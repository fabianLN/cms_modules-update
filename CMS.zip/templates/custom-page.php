<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?=$meta_desc?>">
        <meta name="author" content="Devcrud">
        <title><?=$meta_title?></title>

        <?php include_once('sections/links-head.php') ?>
        <meta name="robots" content="<?=$data['meta_robots']?>">
    </head>
    <body data-spy="scroll" data-target=".navbar" data-offset="40" id="custom-page">
        
        <?php include_once('sections/menu.php') ?>

        <style>
            <?=$data['css']?>
        </style>
        <?=$data['content']?>
        <script>
            <?=$data['js']?>
        </script>


        <?php include_once('sections/footer.php') ?>

        <?php include_once('sections/links-footer.php') ?>

    </body>
</html>
