<!-- font icons -->
<link rel="stylesheet" href="/lib/themify-icons/css/themify-icons.css">

<link rel="stylesheet" href="/lib/animate/animate.css">

<!-- Bootstrap + FoodHut main styles -->
<link rel="stylesheet" href="/public/css/foodhut.css">