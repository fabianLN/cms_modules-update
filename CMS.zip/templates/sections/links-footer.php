<!-- core  -->
<script src="/lib/jquery/jquery-3.4.1.js"></script>
<script src="/lib/bootstrap/bootstrap.bundle.js"></script>

<!-- bootstrap affix -->
<script src="/lib/bootstrap/bootstrap.affix.js"></script>

<!-- wow.js -->
<script src="/lib/wow/wow.js"></script>

<!-- FoodHut js -->
<script src="/public/js/foodhut.js"></script>
