<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?=$meta_desc?>">
        <meta name="author" content="Devcrud">
        <title><?=$meta_title?></title>

        <?php include_once('./templates/sections/links-head.php') ?>
    </head>
    <body data-spy="scroll" data-target=".navbar" data-offset="40" id="404-page">
        
        <?php include_once('./templates/sections/menu.php') ?>
        <!-- header -->
        <header id="home" class="header">
            <div class="overlay text-white text-center">
                <h1 class="display-2 font-weight-bold my-3">404</h1>
                <h2 class="display-4 mb-5">Página no encontrada</h2>
            </div>
        </header>


        <?php include_once('./templates/sections/footer.php') ?>

        <?php include_once('./templates/sections/links-footer.php') ?>

    </body>
</html>
