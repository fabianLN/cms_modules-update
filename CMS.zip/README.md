/***************************************************/
==========Creado por: Fabián Lorente Navarro========
==========Fecha inicio: 04/04/2024==================
==========Fecha revision: 08/04/2024================
/***************************************************/


/***************************************************/
=====================ToDo List=======================
=====================================================
- 28/10/2024
    - Sistema de notificaciones en el admin
    - Sistema de actualizacion para ficheros base
    - Sistema de cambio de plantillas desde el admin
    - Sistema primer inicio sin acceder a ficheros
=====================================================
/***************************************************/


Pasos para iniciar un nuevo proyecto:

    1. Abrir el fichero config/init.php
        1.1 Por defecto ya vienen indicadas las rutas, pero se pueden modificar antes de la primera ejecución si las carpetas cambian el nombre o ubicacion. Tras esto, se pueden configurar desde el admin en la seccion de configuracion
        1.2 Completar los datos para conectar con la base de datos
    2. Revisar los datos especificados en manifest.json (estos datos los utiliza al instalarse como WebApp)
    3. Para instalar todo, abrir en el index. Esto creara las bases de datos y todo lo necesario para que funcione la web
    4. Accede al "/admin" para modificar los datos por defecto del usuario admin (por seguridad)
    5. Instala los modulos necesarios desde "Herramientas > modulos"
    6. ¡Disfruta de tu nueva web!



Datos de acceso a la zona de administracion:

    Url admin: /admin
    Usuario: admin@admin
    Pwd: root1234
**MODIFICAR DATOS POR DEFECTO AL ENTRAR AL ADMINISTRADOR**



Guia para programadores:

    1. Cambiar plantillas
        - Las plantillas incluyen contenido en varios sitios que son:

            |
            |- lib (librerias y modulos necesarios para su funcionamiento exclusivo)
            |
            |- public
            |-- css
            |-- font
            |-- js
            |-- media
            |
            |- templates
            |-- error (podremos encontrar la pagina para el error 404 por defecto)
            |-- sections (las distintas partes compartidas por la plantilla como el menu, header, los includes de css o js, etc...)
            |

        En las anteriores ubicaciones es donde se encuentran los ficheros que componen las plantillas. Pueden ser editados para ajustar la plantilla por defecto o modificados para cambiar por una nueva acorde al proyecto que se esta desarrollando.

    2. Crear modulo:
        - Para crear un modulo, primero tenemos que conocer los ficheros obligatorios y opcionales, por tanto crearemos una carpeta independiente y externa al cms que mas tarde comprimiremos para su instalacion, con los siguientes archivos

        |- composer.json (define la estructura interna y por tanto es recomendable utilizar de base el composer del modulo de prueba)
        |- autoload.php (contiene las funciones basicas para la instalacion y desinstalacion del modulo, generalmente las partes de la bbdd)
        |- README.md (este fichero esta pensado para el programador, por lo que podras guardar el contenido que desees y no es obligatorio)

        Tras conocer estos ficheros, pasariamos a la creacion de la estructura de carpetas para distribuir los ficheros en las carpetas, siguiendo la estructura del cms, es decir si necesitamos crear un nuevo template, deberemos crear la estructura:

        |- templates
        |-- nuevo_fichero.php

        El instalador recorrera la estructura depositando los ficheros en su lugar comenzando siempre desde la raiz del cms.

        En la parte del administrador, podremos crear nuevos accesos en el menu agregando registros en la tabla "admin_menu" completando los campos segun sean los requerimientos del modulo y respetando el sistema de roles:

            1->Admin
            2->Avanzado
            3->Editor
            4->Consultor

        - Creacion de widgets o vistas rapidas por modulo:
            Asi mismo, podremos crear nuevos widgets y vistas rapidas con datos para mostrar en el escritorio del administrador, para ello debemos crear las instancias en las distintas tablas de la base de datos "admin_widgets" y "admin_quickviews" ademas de los ficheros correspodientes en las respectivas carpetas dentro de "admin/view/widgets" o "admin/view/quickView".

        - Inclusion de configuracion del modulo:
            Este apartado es utilizado para editar campos necesarios para el funcionamiento del modulo o para mostrar datos al usuario y hacerlos editables, por ejemplo el titulo h1 en una pagina fija, para conseguir esto existe un modulo del administrador que nos facilitara su uso, veamos:
            1. Lo primero sera incluir en la view del admin el bloque "<div class="block-options pull-right"></div>" que sera donde el jquery nos cargue el boton de abrir la configuracion.
            2. Al final del mismo fichero view que estamos manejando, debemos incluir el siguiente codigo:
                <?php $module_type = 'TYPE'?>
                <?php include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/ModuleConfig/autoload.php'; ?>
                *Donde TYPE es el tipo que hemos asignado a las URL del modulo.
            3. En el atoload.php de nuestro modulo deberemos incluir un insert en la tabla "admin_modules_config" donde indicaremos los campos "type, content". Como hemos visto type es el tipo de la URL y content es un json clave-valor que nos sera devuelto como array para su utilizacion en el frontend mediante la funcion getUrlModuleData(URL). Es por esta funcion por la que el type debe ser el mismo en URL que en "admin_modules_config".

    3. Borrado de modulo:
        - Dentro del anteriormente nombrado "autoload.php" del modulo, tenemos que tener en cuenta las cosas relacionadas que hemos creado y su implicacion con el resto de la web ya que los modulos estan pensado para ser facilmente instalados y desinstalados por el usuario. Por tanto al igual que en la creacion inicializaremos las tablas que necesite nuestro modulo, a la hora de borrar tambien tendremos que eliminar aquellas tablas directas con nuestro modulo y las relaciones que estas hayan generado (como pueden ser urls). Para esta tarea utilizaremos la funcion "delete_database()" del fichero "autoload.php".
        Los distintos ficheros de nuestro modulo son almacenados y eliminados al ser así requerido por el usuario, por tanto no es necesario hacer implementacion de borrado de ficheros extra.

    4. Actualizacion de modulo:
        - Para poder actualizar un modulo posteriormente a la instalacion, existen dos formas o metodos, uno de forma manual y otro automatizado:
        1. Manual: Se debe subir el nuevo .zip con un aumento de version en el composer.json para que el sistema detecte una nueva actualizacion
        2. Automatica: En caso de incluir en el composer.json una url de actualizacion (Ej: "dist": {"url": "url_github_actu"},). En este caso al ser activado el btn de aztualizacion en la pagina de modulos, el sistema hara una comprobacion a la url y hara una comprobacion entre versiones, descargando el nuevo .zip en caso de encontrar una version superior a la instalada.



    ** USO DE FUNCIONES DEL CMS **
    Estas funciones ya estan integradas en el CMS de forma predefinida, en caso de querer utilizarlas en un modulo necesitaras seguir unos pasos que te dejamos a continuacion:

    - Envio de mailing:
        Para agregar un sistema de envio de mails, contamos con una solucion integrada en el cms, para utilizarlo es necesario seguir unos pasos en el controller que requiera el envio de mails:
        1. incluimos el fichero "include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/admin/lib/modules/PHPMailer/SendMail.php' );"
        2. utilizaremos la funcion "enviarCorreo($destinatario,$asunto,$contenido,$fileName='',$fichero='');"

    - Gestion tareas Cron:
        Si queremos agregar funciones que sean necesarias su ejecucion periodica y sin acto del usuario, podemos crearlas en el sistema Cron mediantes funciones implementadas en el cms. Los ficheros a ejecutar deben ser guardados en "/admin/lib/modules/CronJob/scripts/". para la configuracion (crear, actualizar o borrar) desde el controller deberemos seguir los siguientes pasos:
        1. incluimos el fichero "include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/admin/lib/modules/CronJob/CronManager.php' );"
        2. utilizaremos la funcion "manageCronJob('crear', '0 0 * * *', 'script.php', 'mi_identificador');"


Por ultimo y si has llegado hasta aqui, felicitarte por leer todo el toston que te he dejado ahi arriba... lo siento :p 
