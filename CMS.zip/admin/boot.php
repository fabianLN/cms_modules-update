<?php
//Show erros
$_app_stage = 'Dev'; 

if ($_app_stage == 'Dev') {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(1); 
} else {
    error_reporting(0);
}

session_start();
include 'config.php';
include 'funciones.php';
if (isset($_SESSION['user_id']) || isset($_COOKIE['user_id'])) {$usuario = _user();}

//globales
if (!define('APP_URL', $_SERVER['DOCUMENT_ROOT'] . '/admin/')) {}
if (!define('URL', (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['SERVER_NAME'] . '/admin/')) {}
if (!define('URL_POST', (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['SERVER_NAME'] . '/admin/?cf=')) {}
if (!define('MEDIA', (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['SERVER_NAME'] )) {}

include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/PHPMailer/send-mail.php';

if (isset($_GET['cf'])) {
    $routes = explode('/', $_GET['cf']);
    $handler = $routes['0'];
    $action = (!isset($routes[1]) ? '' : $routes[1]);
}

if (!isset($handler)) {
    $handler = 'default';
}

function _auth()
{
	$auth = false;
	//include 'config.php';
	global $primary_nav, $template; //hay que redeclararlas para no tener que incluir de nuevo config

	//comprueba que el usuario exista
	if (isset($_SESSION['user_id']) || isset($_COOKIE['user_id'])) {
		$usuario = ORM::for_table('admin_users')->find_one($_COOKIE['user_id']);
		if($usuario->lastVisited == null){
			$_SESSION['first_time'] = 1;
		}
		$usuario->lastVisited = date("Y/m/d h:m:s");
		$usuario->save();
		if ($_COOKIE['hash_' . hash('sha256', $usuario->id . $usuario->user . $usuario->password)] == hash('sha256', $usuario->user . $usuario->password . $usuario->id)) {
			$auth = true;
		} else {
			r2d2(URL_POST . 'login/logout1');
		}
	} else {
		$routes = explode('/', $_GET['cf']);
		session_start();
		if($routes[1] == 'view-evento-socio' && $_SESSION['previous_location'] == 'eventMailing87659sasdf87076'){
			$auth = true;
			$usuario = ORM::for_table('admin_users')->find_one($_session['sfnun_ydrt']);
			$usuario->lastVisited = date("Y/m/d h:m:s");
			$usuario->save();
			unset($_SESSION['sfnun_ydrt']);
			unset($_SESSION['previous_location']);
		}else{
			r2d2(URL_POST . 'login/logout2');
		}
	}

	//comprueba que el usuario tenga acceso a la pagina para quitar del menu
	if ($auth && $primary_nav) {
		foreach ($primary_nav as $key => $link) {
			$active = ($template['active_page'] == $link['url']) ? 'true' : 'false';
			if ($active) {
				if (_auth_rol($link['rol'])) {
					$auth = true;
					break;
				} else {
					r2d2(URL_POST . 'dashboard');
				}
			}
		}
	}

	//comprueba que el usuario tenga acceso a la pagina
	if ($auth && $primary_nav) {
		foreach ($primary_nav as $row) {
			if(isset($row['sub'])){
				foreach ($row['sub'] as $k) {
					if($template['active_page'] == $k['url']){
						if (_auth_rol($k['rol'])) {
							$auth = true;
							break;
						} else {
							r2d2(URL_POST . 'dashboard');
						}
					}
				}
			}else{
				if($template['active_page'] == $row['url']){
					if (_auth_rol($row['rol'])) {
						$auth = true;
						break;
					} else {
						$auth = false;
					}
				}
			}
		}
	}

	if ($auth) { //aumenta la cookie
		$time = 36000;
		setcookie("user_id", $usuario->id, time() + $time, '/');
		setcookie('hash_' . hash('sha256', $usuario->id . $usuario->user . $usuario->password), hash('sha256', $usuario->user . $usuario->password . $usuario->id), time() + $time, '/');
	} else {
		r2d2(URL_POST . 'login/logout');
	}
}

$sys_render = './admin/controllers/' . $handler . '.php';
//echo $sys_render;exit;
//echo 'exite: '.file_exists($sys_render);exit;
if (file_exists($sys_render)) {
    include $sys_render;
} else {
    $sys_render = './admin/controllers/default.php';
    include $sys_render;
}
