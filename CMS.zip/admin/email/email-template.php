<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Editor de plantillas de email</title>
  <style>body {margin: 0px;}</style>

<link rel="stylesheet" href="/admin/email/dist/css/grapes.min.css">
<link rel="stylesheet" href="/admin/email/plugins/grapesjs-preset-newsletter-master/dist/grapesjs-preset-newsletter.css">
<link rel="stylesheet" href="/admin/email/plugins/grapesjs-preset-webpage-master/dist/grapesjs-preset-webpage.min.css">


<script src="/admin/email/dist/grapes.min.js"></script>
<script src="/admin/email/plugins/grapesjs-preset-webpage-master/dist/grapesjs-preset-webpage.min.js"></script>
<script src="/admin/email/plugins/grapesjs-preset-newsletter-master/dist/grapesjs-preset-newsletter.min.js"></script>
<script src="/admin/email/plugins/grapesjs-plugin-ckeditor-master/dist/grapesjs-plugin-ckeditor.min.js"></script>
<script src="/admin/email/plugins/grapesjs-tui-image-editor-master/dist/grapesjs-tui-image-editor.min.js"></script>
<script src="/admin/email/plugins/grapesjs-tabs-master/dist/grapesjs-tabs.min.js"></script>
<script src="/admin/email/plugins/grapesjs-plugin-forms-master/dist/grapesjs-plugin-forms.min.js"></script>
</head>
<body>

<div id="gjs"></div>

<script type="text/javascript">
  var editor = grapesjs.init({
      container : '#gjs',
      assetManager: {
        upload: 'https://www.puertas-euro-block.com/public/media',
      },
      plugins: [
        'grapesjs-plugin-export',
        'gjs-preset-newsletter',
        'gjs-preset-webpage',
        //'gjs-plugin-ckeditor',
        'grapesjs-tui-image-editor',
        'grapesjs-tabs',
        'grapesjs-plugin-forms',
        ],
      pluginsOpts: {
        'grapesjs-plugin-export': {
          btnLabel: 'Exportar',
        },
        'gjs-preset-newsletter': {
          modalTitleImport: 'Importar plantilla',
          // ... other options
        },
      //'gjs-plugin-ckeditor': {language: 'es',}
      'grapesjs-tui-image-editor': {
          config: {
            includeUI: {
              initMenu: 'Filtro',
            },
          },
        },
        'grapesjs-tabs': {
          // options
        },
        'gjs-preset-webpage': {
          // options
        },
        pluginsOpts: {
        'grapesjs-plugin-forms': {/* ...options */}
      },

      }
  });

  // You can also call the command wherever you want in this way
  //editor.runCommand('gjs-export-zip');
  function getHtml(){
    var html = editor.getHtml();
    return html;
  }
  function getCss(){
    var css = editor.getCss();
    return css;
  }
</script>

</body>
</html>
