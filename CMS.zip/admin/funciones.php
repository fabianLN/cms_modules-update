<?php

    //devuelve el usuario que tiene iniciada la session
    function _user()
    {
        if (isset($_COOKIE['user_id'])) {
            $usuario = ORM::for_table('admin_users')->find_one($_COOKIE['user_id']);
            if ($_COOKIE['hash_' . hash('sha256', $usuario->id . $usuario->user . $usuario->password)] == hash('sha256', $usuario->user . $usuario->password . $usuario->id)) {
                return $usuario;
            } else {
                return false;
            }
        }
        return false;
    }

    //devuelve el rol del usuario (admin, editor, etc)
    function _rol()
    {
        $usuario = _user();
        return $usuario->rol;
    }

    //comprueba que el rol del usuario esta permitido al rol pasado como parametro
    function _auth_rol($rol = '9999999')
    {
        return (_rol() <= $rol);
    }

    //redirige a otra url con un mensaje de e-rror o s-uccess
    function r2d2($to, $ntype = 'e', $msg = '')
    {
        if ($msg == '') {
            header("location: $to");
            exit;
        }
        $_SESSION['ntype'] = $ntype;
        $_SESSION['notify'] = $msg;
        header("location: $to");
        exit;
    }

    //elimina tildes
    function remove_accents($string,$is_url = false) {
        $string = str_replace(' ','-',strtolower($string));
        $string = str_replace('(','',strtolower($string));
        $string = str_replace(')','',strtolower($string));
        $string = str_replace('.','-',strtolower($string));
        if (!$is_url) {$string = str_replace('/','-',strtolower($string));}
        $string = str_replace(',','-',strtolower($string));
        $string = str_replace('+','-',strtolower($string));
        $string = str_replace('°','',strtolower($string));
        //$string = str_replace('x','-',strtolower($string));
        $string = str_replace('*','-',strtolower($string));
        $string = str_replace('Ø','-',strtolower($string));
        $string = str_replace('²','-',strtolower($string));
        $string = str_replace('®','-',strtolower($string));
        $string = str_replace('Φ','-',strtolower($string));
        $string = str_replace('_','-',strtolower($string));
        $string = str_replace('%','-',strtolower($string));
        $string = str_replace(':','-',strtolower($string));
        $string = str_replace('"','-',strtolower($string));
        $string = str_replace('º','-',strtolower($string));
        $string = str_replace('ª','-',strtolower($string));
        $string = str_replace('”','-',strtolower($string));
        $string = str_replace('Ф','',strtolower($string));
        $string = str_replace('\'\'','',strtolower($string));
        $string = str_replace('\'','',strtolower($string));
        $string = str_replace('\\','',strtolower($string));
        $string = str_replace('&','',strtolower($string));
        
        $string = str_replace('__','-',strtolower($string));
        $string = str_replace('---','-',strtolower($string));
        $string = str_replace('-–-','-',strtolower($string));
        $string = str_replace('--','-',strtolower($string));
        $string = str_replace('​-','-',strtolower($string));
        
        if ( !preg_match('/[\x80-\xff]/', $string) )
            return $string;
        
        $chars = array(
        // Decompositions for Latin-1 Supplement
        chr(195).chr(128) => 'A', chr(195).chr(129) => 'A',
        chr(195).chr(130) => 'A', chr(195).chr(131) => 'A',
        chr(195).chr(132) => 'A', chr(195).chr(133) => 'A',
        chr(195).chr(135) => 'C', chr(195).chr(136) => 'E',
        chr(195).chr(137) => 'E', chr(195).chr(138) => 'E',
        chr(195).chr(139) => 'E', chr(195).chr(140) => 'I',
        chr(195).chr(141) => 'I', chr(195).chr(142) => 'I',
        chr(195).chr(143) => 'I', chr(195).chr(145) => 'N',
        chr(195).chr(146) => 'O', chr(195).chr(147) => 'O',
        chr(195).chr(148) => 'O', chr(195).chr(149) => 'O',
        chr(195).chr(150) => 'O', chr(195).chr(153) => 'U',
        chr(195).chr(154) => 'U', chr(195).chr(155) => 'U',
        chr(195).chr(156) => 'U', chr(195).chr(157) => 'Y',
        chr(195).chr(159) => 's', chr(195).chr(160) => 'a',
        chr(195).chr(161) => 'a', chr(195).chr(162) => 'a',
        chr(195).chr(163) => 'a', chr(195).chr(164) => 'a',
        chr(195).chr(165) => 'a', chr(195).chr(167) => 'c',
        chr(195).chr(168) => 'e', chr(195).chr(169) => 'e',
        chr(195).chr(170) => 'e', chr(195).chr(171) => 'e',
        chr(195).chr(172) => 'i', chr(195).chr(173) => 'i',
        chr(195).chr(174) => 'i', chr(195).chr(175) => 'i',
        chr(195).chr(177) => 'n', chr(195).chr(178) => 'o',
        chr(195).chr(179) => 'o', chr(195).chr(180) => 'o',
        chr(195).chr(181) => 'o', chr(195).chr(182) => 'o',
        chr(195).chr(182) => 'o', chr(195).chr(185) => 'u',
        chr(195).chr(186) => 'u', chr(195).chr(187) => 'u',
        chr(195).chr(188) => 'u', chr(195).chr(189) => 'y',
        chr(195).chr(191) => 'y',
        // Decompositions for Latin Extended-A
        chr(196).chr(128) => 'A', chr(196).chr(129) => 'a',
        chr(196).chr(130) => 'A', chr(196).chr(131) => 'a',
        chr(196).chr(132) => 'A', chr(196).chr(133) => 'a',
        chr(196).chr(134) => 'C', chr(196).chr(135) => 'c',
        chr(196).chr(136) => 'C', chr(196).chr(137) => 'c',
        chr(196).chr(138) => 'C', chr(196).chr(139) => 'c',
        chr(196).chr(140) => 'C', chr(196).chr(141) => 'c',
        chr(196).chr(142) => 'D', chr(196).chr(143) => 'd',
        chr(196).chr(144) => 'D', chr(196).chr(145) => 'd',
        chr(196).chr(146) => 'E', chr(196).chr(147) => 'e',
        chr(196).chr(148) => 'E', chr(196).chr(149) => 'e',
        chr(196).chr(150) => 'E', chr(196).chr(151) => 'e',
        chr(196).chr(152) => 'E', chr(196).chr(153) => 'e',
        chr(196).chr(154) => 'E', chr(196).chr(155) => 'e',
        chr(196).chr(156) => 'G', chr(196).chr(157) => 'g',
        chr(196).chr(158) => 'G', chr(196).chr(159) => 'g',
        chr(196).chr(160) => 'G', chr(196).chr(161) => 'g',
        chr(196).chr(162) => 'G', chr(196).chr(163) => 'g',
        chr(196).chr(164) => 'H', chr(196).chr(165) => 'h',
        chr(196).chr(166) => 'H', chr(196).chr(167) => 'h',
        chr(196).chr(168) => 'I', chr(196).chr(169) => 'i',
        chr(196).chr(170) => 'I', chr(196).chr(171) => 'i',
        chr(196).chr(172) => 'I', chr(196).chr(173) => 'i',
        chr(196).chr(174) => 'I', chr(196).chr(175) => 'i',
        chr(196).chr(176) => 'I', chr(196).chr(177) => 'i',
        chr(196).chr(178) => 'IJ',chr(196).chr(179) => 'ij',
        chr(196).chr(180) => 'J', chr(196).chr(181) => 'j',
        chr(196).chr(182) => 'K', chr(196).chr(183) => 'k',
        chr(196).chr(184) => 'k', chr(196).chr(185) => 'L',
        chr(196).chr(186) => 'l', chr(196).chr(187) => 'L',
        chr(196).chr(188) => 'l', chr(196).chr(189) => 'L',
        chr(196).chr(190) => 'l', chr(196).chr(191) => 'L',
        chr(197).chr(128) => 'l', chr(197).chr(129) => 'L',
        chr(197).chr(130) => 'l', chr(197).chr(131) => 'N',
        chr(197).chr(132) => 'n', chr(197).chr(133) => 'N',
        chr(197).chr(134) => 'n', chr(197).chr(135) => 'N',
        chr(197).chr(136) => 'n', chr(197).chr(137) => 'N',
        chr(197).chr(138) => 'n', chr(197).chr(139) => 'N',
        chr(197).chr(140) => 'O', chr(197).chr(141) => 'o',
        chr(197).chr(142) => 'O', chr(197).chr(143) => 'o',
        chr(197).chr(144) => 'O', chr(197).chr(145) => 'o',
        chr(197).chr(146) => 'OE',chr(197).chr(147) => 'oe',
        chr(197).chr(148) => 'R',chr(197).chr(149) => 'r',
        chr(197).chr(150) => 'R',chr(197).chr(151) => 'r',
        chr(197).chr(152) => 'R',chr(197).chr(153) => 'r',
        chr(197).chr(154) => 'S',chr(197).chr(155) => 's',
        chr(197).chr(156) => 'S',chr(197).chr(157) => 's',
        chr(197).chr(158) => 'S',chr(197).chr(159) => 's',
        chr(197).chr(160) => 'S', chr(197).chr(161) => 's',
        chr(197).chr(162) => 'T', chr(197).chr(163) => 't',
        chr(197).chr(164) => 'T', chr(197).chr(165) => 't',
        chr(197).chr(166) => 'T', chr(197).chr(167) => 't',
        chr(197).chr(168) => 'U', chr(197).chr(169) => 'u',
        chr(197).chr(170) => 'U', chr(197).chr(171) => 'u',
        chr(197).chr(172) => 'U', chr(197).chr(173) => 'u',
        chr(197).chr(174) => 'U', chr(197).chr(175) => 'u',
        chr(197).chr(176) => 'U', chr(197).chr(177) => 'u',
        chr(197).chr(178) => 'U', chr(197).chr(179) => 'u',
        chr(197).chr(180) => 'W', chr(197).chr(181) => 'w',
        chr(197).chr(182) => 'Y', chr(197).chr(183) => 'y',
        chr(197).chr(184) => 'Y', chr(197).chr(185) => 'Z',
        chr(197).chr(186) => 'z', chr(197).chr(187) => 'Z',
        chr(197).chr(188) => 'z', chr(197).chr(189) => 'Z',
        chr(197).chr(190) => 'z', chr(197).chr(191) => 's'
        );
        
        $string = strtolower(strtr($string, $chars));
        
        return $string;
    }

    //comprueba los requisitos para la pwd de usuario
    function validate_pwd($password)
    {
        // Validate password strength
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        $number = preg_match('@[0-9]@', $password);
        $specialChars = preg_match('@[^\w]@', $password);

        if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
            $text = 'La contraseña debe tener al menos 8 carácteres de longitud y debe incluir al menos una mayúscula, una minúscula, un número y un carácter especial.';
            $_SESSION['text'] = $text;
            return false;
        } else {
            return true;
        }
    }

    //devuelve el ajuste solicitado
    function get_setting($e)
    {
        $conf = ORM::for_table("appconfig")->where("setting", $e)->find_one();
        return $conf->value;
    }

    //devuelve la extension si esta configurada
    function get_extension(){
        return get_setting('extension');
    }

    //borra la cookie para el logout
    function admin_cookie_delete()
    {
        setcookie('user_id', "", time() - 3600, '/');
        foreach ($_COOKIE as $key => $val) {
            if (strpos($key, 'hash_') === 0) {
                setcookie($key, "", time() - 3600, '/');
            }
        }
    }

    //guarda las acciones de los usuarios en el admin
    function admin_log($description=''){
        $usuario = _user();
        if($description == ''){$description='Se han realizado cambios';}

        $adminLog = ORM::for_table("admin_log")->order_by_desc('id')->find_one();
        if ($adminLog->description == $description) {
            setlocale(LC_ALL,"es_ES");
            $adminLog->fecha = date("Y-m-d H:i:s");
            $adminLog->save();
        }else{
            $adminLog = ORM::for_table("admin_log")->create();
            $adminLog->user = $usuario->id;
            $adminLog->description = $description;
            $adminLog->save();
        }
    }

    //comprueba si hay actualizaciones pendientes
    function checkAndUpdateCmsVersion($manualExecution = false) {
        try {
            // Obtener la configuración de la base de datos
            $config = ORM::for_table("appconfig")->where('setting', 'cms_update')->find_one();
            $configDate = ORM::for_table("appconfig")->where('setting', 'cms_update_date')->find_one();
            
            if (!$config || !$configDate) {
                throw new Exception("No se encontró la configuración 'cms_update' o 'cms_update_date' en la base de datos.");
            }
    
            // Comprobar la fecha de la última actualización
            $lastUpdateDate = new DateTime($configDate->value);
            $currentDate = new DateTime();
    
            // Ejecutar solo si es una ejecución manual o si la última actualización es anterior a hoy
            if (!$manualExecution && $lastUpdateDate->format('Y-m-d') === $currentDate->format('Y-m-d')) {
                return "La comprobación ya se realizó hoy.";
            }
    
            // Leer el archivo composer.json desde la raíz del CMS
            $composerPath = $_SERVER['DOCUMENT_ROOT'] . '/composer.json';
            if (!file_exists($composerPath)) {
                throw new Exception('No se encontró el archivo composer.json en la ruta especificada.');
            }
            
            // Decodificar composer.json
            $composerData = json_decode(file_get_contents($composerPath), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Error al decodificar composer.json: ' . json_last_error_msg());
            }
            
            // Obtener la versión actual del CMS
            $currentVersion = $composerData['module'][0]['version'] ?? null;
            if ($currentVersion === null) {
                throw new Exception('No se encontró la versión en el archivo composer.json.');
            }
            
            // Obtener la URL del archivo .zip desde 'dist'
            $zipUrl = $composerData['module'][0]['dist']['url'] ?? null;
            if (!$zipUrl) {
                throw new Exception('No se encontró la URL de descarga en composer.json.');
            }
    
            // Descargar el archivo .zip a una ubicación temporal
            $tempZipPath = tempnam(sys_get_temp_dir(), 'cms_update') . '.zip';
            file_put_contents($tempZipPath, file_get_contents($zipUrl));
    
            // Descomprimir el archivo .zip en una carpeta temporal
            $tempExtractPath = sys_get_temp_dir() . '/cms_update_extract';
            if (!is_dir($tempExtractPath)) {
                mkdir($tempExtractPath);
            }
            
            $zip = new ZipArchive;
            if ($zip->open($tempZipPath) === TRUE) {
                $zip->extractTo($tempExtractPath);
                $zip->close();
            } else {
                throw new Exception('No se pudo descomprimir el archivo .zip descargado.');
            }
    
            // Verificar que el composer.json existe en la raíz del contenido extraído
            $extractedComposerPath = $tempExtractPath . '/composer.json';
            if (!file_exists($extractedComposerPath)) {
                throw new Exception('No se encontró el archivo composer.json en el archivo .zip descargado.');
            }
    
            // Leer el archivo composer.json extraído
            $moduleData = json_decode(file_get_contents($extractedComposerPath), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Error al decodificar composer.json extraído: ' . json_last_error_msg());
            }
    
            // Obtener la versión remota del módulo
            $remoteVersion = $moduleData['module'][0]['version'] ?? null;
            if (!$remoteVersion) {
                throw new Exception('No se encontró la versión en el composer.json extraído.');
            }
    
            // Comparar versiones
            if (version_compare($remoteVersion, $currentVersion, '>') || $remoteVersion == 'Dev') {
                // Actualizar la versión en la base de datos
                $config->value = $remoteVersion;
                $config->save();
    
                // Limpiar archivos temporales
                unlink($tempZipPath);
                array_map('unlink', glob("$tempExtractPath/*.*"));
                rmdir($tempExtractPath);
    
                return "Nueva versión detectada";
            } else {
                // Limpiar archivos temporales
                unlink($tempZipPath);
                array_map('unlink', glob("$tempExtractPath/*.*"));
                rmdir($tempExtractPath);
    
                return "No hay una versión más reciente disponible.";
            }
        } catch (Exception $e) {
            return 'Error en checkAndUpdateCmsVersion: ' . $e->getMessage();
        }
    }

    //instala si hay actualizaciones pendientes
    function updateCmsModule() {
        $jsonUrl = $_SERVER['DOCUMENT_ROOT'] . '/composer.json'; // URL del JSON desde la raíz del programa
        $tempDir = sys_get_temp_dir();
        $tempZipFile = tempnam($tempDir, 'cms_update_') . '.zip';
        $extractPath = $tempDir . '/' . uniqid('cms_module_', true);
    
        try {
            // Leer el archivo composer.json desde la raíz del CMS
            if (!file_exists($jsonUrl)) {
                throw new Exception('No se encontró el archivo composer.json en la ruta especificada.');
            }
    
            // Decodificar composer.json
            $composerData = json_decode(file_get_contents($jsonUrl), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Error al decodificar composer.json: ' . json_last_error_msg());
            }
    
            // Verificar la URL del archivo ZIP y la versión
            if (!isset($composerData['module'][0]['dist']['url']) || !isset($composerData['module'][0]['version'])) {
                throw new Exception('Faltan datos necesarios en el JSON de configuración.');
            }
    
            $zipUrl = $composerData['module'][0]['dist']['url'];
            $zipVersion = $composerData['module'][0]['version'];
    
            // Descargar el archivo ZIP
            $download = file_put_contents($tempZipFile, fopen($zipUrl, 'r'));
            if ($download === false) {
                throw new Exception('Error al descargar el archivo ZIP del módulo.');
            }
    
            // Extraer el archivo ZIP
            $zip = new ZipArchive;
            if ($zip->open($tempZipFile) === TRUE) {
                mkdir($extractPath);
                $zip->extractTo($extractPath);
                $zip->close();
            } else {
                throw new Exception('No se pudo abrir el archivo ZIP descargado.');
            }
    
            // Obtener las carpetas y archivos a ignorar desde composer.json
            $ignoreFolders = $composerData['module'][0]['ignore']['folders'] ?? [];
            $ignoreFiles = $composerData['module'][0]['ignore']['files'] ?? [];
    
            // Copiar contenido nuevo, ignorando carpetas y archivos especificados en rutas relativas
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($extractPath, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
    
            foreach ($iterator as $item) {
                // Calcular la ruta relativa desde la raíz del CMS
                $relativePath = str_replace($extractPath . '/', '', $item->getPathname());
                $destinationPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $relativePath;
    
                // Ignorar carpetas y archivos especificados en rutas exactas
                foreach ($ignoreFolders as $ignoreFolder) {
                    if (strpos($relativePath, trim($ignoreFolder, '/')) === 0) {
                        continue 2; // Salta al siguiente elemento si está en una carpeta ignorada
                    }
                }
                if (in_array($relativePath, $ignoreFiles)) {
                    continue; // Salta archivos específicos que deben ignorarse
                }
    
                // Copiar archivo o directorio
                if ($item->isDir()) {
                    if (!is_dir($destinationPath)) {
                        mkdir($destinationPath, 0777, true);
                    }
                } else {
                    copy($item->getPathname(), $destinationPath);
                }
            }
    
            return true;
        } catch (Exception $e) {
            throw new Exception('Error en updateCmsModule: ' . $e->getMessage());
        } finally {
            // Limpieza de archivos temporales
            @unlink($tempZipFile);
            if (is_dir($extractPath)) {
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($extractPath, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::CHILD_FIRST
                );
                foreach ($files as $file) {
                    $file->isDir() ? rmdir($file) : unlink($file);
                }
                rmdir($extractPath);
            }
        }
    }
    

    //crea y revisa las redirecciones para una url
    function autoRedirect($old,$new,$rel,$type){
        if($old !== $new){ //si las rutas son distintas
            $existe = ORM::for_table('url_redirect')->where('old_url',$new)->find_one();

            if($existe->id){ //si no existe crea o actualiza la redireccion
                $existe->delete();
            }
            //Buscamos la url para que no haya dos redirecciones iguales
            $todas = ORM::for_table('url_redirect')->where('id_rel',$rel)->where('type',$type)->find_many();
            foreach($todas as $url){ //actualiza todas las redirecciones que tenga el enlace a la nueva url
                $url->new_url = $new;
                $url->save();
            }

            $url_routes = ORM::for_table('url_redirect')->where('old_url',$old)->find_one();
            if(!$url_routes){$url_routes = ORM::for_table('url_redirect')->create();} //la crea en caso de no existir

            if ($old != $new) {
                $url_routes->old_url = $old;
                $url_routes->new_url = $new;
                $url_routes->auto = 1;
                $url_routes->type = $type;
                $url_routes->id_rel = $rel;

                if($url_routes->save()){
                    admin_log('Creada redirección: '.$url_routes->id);
                }
            }
        }
    }

    //optimiza y reescala una imagen
    function imageOptimize($image, $destination_url, $quality = 90, $width = 1920, $height = 1080) {
        include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/Image-master/autoload.php';
    
        // Ruta local de la imagen
        $imagePath = $_SERVER['DOCUMENT_ROOT'] . $image;
    
        // Nombre de la imagen
        $image_name = pathinfo($imagePath, PATHINFO_BASENAME);
    
        // Ruta de destino local
        $image_result = $_SERVER['DOCUMENT_ROOT'] . '/public/media/temp/' . $image_name;
    
        // Copiar la imagen a la carpeta temporal
        copy($imagePath, $image_result);
    
        // Redimensionar y guardar la imagen
        Gregwar\Image\Image::open($image_result)->cropResize($width, $height)->save($image_result, 'jpg');
    
        // Optimizar la calidad de la imagen
        $imagick = new \Imagick(realpath($image_result));
        $imagick->setImageCompressionQuality($quality);
        $imagick->stripImage();
        $imagick->writeImage($image_result);
    
        // Mover la imagen optimizada a la ruta de destino
        rename($image_result, $_SERVER['DOCUMENT_ROOT'] . $destination_url);
    
        // Eliminar la imagen temporal
        unlink($image_result);
    }

    function setURL($id, $type ,$new) {
        //Comprobamos ssi existe la URL para crearla o actualizarla
        $url = ORM::for_table('url_custom')->where('type',$type)->where('id_rel',$id)->find_one();
        $existe = true;
        if (!$url) {
            $url = ORM::for_table('url_custom')->create();
            $existe = false;
        }else{
            $old = $url->url;
        }
        //Si no lleve extension se la pongo
        if (!strpos($new, get_extension())) {
			$url->url = $new.get_extension();
            
        }else{
            $url->url = $new;
        }
        $url->id_rel = $id;
		$url->type = $type;
        if($old!=$new){
            //Se hace el auto redirect 
            if($url->save()){
                if($existe){
                    autoRedirect($old,$url->url,$id,$type);
                    admin_log('Actualizada la url: '.$url->url);
                }
                return true;
            }else{
                return false;
            }
        }else{
            return true;
        }  
    }

    function cronJobExists($identifier) {
        // Ejecutar el comando para listar las tareas cron del usuario actual
        $output = [];
        exec('crontab -l', $output);
    
        // Recorrer las líneas del crontab buscando el identificador
        foreach ($output as $line) {
            if (strpos($line, $identifier) !== false) {
                return true;
            }
        }
    
        return false;
    }

    function setNotification($text,$id_rel,$type)
    {
        $notify = ORM::for_table("admin_notify")->where('text',$text)->where('id_rel',$id_rel)->where('type',$type)->where('user_solved',0)->find_one();
        if(!$notify){
            $notify = ORM::for_table("admin_notify")->create();
            $notify->text = $text;
            $notify->user_solved = 0;
            $notify->id_rel = $id_rel;
            $notify->type = $type;
            $notify->save();
        }else{
            $notify->user_solved = 0;
            $notify->save();
        }

    }