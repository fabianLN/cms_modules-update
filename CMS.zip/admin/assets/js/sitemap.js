var dropzoneImg;

dropzoneImg = $("#my-awesome-dropzone").dropzone({
	maxFiles: 10,
	maxFilesize: 100,
	url: URL + "lib/modules/ImageCache/sitemap-upload.php",
	success: function (file, response) {
		this.removeFile(file);
	}
});

$(".select2").select2({ width: '50%' });
/* GENERAR SITEMAP */
var interval;
$('#sitemap_generator').on('click',function(){
    $(this).next().toggle('slow');
    $('.functionDisable').attr('disabled',true);
    const changefreq = $('#changefreq').val()

    $.ajax({
        url: url_post + 'sitemap/sitemap_generator',
        method: 'POST',
        data: {
            changefreq
        },
        success: function(data){
            showMessage(data);
            interval = setInterval(hiddeMessage, 1500);
        }
    });
});
/* FIN GENERAR SITEMAP */