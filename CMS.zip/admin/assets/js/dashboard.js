$(document).ready(function() {
    $(".abrirOpciones,.cerrarOpciones").click(function () {
        $('.widgets').removeClass('cerradoInicio').toggleClass('abierto').toggleClass('cerrado');
        if (!$(".widgets").hasClass('cerradoInicio') && $(".widgets").hasClass('cerrado')) {
            setTimeout(function () {
                $('.widgets').addClass('cerradoInicio')
            }, 500);
        }
    });

    $('.user-widget').on('change',function(){
        const name = $(this).attr('name')
        const check = $(this).is(':checked')

        $.ajax({
            url: url_post + 'dashboard/user_widgets',
            method: 'POST',
            data: {
                name,
                check
            },
            success: function(data){
                $('.dashboard_widgets').html(data);
            }
        });
    })

    $('.user-quickviews').on('change',function(){
        const name = $(this).attr('name')
        const check = $(this).is(':checked')

        $.ajax({
            url: url_post + 'dashboard/user_quickviews',
            method: 'POST',
            data: {
                name,
                check
            },
            success: function(data){
                $('.dashboard_quickView').html(data);
            }
        });
    })

    $('.viewHelp').on('click',function(){
        $('#modal-first_time').modal('show')
        $('.step').each(function () {
            $(this).css('display', 'none')
        })
        $('#step-2').css('display', 'block')
        $('.abrirOpciones').addClass('animation-pulse')
    })


})

$('.nextStep').on('click', function () {
    const next = ($(this).closest('.step').data('step') + 1)
    const step = $(this).closest('.step').data('step')

    if (step == 1) {
        const user = $('#user-first-correo').val()
        const pwd = $('#user-first-pwd').val()
        $.ajax({
            url: url_post + 'user/first_edit',
            method: 'POST',
            data: {
                user,
                pwd
            },
            success: function (data) {
                const result = JSON.parse(data)
                if (result.code == 0) {
                    $('#message').addClass('alert-'+result.class).html(data).toggle('slow')
                } else {
                    $('.step').each(function () {
                        $(this).css('display', 'none')
                    })
                    $('#step-' + next).css('display', 'block')
                    $('.abrirOpciones').addClass('animation-pulse').click()
                }
            }
        });
    } else if( step == 2) {
        $('.step').each(function () {
            $(this).css('display', 'none')
        })
        $('#step-' + next).css('display', 'block')
        $('.abrirOpciones').removeClass('animation-pulse').click()
        $('.sidebar-nav').css('border','1px solid red')
        $('.sidebar-nav-menu').each(function(){
            $(this).addClass('open').next('ul').css('display','block')
        })
    } else if (step == 3) {
        $('.sidebar-nav').css('border','none')
        $('.sidebar-nav-menu').each(function(){
            $(this).removeClass('open').next('ul').css('display','none')
        })
        $('#modal-first_time').modal('hide')
    } else {
        $('.step').each(function () {
            $(this).css('display', 'none')
        });
        $('#step-' + next).css('display', 'block');
        $('.sidebar-nav').css('border','none')
    }
});