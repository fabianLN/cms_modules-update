$(".select2").select2({ width: '50%' });
/* Carga la tabla de logs */
$(document).ready(function() {
    EcomOrders.init();
    $('a[data-toggle="tab"]').on( 'shown.bs.tab', function (e) {
        $.fn.dataTable.tables( {visible: true, api: true} ).columns.adjust();
    } );
    $("#ecom-products").DataTable().destroy();
    $("#ecom-products").DataTable( {
        responsive: true,
        "processing": true,
        "serverSide": true,
        "ajax": "/admin/lib/modules/dataTables/admin_log.php",
        "language": {
            'loadingRecords': '&nbsp;',
            'processing': ''
        },
        "columns": [
            { data: 0,render: function (data, type, row) { return data; } },
            { data: 1,render: function (data, type, row) { return data; } },
            { data: 2,render: function (data, type, row) { return data; } },
            { data: 3,render: function (data, type, row) { return moment(data).format('D/M/YYYY HH:mm');; } },
            
        ],
        "order": [[ 0, "desc" ]],
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todas"]]
    } );
    $('#ecom-products').css('width','100%');
});

/* BORRADO DE CACHE */
var interval;
$('#clear-cache').on('click',function(){
    $(this).next().toggle('slow');
    $('.functionDisable').attr('disabled',true);
    $.ajax({
        url: url_post + 'settings/clearCache',
        method: 'POST',
        success: function(data){
            showMessage(data);
            interval = setInterval(hiddeMessage, 1500);
        }
    });
});
/* FIN BORRADO CACHE */

/* OPTIMIZACION DE TABLAS */
var interval;
$('#dbOptimice').on('click',function(){
    $(this).next().toggle('slow');
    $('.functionDisable').attr('disabled',true);
    $.ajax({
        url: url_post + 'settings/dbOptimice',
        method: 'POST',
        success: function(data){
            showMessage(data);
            interval = setInterval(hiddeMessage, 1500);
        }
    });
});
/* FIN OPTIMIZACION */