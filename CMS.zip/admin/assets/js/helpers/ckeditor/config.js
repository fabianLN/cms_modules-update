/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function (config) {
	// Define changes to default configuration here. For example:
	config.language = 'es';
	config.allowedContent = true;
	// config.uiColor = '#AADC6E';
	config.skin = 'office2013';
	config.toolbar = [
		{ name: 'document', items: [ 'Source', '-', 'Save', 'NewPage', 'ExportPdf', 'Preview', 'Print', '-', 'Templates','fontawesome5' ] },
		{ name: 'clipboard', items: [ 'Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo' ] },
		{ name: 'editing', items: [ 'Find', 'Replace', '-', 'SelectAll', '-', 'Scayt' ] },
		{ name: 'forms', items: [ 'Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField' ] },
		'/',
		{ name: 'basicstyles', items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'CopyFormatting', 'RemoveFormat' ] },
		{ name: 'paragraph', items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl', 'Language' ] },
		{ name: 'links', items: [ 'Link', 'Unlink', 'Anchor' ] },
		{ name: 'insert', items: [ 'Image', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak', 'Iframe' ] }, // 'Flash',
		'/',
		{ name: 'styles', items: [ 'Styles', 'Format', 'Font', 'FontSize' ] },
		{ name: 'colors', items: [ 'TextColor', 'BGColor' ] },
		{ name: 'tools', items: [ 'Maximize', 'ShowBlocks' ] },
		{ name: 'about', items: [ 'About' ] }
	];
	config.extraPlugins = 'fontawesome5';
	config.fontawesome = { 'path':'https://pro.fontawesome.com/releases/v5.13.1/css/all.css', 'version':'5.13.1', 'edition':'pro', 'element':'i' };
	config.protectedSource.push(/<i[^>]*><\/i>/g);
	config.scayt_autoStartup = true;
	config.scayt_sLang = 'es_ES';

	config.filebrowserBrowseUrl = URL_WEB+'/admin/lib/modules/filemanager/filemanager/dialog.php?type=2&editor=ckeditor&crossdomain=1&akey=14970721110D7AA8D9F9E11DB38EFD49&fldr=';
	config.filebrowserUploadUrl = URL_WEB+'/admin/lib/modules/filemanager/filemanager/dialog.php?type=2&editor=ckeditor&crossdomain=1&akey=14970721110D7AA8D9F9E11DB38EFD49&fldr=';
	config.filebrowserImageBrowseUrl = URL_WEB+'/admin/lib/modules/filemanager/filemanager/dialog.php?type=2&editor=ckeditor&crossdomain=1&akey=14970721110D7AA8D9F9E11DB38EFD49&fldr=';
};

CKEDITOR.dtd.$removeEmpty['i'] = false;

//https://www.responsivefilemanager.com/index.php documentacion del explorador de archivos