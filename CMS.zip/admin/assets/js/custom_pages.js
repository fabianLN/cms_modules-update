/*$('.updateText').on('click',function(){
	var id = $('#page_id').val();//id
	var texto = CKEDITOR.instances['ckeditor'].getData()//texto
	
	$(".avisoOpciones").remove();
	$.ajax({
		url: '?cf=custom_pages/text_update',
		method: 'POST',
		data: {
			id:id,
			texto:texto,
		},
		success: function(data){
			if(!$.isNumeric(data)){
				var a = 'danger';
				$("#page-content").prepend('<div class="alert alert-'+a+' avisoOpciones" style="display:none" role="alert">' + data + '</div>');
				$(".avisoOpciones").show('slow');
			}else{
				window.location = '/admin/lib/modules/VvvebJs/editor_post.php?action=post_text&post='+id
			}
		}
	});
})*/

dropzoneImg = $("#my-awesome-dropzone").dropzone({
    maxFiles: 10,
    maxFilesize: 2,
    url: URL + "lib/modules/ImageCache/multiple-img-upload.php",
    success: function (file, response) {
        this.removeFile(file)
        reloadImg()
    }
});

$('.guardarpaginaV').on('click',function(){
    const id = $('#page-id').val()
    const titulo = $('#page-nombre').val()
    const subtitulo = $('#page-subnombre').val()
    const tipo = $('#tipo-evento').val()
    const description = CKEDITOR.instances['ckeditor'].getData()
    const meta_title = $('#page-meta-title').val()
    const meta_key = $('#page-meta-keywords').val()
    const meta_desc = $('#page-meta-description').val()
    const url = $('#page-url').val()
    let tab_title = [];
	let tab_content = [];

    for(var i = 0; i<5;i++){
		tab_title[i] = $('#tab-name-'+i).val();
		tab_content[i] = CKEDITOR.instances['product_description_bottom_'+i].getData();
	}

    $.ajax({
		url: '?cf=custom_pages/create_update_page',
		method: 'POST',
		data: {
			id,
			titulo,
			subtitulo,
			tipo,
			description,
			meta_title,
			meta_key,
			meta_desc,
			url,
            tab_title,
            tab_content
		},
		success: function(data){
            data = JSON.parse(data)
			$("#page-content").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>');
			$(".avisoOpciones").show('slow');
			setTimeout(
				function() 
				{
					window.location.href = '?cf=custom_pages/view-pagina/'+data['id']
				}, 5000);
		}
	});
})

$('#page-nombre').on('input',function(){
	var titulo = $(this).val().toLowerCase().normalize('NFKD').replace(/[^\w\s.-_\/]/g, '').replace(/ /g,'-').replace(/\?/g, '');
	$('#page-url').val(titulo);
});


/* FUNCIONES */

//recargar imagenes
const reloadImg = () => {
	const ruta = $("#dropzone-config").data('folder');
	const id = $("#dropzone-config").data('id');
	$('#tableImgs').load(URL + 'lib/modules/ImageCache/img-product-reload.php?folder=' + ruta + '&p=' + id);
}

// Delete
const deleteImg = (e, d) => {
	// AJAX request
	$('#tableImgs').load(URL + 'lib/modules/ImageCache/img-product-reload.php?path=' + e + '&delete=' + d, function () {
		reloadImg();
	});
}

/* LLAMADAS */
reloadImg()