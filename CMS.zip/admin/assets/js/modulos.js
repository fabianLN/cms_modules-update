$(document).ready(function() {
	EcomOrders.init();
})

var dropzoneImg;

dropzoneImg = $("#my-awesome-dropzone").dropzone({
	maxFiles: 10,
	maxFilesize: 100,
	url: URL + "lib/modules/ImageCache/modules-upload.php",
	success: function (file, response) {
		this.removeFile(file);
        location.reload()
	}
});

$('.intall-btn').on('click',function(){
	const file = $(this).data('file')

	$.ajax({
		url: '?cf=pluggins/install',
        method: 'POST',
		data: {
			file
		},
        success: function(data){
            showMessage(data);
            interval = setInterval(hiddeMessage, 1500);
        }
    });
})

$('.borrable-btn').on('click',function(){
	const file = $(this).data('file')

	$.ajax({
		url: '?cf=pluggins/delete',
        method: 'POST',
		data: {
			file
		},
        success: function(data){
            showMessage(data);
            interval = setInterval(hiddeMessage, 1500);
        }
    });
})

$('.checkUpdate').on('click',function(){
	$(this).find('i').addClass('fa-spin')
	$('#message').html('').hide('slow')

	$.ajax({
		url: '?cf=pluggins/check_update',
        method: 'POST',
        success: function(data){
			data = JSON.parse(data)
			$('#message').append('<span class="alert"></span>').find('span').addClass(data.class).text(data.text)
			$('#message').show('slow')
			setTimeout(function() {
				if(data.code == 1){
					location.reload()
				}else{
					//$('#message').html('').hide('slow')
				}
			}, 3000);
			$('.checkUpdate').find('i').removeClass('fa-spin')
        }
    });
})