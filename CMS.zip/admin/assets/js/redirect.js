$(document).ready(function() {
	EcomOrders.init();
    $("#ecom-redirect").DataTable().destroy();
    $("#ecom-redirect").DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": "/admin/lib/modules/dataTables/url_redirect.php",
        "language": {
            'loadingRecords': '&nbsp;',
            'processing': ''
        },
        "columns": [
            { data: 0,render: function (data, type, row) { return data; } },
            { data: 1,render: function (data, type, row) { var arr = Object.keys(row).map(function (key) { return row[key]; }); return '<a href="?cf=url_redirect/view-redirect/'+arr[0]+'"><strong>'+data+'</strong></a>'; } },
            { data: 2,render: function (data, type, row) { return data; } },
            { data: 3,render: function (data, type, row) { 
                var arr = Object.keys(row).map(function (key) { return row[key]; });

                return '<div class="btn-group btn-group-sm"><a href="?cf=url_redirect/view-redirect/'+arr[0]+'" data-toggle="tooltip" title="Editar" class="btn btn-default"><i class="fa fa-pencil"></i></a><a href="#modalDeleteProduct" url_action="?cf=url_redirect/delete-redirect/'+arr[0]+'" data-toggle="tooltip" title="Borrar" class="btn btn-xs btn-danger deleteField"><i class="fa fa-times"></i></a></div>'; 
            } },
            
        ],
        "order": [[ 0, "desc" ]],
        "columnDefs": [{
            "targets": 0,
            "orderable": true,
            className: 'text-center'
        },
        {
            "targets": 3,
            className: 'text-center'
        }],
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todas"]]
    } );
} );

$('#act-redirect').on('click',function(){
    var request = $('#url_route-request').val();
    var target = $('#url_route-target').val();
    var type = $('#url_route-type').val();
    var id = $('#id-url_route').val();
    
    if(request != '' && target != '' && type != ''){
		$.ajax({
			method: "POST",
			url: '?cf=url_redirect/update-redirect',
			data: {
				request:request,
				target:target,
                type:type,
                id:id
			},
			async: false
		}).done(function (data) {
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">redirección guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		//location.href = '?cf=url_redirect/view-redirect/' + data_basic;
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('#add-redirect').on('click',function(){
    var request = $('#url_route-request').val();
    var target = $('#url_route-target').val();
    var type = $('#url_route-type').val();
    
    if(request != '' && target != '' && type != ''){
		$.ajax({
			method: "POST",
			url: '?cf=url_redirect/create-redirect',
			data: {
				request:request,
				target:target,
				type:type,
			},
			async: false
		}).done(function (data) {
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">redirección guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		location.href = '?cf=url_redirect/view-redirect/' + data_basic;
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});