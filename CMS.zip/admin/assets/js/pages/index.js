/*
 *  Document   : index.js
 *  Author     : fabian
 *  Description: Custom javascript code used in Dashboard page
 */

 // Random data for the chart
var dataEarnings;
var dataEarningsLastYear;
var dataSales;
var dataSalesLastYear;
var dataPedidosPorDia;
var ubicacion, compras, abandonados, guardados;

changeDates(30)

$.ajax({
    method: "POST",
    url: 'view/ajax.dashboard_data.php',
    data: {
        getVentas:'true',
    },
    async: false
}).done(function (data) {
    dataEarnings = JSON.parse(data);
});
$.ajax({
    method: "POST",
    url: 'view/ajax.dashboard_data.php',
    data: {
        getVentasLastYear:'true',
    },
    async: false
}).done(function (data) {
    dataEarningsLastYear = JSON.parse(data);
});
$.ajax({
    method: "POST",
    url: 'view/ajax.dashboard_data.php',
    data: {
        getPedidos:'true',
    },
    async: false
}).done(function (data) {
    dataSales = JSON.parse(data);
});
$.ajax({
    method: "POST",
    url: 'view/ajax.dashboard_data.php',
    data: {
        getPedidosLastYear:'true',
    },
    async: false
}).done(function (data) {
    dataSalesLastYear = JSON.parse(data);
});

//var dataEarnings = [[1,"0"],[2,"0"],[3,"0"],[4,"0"],[5,"0"],[6,"0"],[7,"0"],[8,"0"],[9,"3"],[10,"0"],[11,"0"],[12,"0"]]; //datos de ventas
//var dataSales = [[1, 500], [2, 420], [3, 480], [4, 350], [5, 600], [6, 850], [7, 1100], [8, 950], [9, 1220], [10, 1300], [11, 1500], [12, 1700]]; //datos de pedidos
//var newsletter = [50,10,40,39,52,32,17]; //apuntados al newsletter
// Array with month and day labels used in chart
var chartMonths = [[1, 'Enero'], [2, 'Febrero'], [3, 'Marzo'], [4, 'Abril'], [5, 'Mayo'], [6, 'Junio'], [7, 'Julio'], [8, 'Agosto'], [9, 'Septiembre'], [10, 'Octubre'], [11, 'Noviembre'], [12, 'Diciembre']];

var Index = function() {

    return {
        init: function() {
            /* Mini Bar Charts with jquery.sparkline plugin, for more examples you can check out http://omnipotent.net/jquery.sparkline/#s-about */
            /*var miniChartBarOptions = {
                type: 'bar',
                barWidth: 40,
                barSpacing: 1,
                height: '335px',
                tooltipOffsetX: -25,
                tooltipOffsetY: 20,
                barColor: '#999999',
                tooltipPrefix: '',
                tooltipSuffix: ' Pedidos',
                tooltipFormat: '{{prefix}}{{value}}{{suffix}}'
            };*/
            //$('#mini-chart-brand').sparkline(dataPedidosPorDia, miniChartBarOptions);

            /*
             * Flot Jquery plugin is used for charts
             *
             * For more examples or getting extra plugins you can check http://www.flotcharts.org/
             * Plugins included in this template: pie, resize, stack, time
             */

            // Get the elements where we will attach the charts
            var dashWidgetChart = $('#dash-widget-chart');

            // Initialize Dash Widget Chart
            $.plot(dashWidgetChart,
                [
                    {
                        data: dataEarnings,
                        lines: {show: true, fill: false},
                        points: {show: true, radius: 6, fillColor: '#e67e22'}
                    },
                    {
                        data: dataEarningsLastYear,
                        lines: {show: true, fill: false},
                        points: {show: true, radius: 6, fillColor: '#058DC7'}
                    }
                ],
                {
                    colors: ['#d27320', '#047DB0'],
                    legend: {show: false},
                    grid: {borderWidth: 0, hoverable: true, clickable: true},
                    yaxis: {show: true},
                    xaxis: {show: false, ticks: chartMonths}
                }
            );

            // Creating and attaching a tooltip to the widget
            var previousPoint = null, ttlabel = null, pedido = null;
            dashWidgetChart.bind('plothover', function(event, pos, item) {
                if (item) {
                    if (previousPoint !== item.dataIndex) {
                        previousPoint = item.dataIndex;

                        $('#chart-tooltip').remove();
                        var x = item.datapoint[0], y = item.datapoint[1];

                        // Get xaxis label
                        var monthLabel = item.series.xaxis.options.ticks[item.dataIndex][1];

                        if (item.seriesIndex === 1) {
                            pedido = dataSalesLastYear[item.dataIndex];
                            ttlabel = '<strong>' +pedido+'</strong> pedidos en ' + monthLabel + ', <strong>' + y + '€</strong>';
                            //ttlabel = '<strong>' + y + '</strong> ventas en <strong>' + monthLabel + '</strong>';
                        } else {
                            pedido = dataSales[item.dataIndex];
                            ttlabel = '<strong>' +pedido+'</strong> pedidos en ' + monthLabel + ', <strong>' + y + '€</strong>';
                        }

                        $('<div id="chart-tooltip" class="chart-tooltip">' + ttlabel + '</div>')
                            .css({top: item.pageY - 50, left: item.pageX - 150}).appendTo("body").show();
                    }
                }else {
                    $('#chart-tooltip').remove();
                    previousPoint = null;
                }
            });
        }
    };
}();

function loadInfoChart(){ //Carga la información de los gráficos
    var ttlabel = null;
    var chartDays = [[0,"Lunes"],[1,"Martes"],[2,"Miércoles"],[3,"Jueves"],[4,"Viernes"],[5,"Sábado"],[6,"Domingo"]];

    var pedidos_dias = $("#mini-chart-brand")
    if(pedidos_dias.length > 0){
        $.plot(pedidos_dias,[
                {
                    data: dataPedidosPorDia,
                    bars: {show: true, fill: true,align: "center",},
                }
            ],{
                colors: ['#888888'],
                legend: {show: false},
                grid: {borderWidth: 0, hoverable: true, clickable: true,gridLines: false},
                yaxis: {show: true,gridLines: false},
                xaxis: {show: true, gridLines: false, ticks: chartDays}
            }
        );
    }
    
    var guardados_chart = $("#mini-chart-sa")
    if(guardados_chart.length > 0){
        $.plot(guardados_chart,[
                {
                    data: guardados,
                    bars: {show: true, fill: true,align: "center",},
                }
            ],{
                colors: ['#e74c3c'],
                legend: {show: false},
                grid: {borderWidth: 0, hoverable: true, clickable: true,gridLines: false},
                yaxis: {show: true,gridLines: false},
                xaxis: {show: true, gridLines: false, ticks: ubicacion}
            }
        );
    }

    var abandonados_chart = $("#mini-chart-ca")
    if(abandonados_chart.length > 0){
        $.plot(abandonados_chart,[
                {
                    data: abandonados,
                    bars: {show: true, fill: true,align: "center",},
                }
            ],{
                colors: ['#e67e22'],
                legend: {show: false},
                grid: {borderWidth: 0, hoverable: true, clickable: true,gridLines: false},
                yaxis: {show: true,gridLines: false},
                xaxis: {show: true, gridLines: false, ticks: ubicacion}
            }
        );
    }

    var compras_chart = $("#mini-chart-co")
    if(compras_chart.length > 0){
        $.plot(compras_chart,[
                {
                    data: compras,
                    bars: {show: true, fill: true,align: "center",},
                }
            ],{
                colors: ['#27ae60'],
                legend: {show: false},
                grid: {borderWidth: 0, hoverable: true, clickable: true,gridLines: false},
                yaxis: {show: true,gridLines: false},
                xaxis: {show: true, gridLines: false, ticks: ubicacion}
            }
        );
    }

    pedidos_dias.bind('plothover', function(event, pos, item) {
        if (item) {
            $('#chart-tooltip').remove();
            var y = item.datapoint[1];

            // Get xaxis label
            var monthLabel = item.series.xaxis.options.ticks[item.dataIndex][1];

            ttlabel = '<strong>' + y + '</strong> ventas en ' + monthLabel;

            $('<div id="chart-tooltip" class="chart-tooltip">' + ttlabel + '</div>')
                .css({top: item.pageY - 50, left: item.pageX - 150}).appendTo("body").show();
        }else {
            $('#chart-tooltip').remove();
        }
    });

    guardados_chart.bind('plothover', function(event, pos, item) {
        if (item) {
            $('#chart-tooltip').remove();
            var y = item.datapoint[1];

            // Get xaxis label
            var monthLabel = item.series.xaxis.options.ticks[item.dataIndex][1];

            ttlabel = '<strong>' + y + '</strong> guardados en ' + monthLabel;

            $('<div id="chart-tooltip" class="chart-tooltip">' + ttlabel + '</div>')
                .css({top: item.pageY - 50, left: item.pageX - 150}).appendTo("body").show();
        }else {
            $('#chart-tooltip').remove();
        }
    });

    abandonados_chart.bind('plothover', function(event, pos, item) {
        if (item) {
            $('#chart-tooltip').remove();
            var y = item.datapoint[1];

            // Get xaxis label
            var monthLabel = item.series.xaxis.options.ticks[item.dataIndex][1];

            ttlabel = '<strong>' + y + '</strong> abandonados en ' + monthLabel;

            $('<div id="chart-tooltip" class="chart-tooltip">' + ttlabel + '</div>')
                .css({top: item.pageY - 50, left: item.pageX - 150}).appendTo("body").show();
        }else {
            $('#chart-tooltip').remove();
        }
    });

    compras_chart.bind('plothover', function(event, pos, item) {
        if (item) {
            $('#chart-tooltip').remove();
            var y = item.datapoint[1];

            // Get xaxis label
            var monthLabel = item.series.xaxis.options.ticks[item.dataIndex][1];

            ttlabel = '<strong>' + y + '</strong> compras en ' + monthLabel;

            $('<div id="chart-tooltip" class="chart-tooltip">' + ttlabel + '</div>')
                .css({top: item.pageY - 50, left: item.pageX - 150}).appendTo("body").show();
        }else {
            $('#chart-tooltip').remove();
        }
    });
}

function getUbicacion(days = 30){ //obtiene los label de las ubicaciones
    dateIni = getDateIni(days)
    dateEnd = getDateEnd()
    $.ajax({
        method: "POST",
        url: 'view/ajax.interacciones.php',
        data: {
            action:'getUbicacion',
            dateIni: dateIni,
            dateEnd: dateEnd,
            searchBy: 'comunidad',
        },
        async: false
    }).done(function (data) {
        ubicacion = JSON.parse(data);
    });
}

function getCompras(days = 30){ //obtiene los datos de compras
    dateIni = getDateIni(days)
    dateEnd = getDateEnd()
    $.ajax({
        method: "POST",
        url: 'view/ajax.interacciones.php',
        data: {
            action:'getCompras',
            dateIni: dateIni,
            dateEnd: dateEnd,
            order: ubicacion,
            searchBy: 'comunidad',
        },
        async: false
    }).done(function (data) {
        compras = JSON.parse(data);
    });
}

function getAbandonedCart(days = 30){ //obtiene los datos de compras
    dateIni = getDateIni(days)
    dateEnd = getDateEnd()
    $.ajax({
        method: "POST",
        url: 'view/ajax.interacciones.php',
        data: {
            action:'getAbandonedCart',
            dateIni: dateIni,
            dateEnd: dateEnd,
            order: ubicacion,
            searchBy: 'comunidad',
        },
        async: false
    }).done(function (data) {
        abandonados = JSON.parse(data);
    });
}

function getSaveCart(days = 30){ //obtiene los datos de compras
    dateIni = getDateIni(days)
    dateEnd = getDateEnd()
    $.ajax({
        method: "POST",
        url: 'view/ajax.interacciones.php',
        data: {
            action:'getSaveCart',
            dateIni: dateIni,
            dateEnd: dateEnd,
            order: ubicacion,
            searchBy: 'comunidad',
        },
        async: false
    }).done(function (data) {
        guardados = JSON.parse(data);
    });
}

function getOrderByDay(days = 30){ //obtiene los datos de ventas por dias
    dateIni = getDateIni(days)
    dateEnd = getDateEnd()
    $.ajax({
        method: "POST",
        url: 'view/ajax.dashboard_data.php',
        data: {
            dateIni: dateIni,
            dateEnd: dateEnd,
            getPedidosPorDia:'true',
        },
        async: false
    }).done(function (data) {
        dataPedidosPorDia = JSON.parse(data);
    });
}

function getDateIni(days){
    var d = new Date();
    if (days == 1) {
        dateIni = "01/01/" + d.getFullYear();
    }else{
        d.setDate(d.getDate() - days);
        dateIni = d.getDate() + "/" + ("0" + (d.getMonth() + 1)).slice(-2) + "/" + d.getFullYear();
    }
    return dateIni;
}
function getDateEnd(){
    var d = new Date();
    dateEnd = d.getDate() + "/" + ("0" + (d.getMonth() + 1)).slice(-2) + "/" + d.getFullYear();
    return dateEnd;
}

function changeDates(option){
    switch (option) {
        case 1:
            $('#rango_fechas').text('Último año');
            $('.dates_range').each(function(){ $(this).removeClass('active'); });
            $('#dates_range-1').addClass('active');
            break;
        case 7:
            $('#rango_fechas').text('Últimos 7 días');
            $('.dates_range').each(function(){ $(this).removeClass('active'); });
            $('#dates_range-7').addClass('active');
            break;
        case 30:
            $('#rango_fechas').text('Últimos 30 días');
            $('.dates_range').each(function(){ $(this).removeClass('active'); });
            $('#dates_range-30').addClass('active');
            break;
    }

    getUbicacion(option);
    getCompras(option);
    getAbandonedCart(option);
    getSaveCart(option);
    getOrderByDay(option);

    loadInfoChart();
}