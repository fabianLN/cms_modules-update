/*
 *  Document   : readyTasks.js
 *  Author     : pixelcave
 *  Description: Custom javascript code used in Tasks page
 */

var ReadyTasks = function() {

    return {
        init: function() {
            var taskList        = $('.task-list');
            var taskInput       = $('#add-task');
            var taskInputVal    = '';

            /* On page load, check the checkbox if the class 'task-done' was added to a task */
            $('.task-done input:checkbox').prop('checked', true);

            /* Toggle task state */
            taskList.on('click', 'input:checkbox', function(){
                $(this).parents('li').toggleClass('task-done');
            });

            /* Remove a task from the list */
            taskList.on('click', '.task-close', function(){
                $(this).parents('li').slideUp();
            });

            /* Add a new task to the list */
            $('#add-task-form').on('submit', function(e){
                // Get input value
                e.preventDefault();
                taskInputVal = taskInput.prop('value');

                // Check if the user entered something
                if ( taskInputVal ) {
                    // Add it to the task list
                    const calendar = $('.calendar_id.active').data('id')
                    $.ajax({
                        method: "POST",
                        url: '?cf=calendario/get-create-event',
                        data: {
                            calendar,
                            taskInputVal
                        },
                        async: false
                    }).done(function (data) {
                        taskList
                        .prepend(data);
                    });

                    // Clear input field
                    taskInput.prop('value', '').focus();
                } else {
                    $("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">Debes escribir un nombre para el evento</div>');
                    $(".avisoOpciones").show('slow');
                }

                // Don't let the form submit
                return false;
            });
        }
    };
}();
