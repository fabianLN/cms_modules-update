// http://www.flotcharts.org/
var dateIni = $('#des-range1').val();
var dateEnd = $('#des-range2').val();

$(function() {

    /* ======
        ZONA DE VARIABLES
    =======*/
    var ubicacion, visitas, compras, abandonados, guardados;
    var data_label = [];
    
    /* ======
        ZONA DE MOSTRADO DE DATOS GRAFICA
    =======*/
    function getData(type = 'lines'){ //podria guardar las variables para evitar tener que hacer la busqueda cada vez
        $('#visitas').css('background-color','#d2d0d0a1').prepend('<i class="fas fa-spinner fa-pulse loading"></i>');
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        var values = $('#campos').val();

        visitas = '';
        compras = '';
        abandonados = '';
        guardados = '';
        data_label = [];
        values.forEach(item => { //obtiene los datos que se quieren mostrar
            switch (item) {
                case '1':
                    getVisitas();
                    break;
                case '2':
                    getCompras();
                break;
                case '3':
                    getAbandonedCart();
                break;
                case '4':
                    getSaveCart();
                break;
                case '5':
                    getOrders();
                break;
            }
        });

        var data_table = [{
            label: data_label[0],
            data: visitas,
            [type]: {show: true,barWidth: 0.6,align: "center"},
			points: { show: true }
        },
        {
            label: data_label[1],
            data: compras,
            [type]: {show: true,barWidth: 0.6,align: "center"},
			points: { show: true }
        },
        {
            label: data_label[2],
            data: abandonados,
            [type]: {show: true,barWidth: 0.6,align: "center"},
			points: { show: true }
        },
        {
            label: data_label[3],
            data: guardados,
            [type]: {show: true,barWidth: 0.6,align: "center"},
			points: { show: true }
        }];

        //muestra por pantalla
        $.plot($("#visitas"), data_table, 
        {
            legend: {show: true},
            grid: {borderWidth: 0, hoverable: true, clickable: true},
            xaxis: {
                mode: "categories",
                showTicks: false,
                gridLines: false,
                ticks: ubicacion
            }
        });

        // crea el tooltip del hover con los datos
        var previousPoint = null, ttlabel = null;
        $('#visitas').bind('plothover', function(event, pos, item) {

            if (item) {
                if (previousPoint !== item.dataIndex) {
                    previousPoint = item.dataIndex;

                    $('#chart-tooltip').remove();
                    var x = item.datapoint[0], y = item.datapoint[1];

                    // Get xaxis label
                    var Label = item.series.xaxis.options.ticks[item.dataIndex][1];

                    ttlabel = '<strong>' + y + '</strong> ' + data_label[item.seriesIndex] + ' en <strong>' + Label + '</strong>';

                    $('<div id="chart-tooltip" class="chart-tooltip">' + ttlabel + '</div>')
                        .css({top: item.pageY - 50, left: item.pageX - 50}).appendTo("body").show();
                }
            }else {
                $('#chart-tooltip').remove();
                previousPoint = null;
            }
        });
        $('#visitas').css('background-color','transparent');
    }

    /* ======
        ZONA DE EVENTOS
    =======*/
    $('#btn-filter').on('click',function(){
        getUbicacion();
        getData();
        changeDataTable();
    });
    
    $('#btn-bars').on('click',function(){
        getData('bars');
    });
    
    $('#btn-lines').on('click',function(){
        getData('lines');
    });

    /* ======
        ZONA DE FUNCIONES
    =======*/
    function getUbicacion(){ //obtiene los label de las ubicaciones
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        $.ajax({
            method: "POST",
            url: 'view/ajax.interacciones.php',
            data: {
                action:'getUbicacion',
                dateIni: dateIni,
                dateEnd: dateEnd,
                searchBy: $('#tipo_x').val(),
            },
            async: false
        }).done(function (data) {
            ubicacion = JSON.parse(data);
        });
    }

    function getVisitas(){ //obtiene los datos de visitas
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        $.ajax({
            method: "POST",
            url: 'view/ajax.interacciones.php',
            data: {
                action:'getVisitas',
                dateIni: dateIni,
                dateEnd: dateEnd,
                order: ubicacion,
                searchBy: $('#tipo_x').val(),
            },
            async: false
        }).done(function (data) {
            visitas = JSON.parse(data);
            data_label[0] = 'interacciones';
        });
    }

    function getCompras(){ //obtiene los datos de compras
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        $.ajax({
            method: "POST",
            url: 'view/ajax.interacciones.php',
            data: {
                action:'getCompras',
                dateIni: dateIni,
                dateEnd: dateEnd,
                order: ubicacion,
                searchBy: $('#tipo_x').val(),
            },
            async: false
        }).done(function (data) {
            compras = JSON.parse(data);
            data_label[1] = 'compras';
        });
    }

    function getAbandonedCart(){ //obtiene los datos de compras
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        $.ajax({
            method: "POST",
            url: 'view/ajax.interacciones.php',
            data: {
                action:'getAbandonedCart',
                dateIni: dateIni,
                dateEnd: dateEnd,
                order: ubicacion,
                searchBy: $('#tipo_x').val(),
            },
            async: false
        }).done(function (data) {
            abandonados = JSON.parse(data);
            data_label[2] = 'carritos abandonados';
        });
    }

    function getSaveCart(){ //obtiene los datos de compras
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        $.ajax({
            method: "POST",
            url: 'view/ajax.interacciones.php',
            data: {
                action:'getSaveCart',
                dateIni: dateIni,
                dateEnd: dateEnd,
                order: ubicacion,
                searchBy: $('#tipo_x').val(),
            },
            async: false
        }).done(function (data) {
            guardados = JSON.parse(data);
            data_label[3] = 'carritos guardados';
        });
    }

    function setDataTable(){ //inicializa la tabla de ciudades
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        App.datatables();
        var data_table = [];
        $.ajax({
            method: "POST",
            url: 'view/ajax.interacciones.php',
            data: {
                action:'getDataCiudades',
                searchBy: 'ciudad',
                dateIni: dateIni,
                dateEnd: dateEnd
            },
            async: false
        }).done(function (data) {
            data_table = JSON.parse(data);
        });
        $('#ecom-informe').DataTable({
                responsive: true,
                data: data_table,
                columns: [
                    { title: "Ciudad" },
                    { title: "Interacciones" }
                ],
                lengthMenu: [[10, 20, 30, -1], [10, 20, 30, 'Todas']]
        });
    }

    function changeDataTable(){ //cambia los datos de la tabla al cambiar las fechas
        var data_table = [];
        dateIni = $('#des-range1').val();
        dateEnd = $('#des-range2').val();
        $.ajax({
            method: "POST",
            url: 'view/ajax.interacciones.php',
            data: {
                action:'getDataCiudades',
                searchBy: 'ciudad',
                dateIni: dateIni,
                dateEnd: dateEnd
            },
            async: false
        }).done(function (data) {
            data_table = JSON.parse(data);
        });
        var datatable = $('#ecom-informe').DataTable();
        datatable.clear().draw();
        datatable.rows.add(data_table); // Add new data
        datatable.columns.adjust().draw(); // Redraw the DataTable
    }

    getUbicacion();
    getData();
    setDataTable();

});