/*
 *  Document   : readyProfile.js
 *  Author     : pixelcave
 *  Description: Custom javascript code used in User Profile page
 */

var ReadyProfile = function() {

    return {
        init: function() {
            /* Example effect of an update showing up in Newsfeed */
            var exampleUpdate = $('#newsfeed-update-example');

            setTimeout(function(){
                exampleUpdate.removeClass('display-none').find('> a').addClass('animation-fadeIn');
                exampleUpdate.find('> div').addClass('animation-pullDown');
            }, 1500);
        }
    };
}();
