$(function(){ EcomOrders.init(); });
$(document).ready(function() {
    var table = $('#ecom-notify').DataTable()
    table.destroy();
    $('#ecom-notify').DataTable( {
            "order": [[ 3, "asc" ]]
        } );
} );

$(document).on('click','.reload',function(){
    $(this).find('i').addClass('fa-spin');
    $.ajax({
        url: url_post + 'notify/notify_restore',
        data: {
            manual:true,
        },
        method: 'POST',
        success: function(){
            location.reload();
        }
    });
});

$(document).on('click','.notify-solved',function(){
    var element = $(this);
    $.ajax({
        url: url_post + 'notify/notify_solved/'+$(this).data('id'),
        method: 'POST',
        success: function(data){
            element.addClass('btn-success').removeClass('btn-info').prop('disabled','true');
            //showMessage(data);
            $('.tooltip.top.in').css('display','none !important')
            interval = setInterval(hiddeMessage, 1500);
        }
    });
});

function showMessage(data){
    var datos = JSON.parse(data);
    if(datos.code == 1){
        $('#message').addClass('alert-success').html(datos.text);
        $('.user-'+datos.id).html(datos.user);
    }else{
        $('#message').addClass('alert-danger').html(datos.text);
    }
    $('#message').toggle('slow')
    $('.loading').each(function(){
        if($(this).is(':visible')){
            $(this).toggle('slow');
        }
    });
}

function hiddeMessage() {
    if($('#message').is(':visible')){
        setTimeout(function(){
            $('.functionDisable').attr('disabled',false);
            $('#message').toggle('slow')
        }, 1500);
        clearInterval(interval);
    }
}