$('#actualizarUsuario').on('click',function(e){
    e.preventDefault();
    let active;
    let actualizar = $('#actualizar').val();
    let email = $('#email').val();
    let nombre = $('#nombre').val();
    let pwd = $('#pwd').val();
    let pwd1 = $('#pwd1').val();
    let rol = $('#rol').val();
    let pwdUser = $('#pwdUser').val();
    
    let error = 0;
    
    if($('#active').val() == 'on'){ active = 1; }else{ active = 0; }

    if(pwd != pwd1){ //comprueba contraseñas iguales
        error = 'error contraseñas no coinciden';
        $('#pwd').css('border','1px solid red');
        $('#pwd1').css('border','1px solid red');
    }else{
        $('#pwd').css('border','1px solid #e8e8e8');
        $('#pwd1').css('border','1px solid #e8e8e8');
    }

    if(nombre == '' || email == ''){ //comprueba que no haya campos sin completar que sean necesarios
        error = 'error campos vacios';

        $('#nombre').css('border','1px solid red');
        $('#email').css('border','1px solid red');
    }else{
        $('#nombre').css('border','1px solid #e8e8e8');
        $('#email').css('border','1px solid #e8e8e8');
    }

    if(pwdUser == ''){ //comprueba que no este la pwd actual sin completar
        error = 'Debes indicar tu contraseña para poder guardar los cambios';
        $('#pwdUser').css('border','1px solid red');
    }else{
        $('#pwdUser').css('border','1px solid #e8e8e8');
    }

    if(error==0){
        $(".avisoOpciones").remove();
        $.ajax({
            url: url + 'user/act-user',
            method: 'POST',
            data: {
                actualizar: actualizar,
                active: active,
                email: email,
                nombre: nombre,
                pwd: pwd,
                pwd1: pwd1,
                rol,
                pwdUser: pwdUser,
            },
            success: function(data){
                if($.isNumeric(data)){
                    var a = 'success';
                    var text = 'Usuario actualizado correctamente'
                }else{
                    var a = 'danger';
                    var text = data;
                }
                $("#page-content").prepend('<div class="alert alert-'+a+' avisoOpciones" style="display:none" role="alert">' + text + '</div>');
                $(".avisoOpciones").show('slow');
                if($.isNumeric(data)){
                    setTimeout(function(){
                        location.reload();
                    }, 2000);
                }
            }
        });
    }else{
        $(".avisoOpciones").remove();
        $("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + error + '</div>');
        $(".avisoOpciones").show('slow');
    }
});

$('#CrearUsuario').on('click',function(e){
    e.preventDefault();
    let active;
    let actualizar = $('#actualizar').val();
    let email = $('#email').val();
    let nombre = $('#nombre').val();
    let pwd = $('#pwd').val();
    let pwd1 = $('#pwd1').val();
    let rol = $('#rol').val();
    let pwdUser = $('#pwdUser').val();
    
    let error = 0;
    
    if($('#active').val() == 'on'){ active = 1; }else{ active = 0; }

    if(pwd != pwd1){ //comprueba contraseñas iguales
        error = 'error contraseñas no coinciden';

        $('#pwd').css('border','1px solid red');
        $('#pwd1').css('border','1px solid red');
    }else{
        $('#pwd').css('border','1px solid #e8e8e8');
        $('#pwd1').css('border','1px solid #e8e8e8');
    }

    if(nombre == '' || email == ''){ //comprueba que no haya campos sin completar que sean necesarios
        error = 'error campos vacios';

        $('#nombre').css('border','1px solid red');
        $('#email').css('border','1px solid red');
    }else{
        $('#nombre').css('border','1px solid #e8e8e8');
        $('#email').css('border','1px solid #e8e8e8');
    }

    if(pwdUser == ''){ //comprueba que no este la pwd actual sin completar
        error = 'Debes indicar tu contraseña para poder guardar los cambios';
        $('#pwdUser').css('border','1px solid red');
    }else{
        $('#pwdUser').css('border','1px solid #e8e8e8');
    }

    if(error==0){
        $(".avisoOpciones").remove();
        $.ajax({
            url: url + 'user/add-user',
            method: 'POST',
            data: {
                actualizar: actualizar,
                active: active,
                email: email,
                nombre: nombre,
                pwd: pwd,
                pwd1: pwd1,
                rol,
                pwdUser: pwdUser,
            },
            success: function(data){
                if($.isNumeric(data)){
                    var a = 'success';
                    var text = 'Usuario actualizado correctamente'
                }else{
                    var a = 'danger';
                    var text =  data;
                }
                $("#page-content").prepend('<div class="alert alert-'+a+' avisoOpciones" style="display:none" role="alert">' + text + '</div>');
                $(".avisoOpciones").show('slow');
                if($.isNumeric(data)){
                    setTimeout(function(){
                        window.location.href= url+'user/view-user/'+data;
                    }, 2000);
                }
            }
        });
    }else{
        $(".avisoOpciones").remove();
        $("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + error + '</div>');
        $(".avisoOpciones").show('slow');
    }
});