$('#actualizarPagina').on('click',function(){
    var id = $('#page_id').val();
    var active = $('#page-active').is(':checked');
    var nombre = $('#page-name').val();
    var url = $('#page-url').val();
    // var contenido = getHtml();
    // var css = getCss();
    // var js = getJs();
    var meta_title = $('#page-meta-title').val();
    var meta_key = $('#page-meta-keywords').val();
    var meta_description = $('#page-meta-description').val();
	const meta_robots = $('#page_robots').val();
    if(nombre != '' && url != '' || id==1){
		if (meta_description.length > 250) {
			data_basic = 'La meta descripción es demasiado larga';
		}else{
			$.ajax({
				method: "POST",
				url: '?cf=edit_pages/act-page',
				data: {
					id:id,
					active:active,
					nombre:nombre,
					url:url,
					// contenido:contenido,
					// css:css,
					// js:js,
					meta_title:meta_title,
					meta_key:meta_key,
					meta_description:meta_description,
					meta_robots,
				},
				async: false
			}).done(function (data) {
				data_basic = data;
			});
		}
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Página guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		setTimeout(() => {
			location.href = '?cf=edit_pages/view-page/' + data_basic;
		  }, "2000");
		  
		
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('#guardarPagina').on('click',function(e){
	
    var id = $('#page_id').val();
    var active = $('#page-active').val();
    var nombre = $('#page-name').val();
    var url = $('#page-url').val();
    // var contenido = getHtml();
    // var css = getCss();
    // var js = getJs();
    var meta_title = $('#page-meta-title').val();
    var meta_key = $('#page-meta-keywords').val();
    var meta_description = $('#page-meta-description').val();

    if(nombre != '' && url != ''){
		if (meta_description.length > 250) {
			data_basic = 'La meta descripción es demasiado larga';
		}else{
			$.ajax({
				method: "POST",
				url: '?cf=edit_pages/act-page',
				data: {
					id:id,
					active:active,
					nombre:nombre,
					url:url,
					// contenido:contenido,
					// css:css,
					// js:js,
					meta_title:meta_title,
					meta_key:meta_key,
					meta_description:meta_description,
					meta_robots,
				},
				async: false
			}).done(function (data) {
				data_basic = data;
			});
		}
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Página guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		window.onbeforeunload = null;
		location.href = '?cf=edit_pages/view-page/' + data_basic;
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});

$('.page-name').on('input',function(){
	
	var titulo = $(this).val().toLowerCase().normalize('NFKD').replace(/[^\w\s.-_\/]/g, '').replace(/ /g,'-').replace(/\?/g, '');
	$('#page-url').val(titulo+".php");
});

$('.reading_facility').on('click',function(){
	const id = $('#page_id').val();

	$.ajax({
		method: "POST",
		url: '?cf=edit_pages/reading_facility',
		data: {
			id
		},
		async: false
	}).done(function (data) {
		value = JSON.parse(data)
		$('.reading_facility').text('Comprobar lectura: '+value.text);
		$('.reading_facility').css('backgroundColor',value.color)
		$('.reading_facility').attr('data-original-title', 'El texto tiene una facilidad de lectura de '+value.score+' sobre 100');
	});
})