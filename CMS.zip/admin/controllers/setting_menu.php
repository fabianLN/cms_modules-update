<?php
_auth();

switch ( $action ) {
    //las funciones se encuentran en el modulo de edicion de menu
    case 'refresh':
        $huerfanas = ORM::for_table('menu')->where_raw('id_parent not in (select id from menu) and id_parent != 0')->find_many();
        
        foreach($huerfanas as $huerfana){
            //echo $huerfana->title.'<br>';
            $huerfana->delete();
        }
        break;

    default: 
    
    include(APP_URL.'view/settings_menu_edit.php'); break;
}

?>