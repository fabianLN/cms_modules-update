<?php
_auth();

switch ($action) {
    case 'install':
        $modules = ORM::for_table('admin_modules')->select('name')->find_many();
        $installed = [];

        foreach ($modules as $module) {
            $installed[] = $module->name;
        }

        $module = ORM::for_table('admin_modules')->where_like('file', $_POST['file'])->find_one();
        $data = get_files_local([$_SERVER['DOCUMENT_ROOT'] . '/admin/modules/' . $_POST['file']]);

        if (!$module || $data[0]['version'] > $module->version || $data[0]['version'] == 'Dev') {
            procesarArchivoZip($_POST['file'], true);
            admin_log('Instalado o actualizado el módulo ' . str_replace('.zip', '', $_POST['file']));
            echo json_encode(['code' => 1, 'text' => 'El módulo ha sido instalado correctamente']);
        } else {
            echo json_encode(['code' => 0, 'text' => 'Este módulo ya está instalado']);
        }
        break;

    case 'delete':
        $module = ORM::for_table('admin_modules')->where_like('file', $_POST['file'])->find_one();

        if ($module && $module->borrable == 1) {
            $delete_fields = json_decode($module->files);

            foreach ($delete_fields as $field) { // Elimina los archivos del módulo
                unlink($field);
                if (strpos($field, '/modules') !== false && strpos($field, '/admin/modules') === false) {
                    rmdir(dirname($field));
                }
            }

            $data = procesarArchivoZip($_POST['file'], false);

            if ($module->delete()) {
                admin_log('Borrado o actualizado el módulo ' . str_replace('.zip', '', $_POST['file']));
                echo json_encode(['code' => 1, 'text' => 'El módulo ha sido borrado correctamente']);
            } else {
                echo json_encode(['code' => 0, 'text' => 'No se ha podido borrar el módulo, inténtalo de nuevo']);
            }
        } elseif ($module) {
            echo json_encode(['code' => 0, 'text' => 'No se puede borrar el módulo ya que su uso es necesario']);
        } else {
            echo json_encode(['code' => 0, 'text' => 'No se encuentra el módulo a borrar']);
        }
        break;

    case 'check_update':
        $modules = ORM::for_table('admin_modules')->find_many();
        $updateAvailable = false;
        $errorMessage = '';

        foreach ($modules as $module) {
            if (is_numeric($module->version) && $module->version > 0) {
                $githubZipUrl = $module->update_url;
                $internalVersion = $module->version;
                $fileName = $module->file;

                try {
                    if ($githubZipUrl != '') {
                        if (checkForUpdates($githubZipUrl, $internalVersion, $module->file)) {
                            $updateAvailable = true;
                        }
                    } else {
                        $errorMessage .= 'Error: el módulo ' . $module->file . ' no tiene actualización en la nube. ';
                    }
                } catch (Exception $e) {
                    $errorMessage .= 'Error: ' . $e->getMessage() . ' ';
                    $updateAvailable = false;
                    break;
                }
            }

            // Actualizar el campo last_check
            $module->last_check = date('Y-m-d H:i:s');
            $module->save();
        }

        if ($errorMessage) {
            $return = json_encode(['code' => -1, 'class' => 'alert-danger', 'text' => $errorMessage]);
        } elseif ($updateAvailable) {
            $return = json_encode(['code' => 1, 'class' => 'alert-success', 'text' => 'Hay una actualización disponible.']);
        } else {
            $return = json_encode(['code' => 0, 'class' => 'alert-danger', 'text' => 'No hay actualizaciones disponibles.']);
        }

        echo $return;
        break;

    default:
        $files = get_files_local();
        $modules = ORM::for_table('admin_modules')->select(['name', 'file', 'version', 'borrable'])->find_many();
        $installed = [];
        foreach ($modules as $module) {
            $installed[$module->file] = [
                'version' => $module->version,
                'borrable' => $module->borrable
            ];
        }

        $js_footer = ['modulos'];
        include(APP_URL . 'view/page_modulos.php');
}

function get_files_local($files = '') {
    if ($files == '') {
        $directory = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules';
        $files = glob($directory . '/*.zip'); // Obtener lista de archivos que coincidan con el patrón "*.zip"
        sort($files); // Ordenar la lista de archivos
    }

    $modulos = [];
    foreach ($files as $key => $archivoZip) {
        $zip = new ZipArchive;
        if ($zip->open($archivoZip) === TRUE) {
            $contenidoJson = $zip->getFromName('composer.json');
            if ($contenidoJson !== false) {
                $datosJson = json_decode($contenidoJson, true);
                // Verificar si el JSON tiene la estructura esperada
                if (isset($datosJson['module']) && is_array($datosJson['module'])) {
                    foreach ($datosJson['module'] as $modulo) {
                        // Agregar el nombre del módulo a la lista
                        $modulos[$key]['name'] = $modulo['name'];
                        $modulos[$key]['file'] = $archivoZip;
                        $modulos[$key]['description'] = $modulo['description'];
                        $modulos[$key]['version'] = $modulo['version'];
                        $modulos[$key]['file'] = basename($archivoZip);
                    }
                }
            }
            $zip->close();
        }
    }

    return $modulos;
}

function procesarArchivoZip($nombreArchivo, $install) {
    // Carpeta predefinida donde buscar el archivo
    $carpetaOrigen = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules/';

    // Ruta temporal para extraer los archivos
    $rutaTemporal = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules/temp/';
    
    // Ruta del autoload.json de los modulos del front
    $rutaAutoload = $_SERVER['DOCUMENT_ROOT'] . '/modules/autoload.json';

    // Extraer el archivo ZIP
    $zip = new ZipArchive;
    if ($zip->open($carpetaOrigen . $nombreArchivo) === TRUE) {
        $zip->extractTo($rutaTemporal);
        $zip->close();
    } else {
        die('Error al abrir el archivo ZIP');
    }

    // Array para almacenar las ubicaciones de los archivos
    $ubicaciones = [];

    if ($install) {
        try {
            // Recorrer las carpetas internas de la carpeta temporal
            $carpetasInternas = scandir($rutaTemporal);
            foreach ($carpetasInternas as $carpeta) {
                switch ($carpeta) {
                    case 'composer.json':
                        $contenido = file_get_contents($rutaTemporal . $carpeta);
                        $contenidoArray = json_decode($contenido, true);
                        $requisitos = test_requires($contenidoArray['module'][0]['require']);
                        if (!is_numeric($requisitos)) {
                            echo 'El módulo no se ha podido instalar porque no se cumple algún requisito: ' . $requisitos;
                            exit;
                        }
                        // Leer el contenido actual del archivo JSON
                        $json = file_get_contents($rutaAutoload);

                        // Decodificar el JSON en un array asociativo
                        $data = json_decode($json, true);

                        // Buscar el índice del módulo en el array de modules
                        $index = array_search($contenidoArray['module'][0]['name'], array_column($data['modules'], 'name'));

                        if ($index !== false) {
                            // Si se encuentra el módulo, actualizar del array
                            $data['modules'][$index] = $contenidoArray['module'][0];
                        } else {
                            // Agregar el nuevo array al final del array existente
                            $data['modules'] = array_merge($data['modules'], $contenidoArray['module']);
                        }

                        // Codificar el array actualizado a JSON
                        $jsonUpdated = json_encode($data, JSON_PRETTY_PRINT);

                        // Escribir el JSON en el archivo
                        file_put_contents($rutaAutoload, $jsonUpdated);
                        break;
                    case 'autoload.php':
                        // Hacer las funciones que traiga el fichero
                        include_once($rutaTemporal . $carpeta);
                        $module_db = new bbdd_update(); 
                        $module_db->update_database();
                        $borrable = method_exists('bbdd_update', 'delete_database');
                        break;
                    
                    default:
                        // Llamar a la función principal para iniciar la recursión
                        if ($carpeta != '.' && $carpeta != '..' && $carpeta != '__MACOSX' && $carpeta != '.git') {
                            $rutaOrigen = $rutaTemporal . $carpeta;
                            $rutaDestino = $_SERVER['DOCUMENT_ROOT'] . '/';
                            moverArchivos($rutaOrigen, $rutaDestino, $ubicaciones);
                        }
                }
            }
            ORM::for_table('admin_modules')->create([
                'name' => $contenidoArray['module'][0]['name'],
                //'description' => $contenidoArray['module'][0]['description'],
                'update_url' => $contenidoArray['module'][0]['dist']['url'],
                'version' => $contenidoArray['module'][0]['version'],
                'file' => $nombreArchivo,
                'borrable' => $borrable,
                'files' => json_encode($ubicaciones),
                //'status' => 1,
                //'user' => $_SESSION['user_id'],
                //'date' => date('Y-m-d H:i:s'),
            ])->save();
        } catch (Exception $e) {
            $error = $e->getMessage();
            echo $error;
            exit;
            return 'Error al procesar el archivo ZIP: ' . $error;
        }
    } else {
        // Recorrer las carpetas internas de la carpeta temporal
        $carpetasInternas = scandir($rutaTemporal);
        foreach ($carpetasInternas as $carpeta) {
            switch ($carpeta) {
                case 'composer.json':
                    $contenido = file_get_contents($rutaTemporal . $carpeta);
                    $contenidoArray = json_decode($contenido, true);

                    // Leer el contenido actual del archivo JSON
                    $json = file_get_contents($rutaAutoload);

                    // Decodificar el JSON en un array asociativo
                    $data = json_decode($json, true);

                    // Buscar el índice del módulo en el array de modules
                    $index = array_search($contenidoArray['module'][0]['name'], array_column($data['modules'], 'name'));

                    if ($index !== false) {
                        // Si se encuentra el módulo, eliminarlo del array
                        unset($data['modules'][$index]);
                    }

                    // Reindexar el array para eliminar los índices vacíos
                    $data['modules'] = array_values($data['modules']);

                    // Codificar el array actualizado a JSON
                    $jsonUpdated = json_encode($data, JSON_PRETTY_PRINT);

                    // Escribir el JSON en el archivo
                    file_put_contents($rutaAutoload, $jsonUpdated);
                    break;
                case 'autoload.php':
                    //hacer las funciones que traiga el fichero
                    include_once($rutaTemporal.$carpeta);
                    $module_db = new bbdd_update;
                    $module_db::delete_database();
                    break;
                
                
                default:
                    break;
            }
        }
    }

    // Eliminar la carpeta temporal
    eliminarCarpetaTemporal($rutaTemporal);
    mkdir($rutaTemporal);

    return $ubicaciones;
}

// Funcion para eliminar la carpeta temporal y su contenido
function eliminarCarpetaTemporal($rutaTemporal) {
    $archivos = scandir($rutaTemporal);
    foreach ($archivos as $archivo) {
        if ($archivo != '.' && $archivo != '..') {
            $rutaArchivo = $rutaTemporal . $archivo;
            if (is_dir($rutaArchivo)) {
                eliminarCarpetaTemporal($rutaArchivo . '/');
            } else {
                unlink($rutaArchivo);
            }
        }
    }
    rmdir($rutaTemporal);
}

function moverArchivos($rutaOrigen, $rutaDestinoBase, &$ubicaciones, $rutaOrigenBaseParaCalculo = null) {
    // Si es la primera llamada, $rutaOrigenBaseParaCalculo será null.
    // Lo establecemos como la ruta que se va a "reemplazar" para obtener la relativa.
    // En tu ejemplo, si el origen es '/home/s06549a2/public_html/cms/admin/modules/temp/admin/assets/js/blog_category.js'
    // y quieres que 'admin/assets/js/' aparezca en el destino, la base para el cálculo debería ser
    // '/home/s06549a2/public_html/cms/admin/modules/temp/'
    if ($rutaOrigenBaseParaCalculo === null) {
        // En este punto, $rutaOrigen es la ruta completa inicial (ej. '/home/s06549a2/public_html/cms/admin/modules/temp/admin/assets/js')
        // Necesitamos la parte que no queremos que aparezca en el destino, es decir, todo hasta 'temp/'
        // Asumiendo que $rutaOrigen siempre contendrá el patrón 'temp/admin/'
        // Podemos buscar la última aparición de 'temp/' y tomar todo lo anterior.
        $posTemp = strrpos($rutaOrigen, 'temp/');
        if ($posTemp !== false) {
            $rutaOrigenBaseParaCalculo = substr($rutaOrigen, 0, $posTemp + strlen('temp/'));
        } else {
            // Si 'temp/' no se encuentra, usamos la ruta de origen completa como base
            // Esto podría significar que no se perdería nada, o se perdería algo más
            // dependiendo de la estructura de la ruta.
            $rutaOrigenBaseParaCalculo = $rutaOrigen;
        }
    }


    // Verificar si la ruta de origen es válida
    if (!is_dir($rutaOrigen)) {
        return;
    }

    // Obtener todos los archivos y carpetas en la ruta de origen
    $archivos = scandir($rutaOrigen);

    // Recorrer cada archivo y carpeta
    foreach ($archivos as $archivo) {
        // Ignorar los directorios "." y ".."
        if ($archivo != "." && $archivo != "..") {
            // Ruta completa del archivo de origen actual
            $rutaArchivoOrigen = $rutaOrigen . '/' . $archivo;

            // --- CAMBIO CLAVE EN EL CÁLCULO DE LA RUTA RELATIVA ---
            // Calcular la parte de la ruta que es relativa a $rutaOrigenBaseParaCalculo.
            // Esto debería darnos 'admin/assets/js/blog_category.js'
            $rutaRelativa = ltrim(str_replace($rutaOrigenBaseParaCalculo, '', $rutaArchivoOrigen), '/');

            // Construir la ruta de destino completa usando la $rutaDestinoBase original
            // y la ruta relativa calculada.
            $rutaArchivoDestino = rtrim($rutaDestinoBase, '/') . '/' . $rutaRelativa;
            // --- FIN DEL CAMBIO CLAVE ---


            // Verificar si es un archivo o una carpeta
            if (is_file($rutaArchivoOrigen)) {
                // Asegurarse de que el directorio de destino exista antes de mover el archivo
                $directorioDestino = dirname($rutaArchivoDestino);
                if (!is_dir($directorioDestino)) {
                    mkdir($directorioDestino, 0777, true); // Crea directorios recursivamente
                }

                // Mover el archivo a la ubicación de destino
                rename($rutaArchivoOrigen, $rutaArchivoDestino);
                $ubicaciones[] = $rutaArchivoDestino; // Agregar la ubicación del archivo al array
            } elseif (is_dir($rutaArchivoOrigen)) {
                // Crear la carpeta de destino si no existe
                if (!is_dir($rutaArchivoDestino)) {
                    mkdir($rutaArchivoDestino, 0777, true); // Crea directorios recursivamente
                }

                // Llamar recursivamente a la función para mover archivos dentro de la carpeta
                // Pasamos la misma $rutaDestinoBase y $rutaOrigenBaseParaCalculo para mantener la referencia
                moverArchivos($rutaArchivoOrigen, $rutaDestinoBase, $ubicaciones, $rutaOrigenBaseParaCalculo);

                // Eliminar la carpeta de origen si está vacía
                $itemsEnCarpetaOrigen = array_diff(scandir($rutaArchivoOrigen), array('.', '..'));
                if (empty($itemsEnCarpetaOrigen)) {
                    rmdir($rutaArchivoOrigen);
                }
            }
        }
    }
}

function test_requires($requires) {
    foreach ($requires as $name => $version) {
        if ($name == 'php') {
            $version = str_replace(">=", '', $version);
            if (version_compare(PHP_VERSION, $version, '<')) {
                return 'El servidor necesita PHP ' . $version . ' o superior';
            }
        } elseif ($name == 'phpmailer') {
            if (class_exists('PHPMailer')) {
                return 'La clase PHPmailer ya existe';
            }
        } elseif ($name == 'openssl') {
            if (!extension_loaded('openssl')) {
                return 'El servidor necesita la extensión OpenSSL';
            }
        } elseif ($name == 'curl') {
            if (!function_exists('curl_init')) {
                return 'El servidor necesita la extensión cURL';
            }
        } elseif ($name == 'pdo') {
            if (!defined('PDO::ATTR_DRIVER_NAME')) {
                return 'El servidor necesita la extensión PDO';
            }
        }
    }
    return 1;
}

function checkForUpdates($githubZipUrl, $internalVersion, $fileName) {
    $file_path = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules/' . $fileName;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $githubZipUrl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $githubZip = curl_exec($curl);
    curl_close($curl);

    if ($githubZip) {
        $tempFile = tempnam(sys_get_temp_dir(), 'module_') . '.zip';
        file_put_contents($tempFile, $githubZip);

        $zip = new ZipArchive;
        if ($zip->open($tempFile) === TRUE) {
            $contenidoJson = $zip->getFromName('composer.json');
            $zip->close();

            if ($contenidoJson !== false) {
                $datosJson = json_decode($contenidoJson, true);
                $githubVersion = $datosJson['module'][0]['version'];
                if ($internalVersion < $githubVersion || $githubVersion == 'Dev') {
                    unlink($file_path);
                    copy($tempFile, $file_path);
                    unlink($tempFile);
                    return true;
                }
            }
        }

        unlink($tempFile);
    }

    return false;
}

?>
