<?php
_auth();

switch ( $action ) {

    case 'install':
        $modules = ORM::for_table( 'admin_modules' )->select('name')->find_many();
        foreach ($modules as $key => $module) {
            $installed[$key] = $module->name;
        }

        $module = ORM::for_table( 'admin_modules' )->where_like('file',$_POST['file'])->find_one();
        $data = get_files_local(array($_SERVER['DOCUMENT_ROOT'] . '/admin/modules/' . $_POST['file']));

        if(count($module) == 0 || $data[0]['version'] > $module->version || $data[0]['version'] == 'Dev'){
            procesarArchivoZip($_POST['file'],true);
            admin_log('Instalado o actualizado el módulo '.str_replace('.zip','',$_POST['file']));
            echo json_encode(array('code'=>1,'text'=>'El módulo ha sido instalado correctamente'));
        }else{
            echo json_encode(array('code'=>0,'text'=>'Este módulo ya está instalado'));
        }
        break;
    case 'delete':
        $module = ORM::for_table( 'admin_modules' )->where_like('file',$_POST['file'])->find_one();
        
        if($module->borrable == 1){
            $delete_fields = json_decode($module->files);

            foreach ($delete_fields as $field) { //elimina los archivos del modulo
                unlink($field);
                if(is_numeric(strpos($field,'/modules')) && !is_numeric(strpos($field,'/admin/modules'))){
                    rmdir(dirname($field));
                }
            }

            $data = procesarArchivoZip($_POST['file'],false);

            if($module->delete()){
                admin_log('Borrado o actualizado el módulo '.str_replace('.zip','',$_POST['file']));
                echo json_encode(array('code'=>1,'text'=>'El módulo ha sido borrado correctamente'));
            }else{
                echo json_encode(array('code'=>0,'text'=>'No se ha podido borrar el módulo, inténtalo de nuevo'));
            }
        }elseif(count($module) > 0){
            echo json_encode(array('code'=>0,'text'=>'No se puede borrar el módulo ya que su uso es necesario'));
        }else{
            echo json_encode(array('code'=>0,'text'=>'No se encuentra el módulo a borrar'));
        }
        break;
    case 'check_update':
            $modules = ORM::for_table('admin_modules')->find_many();
            $updateAvailable = false;
            $errorMessage = '';
        
            foreach ($modules as $module) {
                if (is_numeric($module->version) && $module->version > 0) {
                    $githubZipUrl = $module->update_url;
                    $internalVersion = $module->version;
                    $fileName = $module->file;
        
                    try {
                        if($githubZipUrl != ''){
                            if (checkForUpdates($githubZipUrl, $internalVersion, $module->file)) {
                                $updateAvailable = true;
                            }
                        }else{
                            $errorMessage .= 'Error: el módulo '.$module->file.' no tiene actualización en la nube. ';
                        }
                    } catch (Exception $e) {
                        $errorMessage .= 'Error: ' . $e->getMessage().' ';
                        $updateAvailable = false;
                        break;
                    }
                }
        
                // Actualizar el campo last_check
                $module->last_check = date('Y-m-d H:i:s');
                $module->save();
            }
        
            if ($errorMessage) {
                $return = json_encode(array('code' => -1, 'class' =>'alert-danger', 'text' => $errorMessage));
            } elseif ($updateAvailable) {
                $return = json_encode(array('code' => 1, 'class' =>'alert-success', 'text' => 'Hay una actualización disponible.'));
            } else {
                $return = json_encode(array('code' => 0, 'class' =>'alert-danger', 'text' => 'No hay actualizaciones disponibles.'));
            }
        
            echo $return;
            break;

	default:
        $files = get_files_local();
        $modules = ORM::for_table( 'admin_modules' )->select(array('name','file','version','borrable'))->find_many();
        foreach ($modules as $key => $module) {
            $installed[$module->file]['version'] = $module->version;
            $installed[$module->file]['borrable'] = $module->borrable;
        }

        $js_footer = array('modulos');
		include(APP_URL.'view/page_modulos.php');
}

function get_files_local($files = '') {
    if($files == ''){
        $directory = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules';
        $files = glob($directory . '/*.zip'); // Obtener lista de archivos que coincidan con el patrón "*.zip"
        sort($files); // Ordenar la lista de archivos
    }

    $modulos = [];
    foreach ($files as $key => $archivoZip) {
        $zip = new ZipArchive;
        if ($zip->open($archivoZip) === TRUE) {
            $contenidoJson = $zip->getFromName('composer.json');
            if ($contenidoJson !== false) {
                $datosJson = json_decode($contenidoJson, true);
                // Verificar si el JSON tiene la estructura esperada
                if (isset($datosJson['module']) && is_array($datosJson['module'])) {
                    foreach ($datosJson['module'] as $modulo) {
                        // Agregar el nombre del módulo a la lista
                        $modulos[$key]['name'] = $modulo['name'];
                        $modulos[$key]['file'] = $archivoZip;
                        $modulos[$key]['description'] = $modulo['description'];
                        $modulos[$key]['version'] = $modulo['version'];
                        $modulos[$key]['file'] = basename($archivoZip);
                    }
                }
            }
            $zip->close();
        }
    }

    return $modulos;
}

function procesarArchivoZip($nombreArchivo,$install) {
    // Carpeta predefinida donde buscar el archivo
    $carpetaOrigen = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules/';

    // Ruta temporal para extraer los archivos
    $rutaTemporal = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules/temp/';
    
    // Ruta del autoload.json de los modulos del front
    $rutaAutoload = $_SERVER['DOCUMENT_ROOT'] . '/modules/autoload.json';

    // Extraer el archivo ZIP
    $zip = new ZipArchive;
    if ($zip->open($carpetaOrigen . $nombreArchivo) === TRUE) {
        $zip->extractTo($rutaTemporal);
        $zip->close();
    } else {
        die('Error al abrir el archivo ZIP');
    }

    // Array para almacenar las ubicaciones de los archivos
    $ubicaciones = [];

    if($install){
        // Recorrer las carpetas internas de la carpeta temporal
        $carpetasInternas = scandir($rutaTemporal);
        foreach ($carpetasInternas as $carpeta) {
            switch ($carpeta) {
                case 'composer.json':
                    $contenido = file_get_contents($rutaTemporal . $carpeta);
                    $contenidoArray = json_decode($contenido, true);
                    $requisitos = test_requires($contenidoArray['module'][0]['require']);
                    if(!is_numeric($requisitos)){
                        echo 'El módulo no se ha podido instalar porque no se cumple algún requisito: '.$requisitos;
                        exit;
                    }
                    // Leer el contenido actual del archivo JSON
                    $json = file_get_contents($rutaAutoload);

                    // Decodificar el JSON en un array asociativo
                    $data = json_decode($json, true);

                    // Buscar el índice del módulo en el array de modules
                    $index = array_search($contenidoArray['module'][0]['name'], array_column($data['modules'], 'name'));

                    if ($index) {
                        // Si se encuentra el módulo, actualizar del array
                        $data['modules'][$index] = $contenidoArray['module'][0];
                    }else{
                        // Agregar el nuevo array al final del array existente
                        $data['modules'] = array_merge($data['modules'], $contenidoArray['module']);
                    }

                    // Codificar el array actualizado a JSON
                    $jsonUpdated = json_encode($data, JSON_PRETTY_PRINT);

                    // Escribir el JSON en el archivo
                    file_put_contents($rutaAutoload, $jsonUpdated);
                    break;
                case 'autoload.php':
                    //hacer las funciones que traiga el fichero
                    include_once($rutaTemporal.$carpeta);
                    $module_db = new bbdd_update;
                    $module_db::update_database();
                    $borrable = method_exists('bbdd_update','delete_database');
                    break;
                
                default:
                    // Llamar a la función principal para iniciar la recursión
                    if($carpeta != '.' && $carpeta != '..' && $carpeta != 'README.md'){
                        $ubicaciones = array_merge($ubicaciones, moverArchivos($rutaTemporal));
                    }
                    break;
            }
        }

        // Guardar las ubicaciones de los archivos en un archivo JSON
        $jsonUbicaciones = json_encode($ubicaciones);

        $module = ORM::for_table( 'admin_modules' )->where_like('name',$contenidoArray['module'][0]['name'])->find_one();
        if (!$module) {
            $module = ORM::for_table( 'admin_modules' )->create();
            $module->name = $contenidoArray['module'][0]['name'];
        }
        $module->file = $nombreArchivo;
        $module->version = ($contenidoArray['module'][0]['version'] == 'Dev')? 0 : $contenidoArray['module'][0]['version'];
        $module->update_url = ($contenidoArray['module'][0]['dist']['url'] == 'Dev')? '' : $contenidoArray['module'][0]['dist']['url'];
        $module->files = $jsonUbicaciones;
        $module->borrable = $borrable;
        $module->save();
    }else{
        // Recorrer las carpetas internas de la carpeta temporal
        $carpetasInternas = scandir($rutaTemporal);
        foreach ($carpetasInternas as $carpeta) {
            switch ($carpeta) {
                case 'composer.json':
                    $contenido = file_get_contents($rutaTemporal . $carpeta);
                    $contenidoArray = json_decode($contenido, true);
                    // Leer el contenido actual del archivo JSON
                    $json = file_get_contents($rutaAutoload);
                
                    // Decodificar el JSON en un array asociativo
                    $data = json_decode($json, true);
                
                    // Buscar el índice del módulo en el array de modules
                    $index = array_search($contenidoArray['module'][0], $data['modules']);

                    // Si se encuentra el módulo, eliminarlo del array
                    if ($index !== false) {
                        unset($data['modules'][$index]);
                    }
                
                    // Codificar el array actualizado a JSON
                    $jsonUpdated = json_encode($data, JSON_PRETTY_PRINT);
                
                    // Escribir el JSON en el archivo
                    file_put_contents($rutaAutoload, $jsonUpdated);
                    break;
                case 'autoload.php':
                    //hacer las funciones que traiga el fichero
                    include_once($rutaTemporal.$carpeta);
                    $module_db = new bbdd_update;
                    $module_db::delete_database();
                    break;
                
                
                default:
                    break;
            }
        }
    }


    // Eliminar la carpeta temporal
    eliminarCarpetaTemporal($rutaTemporal);
    mkdir($rutaTemporal);
}

// Funcion para eliminar la carpeta temporal y su contenido
function eliminarCarpetaTemporal($rutaTemporal) {
    $archivos = scandir($rutaTemporal);
    foreach ($archivos as $archivo) {
        if ($archivo != '.' && $archivo != '..') {
            $rutaArchivo = $rutaTemporal . $archivo;
            if (is_dir($rutaArchivo)) {
                eliminarCarpetaTemporal($rutaArchivo . '/');
            } else {
                unlink($rutaArchivo);
            }
        }
    }
    rmdir($rutaTemporal);
}

// Comprueba los requisitos del modulo
function test_requires($requires){
    global $installed;
    $return = 1;
    foreach ($requires as $key => $require) {
        switch ($key) {
            case 'php':
                if (!verificarVersionPHP($require)) {
                    $retunr .= '<br> - La versión php requerida es distinta a la disponible';
                }
                break;
            case 'modules':
                //comprobar si estan en la bbdd los modulos que necesita
                foreach ($require as $module) {
                    if(!in_array($module,$installed)){
                        $return .= '<br> - El modulo '.$module.' es requerido para la instalación';
                    }
                }
                break;
            
            default:
                $return .= '<br> - Error inesperado al comprobar los requisitos';
                break;
        }
    }
    return $return;
}

function moverArchivos($rutaTemporal, $carpeta = '') {
    $ubicaciones = [];

    // Verificar si la ruta es una carpeta y si es accesible
    if (is_dir($rutaTemporal . $carpeta)) {
        // Escanear la carpeta
        $archivos = scandir($rutaTemporal . $carpeta);
        
        // Recorrer los archivos y carpetas dentro de la carpeta
        foreach ($archivos as $archivo) {
            // Ignorar las referencias a la carpeta actual y la carpeta padre
            if ($archivo != '.' && $archivo != '..' && $archivo != 'composer.json' && $archivo != 'autoload.php' && $archivo != 'README.md') {
                // Construir la ruta completa del archivo o carpeta
                $rutaArchivo = $rutaTemporal . $carpeta . '/' . $archivo;

                // Si es una carpeta, llamar recursivamente a esta función
                if (is_dir($rutaArchivo)) {
                    // Mover archivos dentro de la carpeta recursivamente
                    $ubicaciones = array_merge($ubicaciones, moverArchivos($rutaTemporal, $carpeta . '/' . $archivo));
                } else {
                    // Si es un archivo, moverlo a su destino final
                    if($carpeta !== ''){
                        $ubicacionDestino = $_SERVER['DOCUMENT_ROOT'] . $carpeta . '/' . $archivo;
                        // Verificar si la carpeta de destino existe, si no, crearla
                        if (!is_dir(dirname($ubicacionDestino))) {
                            mkdir(dirname($ubicacionDestino), 0777, true);
                        }

                        rename($rutaArchivo, $ubicacionDestino);
                        $ubicaciones[$carpeta . '/' . $archivo] = $ubicacionDestino;
                    }
                }
            }
        }

        // Eliminar la carpeta interna vacía después de mover todos los archivos
        if($carpeta != ''){
            rmdir($rutaTemporal . ltrim($carpeta, '/'));
        }
    }

    return $ubicaciones;
}

function verificarVersionPHP($requisito) {
    // Obtiene la versión actual de PHP
    $version_php = phpversion();
    
    // Divide el requisito en partes separadas por "||"
    $requisitos = explode('||', $requisito);
    
    // Itera sobre cada requisito y verifica si la versión cumple con alguno
    foreach ($requisitos as $req) {
        // Elimina los espacios en blanco al principio y al final
        $req = trim($req);
        // Verifica si la versión cumple con el requisito actual
        if (version_compare($version_php, str_replace('^', '', $req), '>=')) {
            return true;
        }
    }
    
    // Si ninguno de los requisitos se cumple, devuelve false
    return false;
}


//comprobar actualizaciones pendientes
function checkForUpdates($githubZipUrl, $internalVersion, $fileName) {
    // Directorio temporal para almacenar el archivo ZIP descargado
    $tempDir = sys_get_temp_dir();
    $tempZipFile = tempnam($tempDir, 'module_update_') . '.zip';
    $extractPath = $tempDir . '/' . uniqid('module_', true);

    try {
        // Descargar el archivo ZIP desde la URL de GitHub
        $download = file_put_contents($tempZipFile, fopen($githubZipUrl, 'r'));
        if ($download === false) {
            throw new Exception('Error al descargar el archivo desde GitHub.');
        }

        // Crear una instancia de ZipArchive y abrir el archivo ZIP descargado
        $zip = new ZipArchive;
        if ($zip->open($tempZipFile) === TRUE) {
            mkdir($extractPath);
            $zip->extractTo($extractPath);
            $zip->close();
        } else {
            throw new Exception('No se pudo abrir el archivo ZIP descargado.');
        }

        // Leer la versión del módulo desde el archivo composer.json
        $composerFilePath = $extractPath . '/composer.json';
        if (!file_exists($composerFilePath)) {
            throw new Exception('El archivo composer.json no se encuentra en el ZIP descargado del módulo ' . $fileName . '.');
        }

        $composerData = json_decode(file_get_contents($composerFilePath), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Error al decodificar composer.json: ' . json_last_error_msg());
        }

        if (isset($composerData['module'][0]['version'])) {
            $zipVersion = $composerData['module'][0]['version'];

            // Comparar la versión del módulo interno con la del archivo ZIP
            if (version_compare($zipVersion, $internalVersion, '>')) {
                // La versión del ZIP es mayor, hay una actualización disponible
                $destinationPath = $_SERVER['DOCUMENT_ROOT'] . '/admin/modules/' . $fileName;
                if (rename($tempZipFile, $destinationPath)) {
                    return true;
                } else {
                    throw new Exception('No se pudo mover el nuevo archivo ZIP a la ruta de destino.');
                }
            }
            // Si la versión no es mayor, no hay actualización
            return false;
        } else {
            throw new Exception('No se encontró la versión en el archivo composer.json.');
        }
    } catch (Exception $e) {
        throw new Exception('Error en checkForUpdates: ' . $e->getMessage());
    } finally {
        // Limpiar archivos temporales
        @unlink($tempZipFile);
        if (is_dir($extractPath)) {
            array_map('unlink', glob("$extractPath/*.*"));
            rmdir($extractPath);
        }
    }
}

?>