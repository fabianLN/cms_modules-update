<?php
_auth();

switch ( $action ) {
    case 'sitemap_generator':
		always_active();

		//generarSitemap($_SERVER['HTTP_ORIGIN'],$_POST['changefreq'],get_setting('sitemap_images'),get_setting('sitemap_videos'));
        //generarSitemap($_SERVER['HTTP_ORIGIN'], $_POST['changefreq'], false, false);
        include_once(APP_URL . 'microservices/sitemap.php');

        // Ejemplo de uso
        $startUrl = $_SERVER['HTTP_ORIGIN'];
        $changeFreq = $_POST['changefreq'];
        $includeMedia = get_setting('sitemap_images');
        $paginationVar = 'p';
        generateSitemap($startUrl, $changeFreq, $includeMedia, $paginationVar);

        admin_log('SiteMap actualizado');
		$arr = array('code' => 1, 'text' => 'SiteMap generado correctamente');
		echo json_encode($arr);
		break;

	default:
        $files = get_files_local();

        $js_footer = array('sitemap');
		include(APP_URL.'view/page_sitemap.php');
}

function get_files_local() {
    $directory = $_SERVER['DOCUMENT_ROOT'];
    $files = glob($directory . '/sitemap*'); // Obtener lista de archivos que coincidan con el patrón "sitemap*"
    sort($files); // Ordenar la lista de archivos
    return $files;
}

function always_active(){
    ignore_user_abort(true);
    @ini_set('memory_limit', '10000M');
    @date_default_timezone_set('Europe/Madrid');
    set_time_limit(0);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(1);
}

/*function generarSitemap($urlSitio, $changefreq = 'Daily', $incluyeImagenes = false, $incluyeVideos = false) {
    // Configuración del sitemap
    $numUrlsMax = 50000;
    $tamMax = 50000000; // en bytes (50 MB)
    $prioridadInicial = 1.0; // Prioridad inicial para las URL de nivel superior

    // Obtener la fecha actual
    $fechaActual = date('Y-m-d');

    // Función para obtener la profundidad de una URL
    function obtenerProfundidad($url) {
        return substr_count($url, '/') - 2; // Restar 2 para excluir el esquema (http://) y el dominio
    }

    // Función para calcular la prioridad en función de la profundidad
    function calcularPrioridad($profundidad, $prioridadInicial) {
        return max($prioridadInicial - ($profundidad * 0.1), 0.1); // Disminuir la prioridad en función de la profundidad
    }

    // Función para convertir URL relativa a absoluta
    function urlAbsoluta($url, $urlBase) {
        if (filter_var($url, FILTER_VALIDATE_URL) !== false) {
            return $url; // La URL ya es absoluta
        }
        $parts = parse_url($urlBase);
        return $parts['scheme'] . '://' . $parts['host'] . '/' . ltrim($url, '/');
    }

    // Función para obtener todas las URL internas de una página
    function obtenerUrlsInternas($urlSitio) {
        $html = file_get_contents($urlSitio);
        preg_match_all('/<a\s+href=["\']([^"\']+)["\']/i', $html, $matches);
        $enlaces = $matches[1];

        $urlsInternas = [];
        foreach ($enlaces as $enlace) {
            if (strpos($enlace, '#') === false && strpos($enlace, 'mailto:') === false && strpos($enlace, 'tel:') === false) {
                if (strpos($enlace, 'http') !== 0) {
                    $enlace = rtrim($urlSitio, '/') . '/' . ltrim($enlace, '/');
                }
                $urlsInternas[] = $enlace;
            }
        }
        return array_unique($urlsInternas);
    }

    // Función para obtener las imágenes de una página
    function obtenerImagenes($urlSitio) {
        $html = file_get_contents($urlSitio);
        preg_match_all('/<img\s+.*?src=["\']([^"\']+)["\']/i', $html, $imgMatches);
        return $imgMatches[1];
    }

    // Función para obtener los videos de una página
    function obtenerVideos($urlSitio) {
        $html = file_get_contents($urlSitio);
        preg_match_all('/<video\s+.*?src=["\']([^"\']+)["\']/i', $html, $videoMatches);
        return $videoMatches[1];
    }

    // Comenzar a generar el contenido del sitemap
    $sitemapContent = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $sitemapContent .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"';
    if ($incluyeImagenes) {
        $sitemapContent .= ' xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"';
    }
    if ($incluyeVideos) {
        $sitemapContent .= ' xmlns:video="http://www.google.com/schemas/sitemap-video/1.1"';
    }
    $sitemapContent .= '>' . "\n";

    // Agregar la URL principal al sitemap
    $sitemapContent .= "\t<url>\n";
    $sitemapContent .= "\t\t<loc>{$urlSitio}</loc>\n";
    $sitemapContent .= "\t\t<lastmod>{$fechaActual}</lastmod>\n";
    $sitemapContent .= "\t\t<changefreq>$changefreq</changefreq>\n";
    $sitemapContent .= "\t\t<priority>{$prioridadInicial}</priority>\n";
    if ($incluyeImagenes) {
        $imagenes = obtenerImagenes($urlSitio);
        foreach ($imagenes as $imagen) {
            $imagenAbsoluta = urlAbsoluta($imagen, $urlSitio);
            $sitemapContent .= "\t\t<image:image>\n";
            $sitemapContent .= "\t\t\t<image:loc>{$imagenAbsoluta}</image:loc>\n";
            $sitemapContent .= "\t\t</image:image>\n";
        }
    }
    if ($incluyeVideos) {
        $videos = obtenerVideos($urlSitio);
        foreach ($videos as $video) {
            $videoAbsoluto = urlAbsoluta($video, $urlSitio);
            $sitemapContent .= "\t\t<video:video>\n";
            $sitemapContent .= "\t\t\t<video:content_loc>{$videoAbsoluto}</video:content_loc>\n";
            // Aquí podrías agregar más información del video si es necesario
            $sitemapContent .= "\t\t</video:video>\n";
        }
    }
    $sitemapContent .= "\t</url>\n";

    // Obtener todas las URL internas del sitio
    $urlsInternas = obtenerUrlsInternas($urlSitio);

    // Agregar las URL internas al sitemap
    foreach ($urlsInternas as $url) {
        // Verificar si la URL interna pertenece al mismo dominio
        if (strpos($url, $urlSitio) === 0) {
            $profundidad = obtenerProfundidad($url);
            $prioridad = calcularPrioridad($profundidad, $prioridadInicial);

            // Agregar el enlace al sitemap
            $sitemapContent .= "\t<url>\n";
            $sitemapContent .= "\t\t<loc>{$url}</loc>\n";
            $sitemapContent .= "\t\t<lastmod>{$fechaActual}</lastmod>\n";
            $sitemapContent .= "\t\t<changefreq>daily</changefreq>\n";
            $sitemapContent .= "\t\t<priority>{$prioridad}</priority>\n";
            if ($incluyeImagenes) {
                $imagenes = obtenerImagenes($url);
                foreach ($imagenes as $imagen) {
                    $imagenAbsoluta = urlAbsoluta($imagen, $urlSitio);
                    $sitemapContent .= "\t\t<image:image>\n";
                    $sitemapContent .= "\t\t\t<image:loc>{$imagenAbsoluta}</image:loc>\n";
                    $sitemapContent .= "\t\t</image:image>\n";
                }
            }
            if ($incluyeVideos) {
                $videos = obtenerVideos($url);
                foreach ($videos as $video) {
                    $videoAbsoluto = urlAbsoluta($video, $urlSitio);
                    $sitemapContent .= "\t\t<video:video>\n";
                    $sitemapContent .= "\t\t\t<video:content_loc>{$videoAbsoluto}</video:content_loc>\n";
                    // Aquí podrías agregar más información del video si es necesario
                    $sitemapContent .= "\t\t</video:video>\n";
                }
            }
            $sitemapContent .= "\t</url>\n";
        }
    }

    $sitemapContent .= '</urlset>';

    // Guardar el sitemap en un archivo
    file_put_contents("sitemap.xml", $sitemapContent);
}*/
?>