<?php 
if(isset($_SESSION['user_id']) || isset($_COOKIE['user_id'])){
	r2d2(URL_POST.'dashboard');
}else{
	include(APP_URL.'view/login.php'); 
}
?>