<?php

//aqui va la llamada a la funcion de _auth()
switch ( $action ) {

	case 'view':
		include( 'view/login.php' );

		break;

	case 'post':
		if ( isset( $_POST[ 'login-email' ] ) ) {
			if ( isset( $_POST[ 'login-email' ] ) && $_POST[ 'login-password' ] ) {
					$usuario = ORM::for_table( 'admin_users' )->where( 'user', $_POST[ 'login-email' ] )->find_one();
					if ( password_verify($_POST['login-password'], $usuario->password) && $usuario->isActive == 1 ) {
						$_SESSION[ 'user_id' ] = $usuario->id;
						$_SESSION[ 'panel-usuario' ] = $usuario->user;
						$_SESSION[ 'panel-pwd' ] = $usuario->password;

						//crea la cookie de inicio de sesion
						$time = 36000;
						setcookie("user_id", $usuario->id, time()+$time,'/');
						setcookie('hash_'.hash('sha256',$usuario->id.$usuario->user.$usuario->password), hash('sha256',$usuario->user.$usuario->password.$usuario->id), time()+$time,'/');
						
						header( 'Location: '.URL_POST.'dashboard' );
					} else {
						r2d2(URL_POST .'login#datos-mal');
					}

			} else {
				r2d2(URL_POST .'login#datos-mal');
			}
		}

		break;
		
	case 'reminder-email':
		
		$usuario = ORM::for_table( 'users' )->where( 'user', $_POST[ 'reminder-email' ] )->find_one();

		if ( $usuario->tokenUsado == 1 ) {
			$usuario->tokenUsado = 0;
			$usuario->token = sha1( $usuario->user . date( "Y/m/d h:m:s" ) );
			$usuario->save();

			sendMailReminder( $usuario->id );
			
			r2d2(URL_POST .'login#success-restore-mail');
		} else {
			r2d2(URL_POST .'login#error-reminder-email');
		}
		
		break;
		
	case 'restore-pwd-admin':
		if ( $_POST[ 'login-password' ] == $_POST[ 'login-password1' ] ) {
			$usuario = ORM::for_table( 'users' )->where( 'token', $_POST[ 'restore-pwd-admin' ] )->find_one();
			if($usuario){
				echo $usuario->user;
				if($text = validate_pwd($_POST[ 'login-password' ])){
					$usuario->password = hash( 'sha256', $_POST[ 'login-password' ] );
				}else{
					r2d2('?cf=login/pwd-restore/'.$_POST[ 'restore-pwd-admin' ].'#error-validate-pwd');
				}
				$usuario->tokenUsado = 1;
				$usuario->save();

				$_SESSION[ 'user_id' ] = $usuario->id;
				$_SESSION[ 'panel-usuario' ] = $usuario->user;
				$_SESSION[ 'panel-pwd' ] = $usuario->password;

				$time = 36000;
				setcookie("user_id", $usuario->id, time()+$time,'/');
				setcookie('hash_'.hash('sha256',$usuario->id.$usuario->user.$usuario->password), hash('sha256',$usuario->user.$usuario->password.$usuario->id), time()+$time,'/');
				

				$time = 3600;
				$_SESSION[ 'time_discard' ] = $time;
				$now = time();
				$_SESSION[ 'discard_after' ] = $now + $time;
				
				r2d2(URL_POST.'dashboard');
			}else{
				r2d2(URL_POST.'dashboard');
			}
			
		} else {
			r2d2('?cf=login/pwd-restore/'.$_POST[ 'restore-pwd-admin' ].'#error_pwd_no_iguales');
		}
		
		break;
		
	case 'pwd-restore':
		
		$token = $routes[2];
		
		include( './admin/view/pwd-restore.php' );
		
		break;
		
	case 'logout':
		
		if(isset($_COOKIE[ 'user_id' ])){
			$usuario = ORM::for_table( 'admin_users' )->find_one($_COOKIE[ 'user_id' ]);
			$usuario->lastVisited = date( "Y/m/d h:m:s" );
			$usuario->save();
		}
		
		admin_cookie_delete();

		r2d2(URL_POST.'login');
		
		break;

	default:
		$logo_store = ORM::for_table( 'appconfig' )->where('setting','store_logo')->find_one();

		include( './admin/view/login.php' );
		break;
}

?>