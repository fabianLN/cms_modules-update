<?php
_auth();
$prevUrl = $_SERVER['HTTP_REFERER'];

switch ($action) {
	case 'fast-edit':
        //POST: user-settings-password, user-settings-repassword, user-settings-email, user-settings-first
        if ($_POST['user-settings-password'] === $_POST['user-settings-repassword'] || !isset($_POST['user-settings-password'])) {
            $usuario = ORM::for_table('admin_users')->find_one($_COOKIE['user_id']);
            $lastUser = $usuario->user;
            $lastPwd = $usuario->password;
            $usuario->user = $_POST['user-settings-email'];
            $usuario->nombre = $_POST['user-settings-first'];

            if ($usuario->save()) {

                if (isset($_POST['user-settings-password']) && $_POST['user-settings-password'] != '' && validate_pwd($_POST['user-settings-password'])) {
                    $hash = password_hash($_POST['user-settings-password'], PASSWORD_DEFAULT);
                    if($hash != false){
                        $usuario->password = $hash;
                    }else{
                        die('Hay un error en la contraseña');
                    }

                    $usuario = ORM::for_table('admin_users')->where('user', $_POST['user-settings-email'])->find_one();
                    $_SESSION['panel-usuario'] = $usuario->user;
                    $_SESSION['panel-pwd'] = $usuario->password;
                    $_COOKIE['user_id'] = $usuario->id;

                    userCookie($usuario->id,$usuario->user,$usuario->password,$lastUser,$lastPwd);

                }
                admin_log('Usuario editado rápido: '.$usuario->user);
                r2d2($prevUrl . '#success');
            } else {
                r2d2($prevUrl . '#error-save');
            }

        } else {
            r2d2($prevUrl . '#error-no-pwd');
        }

        break;
    case 'first_edit':
        $usuario = ORM::for_table('admin_users')->find_one($_COOKIE['user_id']);
        if (isset($_POST['pwd']) && $_POST['pwd'] != '' && validate_pwd($_POST['pwd'])) {
            $lastUser = $usuario->user;
            $lastPwd = $usuario->password;
            $usuario->user = $_POST['user'];

            $hash = password_hash($_POST['pwd'], PASSWORD_DEFAULT);
            if($hash != false){
                $usuario->password = $hash;
            }else{
                die('Hay un error en la contraseña');
            }

            if ($usuario->save()) {
                $_SESSION['panel-usuario'] = $usuario->user;
                $_SESSION['panel-pwd'] = $usuario->password;
                $_COOKIE['user_id'] = $usuario->id;

                userCookie($usuario->id,$usuario->user,$usuario->password,$lastUser,$lastPwd);

                admin_log('Usuario editado rápido: '.$usuario->user);
                echo json_encode(array('code'=>1,'class'=>'success','text'=>$usuario->id));
            }

        }else{
            echo json_encode(array('code'=>0,'class'=>'danger','text'=>$_SESSION['text']));
        }
        break;

    case 'view-user':
        $usuario_view = ORM::for_table('admin_users')->find_one($routes[2]);
        
        $js_footer = array('user');
        include './admin/view/page_user_profile.php';
        break;

    case 'create-user':

        $js_footer = array('user');
        include './admin/view/page_user_profile.php';
        break;

    case 'act-user':
        /**** Obtenemos las variables ****/
        $actualizar = $_POST['actualizar'];
        $activo = $_POST['active'];
        $email = $_POST['email'];
        $nombre = $_POST['nombre'];
        $pwd = $_POST['pwd'];
        $pwd1 = $_POST['pwd1'];
        $rol = (isset($_POST['rol']))? $_POST['rol'] : 4;
        $pwdUser = $_POST['pwdUser'];
        $error = 0;

        if($email == '' || $nombre == ''){ //comprobamos que los campos basicos esten completados
            $data = 'Hay campos sin completar';
            $error = 1;
        }

        $usuarioActual = ORM::for_table('admin_users')->find_one($_COOKIE['user_id']);
        if ($usuarioActual) {
            // Obtener el hash de la contraseña almacenada en la base de datos
            $hashAlmacenado = $usuarioActual->password;

            // Verificar si la contraseña proporcionada coincide con el hash almacenado
            if (password_verify($pwdUser, $hashAlmacenado)) {
                // La contraseña es correcta
                if($_COOKIE['user_id'] != $usuarioActual->id && $usuarioActual->rol != 1){
                    $data .=  'La contraseña no corresponde con tu usuario o no tienes permiso.<br>';
                    $error = 1;
                }
            } else {
                // La contraseña proporcionada no coincide con la del usuario
                $data = 'La contraseña no corresponde con tu usuario.';
                $error = 1;
            }
        } else {
            // No se encontró ningún usuario con el ID almacenado en la cookie
            $data = 'Usuario no encontrado.';
            $error = 1;
        }

        if($pwd != '' && $pwd1 != '' && $pwd == $pwd1){ //las nuevas pwd deben contener algo y ser iguales para actualizar
            $validate = validate_pwd($pwd);
            
            if($validate){
                if($_COOKIE['user_id'] == $actualizar){ //si se ha validado y el usuario a actualizado, fuerza un reinicio
                    unset($_COOKIE['user_id']);
                    setcookie('user_id', null, -1, '/');
                }
            }else{
                session_start();
                $data = $_SESSION['text'];
                unset($_SESSION['text']);
                $error = 1;
            }
        }

        if($error == 0){ //actualiza los campos en caso de que no haya un error previo
            $usuario = ORM::for_table('admin_users')->find_one($actualizar);
            $lastUser = $usuario->user;
            $lastPwd = $usuario->password;
            $usuario->isActive = $activo;
            $usuario->user = $email;
            $usuario->nombre = $nombre;
            if($usuario->id != 1){
                $usuario->rol = $rol;
            }
            if($pwd != '' && $pwd1 != '' && $pwd == $pwd1){
                $hash = password_hash($pwd, PASSWORD_DEFAULT);
                if($hash != false){
                    $usuario->password = $hash;
                }else{
                    die('Hay un error en la contraseña');
                }
            }

            if($usuario->save()){
                userCookie($usuario->id,$usuario->user,$usuario->password,$lastUser,$lastPwd);
                //admin_log('Usuario actualizado: '.$usuario->user);
                echo $usuario->id;
            }else{
                echo 'No se ha podido actualizar el usuario';
            }
        }else{
            echo $data;
        }

        break;
    
    case 'add-user':
        $actualizar = $_POST['actualizar'];
        $activo = $_POST['active'];
        $email = $_POST['email'];
        $nombre = $_POST['nombre'];
        $pwd = $_POST['pwd'];
        $pwd1 = $_POST['pwd1'];
        $rol = (isset($_POST['rol']))? $_POST['rol'] : 4;
        $pwdUser = $_POST['pwdUser'];
        $error = 0;
        $data = '';
        if($email == '' || $nombre == '' || $pwd == '' || $pwd1 == ''){
            $data .= 'Hay campos sin completar<br>';
            $error = 1;
        }

        if($pwd !== $pwd1){
            $data .= 'Las contraseñas indicadas no son iguales<br>';
            $error = 1;
        }
        $existe = ORM::for_table('admin_users')->where('user',$email)->find_one();
        if($existe->id){
            $data .= 'El correo indicado ya está registrado<br>';
            $error = 1;
        }

        $usuarioActual = ORM::for_table('admin_users')->find_one($_COOKIE['user_id']);
        if ($usuarioActual) {
            // Obtener el hash de la contraseña almacenada en la base de datos
            $hashAlmacenado = $usuarioActual->password;

            // Verificar si la contraseña proporcionada coincide con el hash almacenado
            if (password_verify($pwdUser, $hashAlmacenado)) {
                // La contraseña es correcta
                if($_COOKIE['user_id'] != $usuarioActual->id && $usuarioActual->rol != 1){
                    $data .=  'La contraseña no corresponde con tu usuario o no tienes permiso.<br>';
                    $error = 1;
                }
            } else {
                // La contraseña proporcionada no coincide con la del usuario
                $data = 'La contraseña no corresponde con tu usuario.';
                $error = 1;
            }
        } else {
            // No se encontró ningún usuario con el ID almacenado en la cookie
            $data = 'Usuario no encontrado.';
            $error = 1;
        }

        if($error == 0){
            $usuario = ORM::for_table('admin_users')->create();
            $usuario->isActive = $activo;
            $usuario->user = $email;
            $usuario->nombre = $nombre;
            $usuario->rol = $rol;
            if(validate_pwd($pwd)){
                $hash = password_hash($pwd, PASSWORD_DEFAULT);
                if($hash != false){
                    $usuario->password = $hash;
                }else{
                    die('Hay un error en la contraseña');
                }
            }else{
                $data = $_SESSION['text'];
                echo $data;exit;
            }

            
            if($usuario->save()){
                admin_log('Usuario creado: '.$usuario->user);
                echo $usuario->id;
            }else{
                echo 'No se ha podido actualizar el usuario';
            }
        }else{
            echo $data;
        }

        break;

    case 'delete-user':
        $usuario = ORM::for_table('admin_users')->find_one($routes[2]);
        $email = $usuario->user;
        if($usuario->delete()){
            admin_log('Usuario borrado: '.$email);
            r2d2( URL_POST . 'user', 's', 'Usuario borrado' );
        }else{
            r2d2( URL_POST . 'user', 'e', 'No se ha podido borrar al usuario' );
        }
        break;

    default:
        $usuarios = ORM::for_table('admin_users')->find_many();
        include(APP_URL.'view/page_users.php');
        break;
}


function userCookie($id,$name,$pwd,$lastUser,$lastPwd){
    setcookie('hash_' . hash('sha256', $id . $lastUser . $lastPwd), '', time() - 3600, '/'); //elimina la cookie con el hash del correo antiguo y la crea de nuevo
    setcookie('hash_' . hash('sha256', $id . $name . $pwd), hash('sha256', $name . $pwd . $id), time() + 36000, '/');
}