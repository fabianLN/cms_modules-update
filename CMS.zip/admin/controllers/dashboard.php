
<?php
_auth();
$user = _user();
$frases = array(
	'',
);

switch ( $action ) {
	case 'user_widgets':
		$user_widgets = ORM::for_table('admin_users')->find_one($user->id);
		if($_POST['check'] == 'true'){
			$user_widgets->admin_widgets .= $_POST['name'].',';
		}else{
			$user_widgets->admin_widgets = str_replace($_POST['name'].',', '', $user_widgets->admin_widgets);
		}
		$user_widgets->save();

		//devolucion de los widgets actuales
		$admin_widgets = ORM::for_table('admin_widgets')->find_many();
		$widgets_user = explode(',',$user_widgets->admin_widgets);

		foreach($admin_widgets as $widget){
			if(in_array($widget->id,$widgets_user)){
				include_once(APP_URL . 'view/widgets/'.$widget->files);
			}
		}
		break;
	case 'user_quickviews':
		$user_quickviews = ORM::for_table('admin_users')->find_one($user->id);
		if($_POST['check'] == 'true'){
			$user_quickviews->admin_quickviews .= $_POST['name'].',';
		}else{
			$user_quickviews->admin_quickviews = str_replace($_POST['name'].',', '', $user_quickviews->admin_quickviews);
		}
		$user_quickviews->save();

		//devolucion de los quickviews actuales
		$admin_quickviews = ORM::for_table('admin_quickviews')->find_many();
		$quickviews_user = explode(',',$user_quickviews->admin_quickviews);

		foreach($admin_quickviews as $quickview){
			if(in_array($quickview->id,$quickviews_user)){
				include_once(APP_URL . 'view/quickView/'.$quickview->files);
			}
		}
		break;
	default:
		$admin_widgets = ORM::for_table('admin_widgets')->find_many();
		$admin_quickviews = ORM::for_table('admin_quickviews')->find_many();

		$user_widgets = ORM::for_table('admin_users')->select('admin_widgets')->find_one($user->id);
		$widgets_user = explode(',',$user_widgets->admin_widgets);
		
		$user_quickviews = ORM::for_table('admin_users')->select('admin_quickviews')->find_one($user->id);
		$quickviews_user = explode(',',$user_quickviews->admin_quickviews);

		$total_visitors = ORM::for_table('wa_browsers')->count();

		$js_footer = array( 'dashboard' );
		include( APP_URL . 'view/dashboard.php' );
	break;
}
?>