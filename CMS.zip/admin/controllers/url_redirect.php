<?php
_auth();


switch ( $action ) {
    case 'view-redirect':
        $js_footer= array('redirect');
        $url_route = ORM::for_table('url_redirect')->find_one($routes[2]);
		include(APP_URL .'view/page_url_redirect_edit.php');
    break;

    case 'add-redirect':
        $js_footer= array('redirect');
        $url_route = ORM::for_table('url_redirect')->find_one($routes[2]);
		include(APP_URL .'view/page_url_redirect_edit.php');
    break;

    case 'create-redirect':
        $existe = ORM::for_table('url_redirect')->where_like('old_url',$_POST['request'])->find_one();
        if($_POST['request'] != $_POST['target'] && !$existe){
            $url_routes = ORM::for_table('url_redirect')->create();
            $url_routes->old_url = $_POST['request'];
            $url_routes->new_url = $_POST['target'];

            if($url_routes->save()){
                admin_log('Creada redirección: '.$url_routes->id);
                echo $url_routes->id;
            }else{
                echo 'Ha ocurrido un problema al actualizar la redirección';
            }
        }else{
            echo 'Las url son la misma o la redirección ya existe';
        }
    break;

    case 'update-redirect':
        $existe = ORM::for_table('url_redirect')->where_like('old_url',$_POST['request'])->where_not_equal('id',$_POST['id'])->find_one();
        if($_POST['request'] != $_POST['target'] && !$existe){
            $url_routes = ORM::for_table('url_redirect')->find_one($_POST['id']);
            $url_routes->old_url = $_POST['request'];
            $url_routes->new_url = $_POST['target'];

            if($url_routes->save()){
                admin_log('Actualizada redirección: '.$url_routes->id);
                echo 1;
            }else{
                echo 'Ha ocurrido un problema al actualizar la redirección';
            }
        }else{
            echo 'Las url son la misma o la redirección ya existe';
        }
    break;

    case 'delete-redirect':
        $url_routes = ORM::for_table('url_redirect')->find_one($routes[2]);
        $id = $url_routes->id;
        if($url_routes->delete()){
            admin_log('Borrada redirección: '.$id);
            r2d2( URL_POST . 'url_redirect', 's', 'Se ha borrado la redirección' );
        }else{
            r2d2( URL_POST . 'url_redirect/view-redirect/'.$url_routes->id, 'e', 'Ha ocurrido un problema al borrar la redirección' );
        }
    break;

    default:
        $js_footer= array('redirect');
        $url_routes = ORM::for_table('url_redirect')->find_many();
        include(APP_URL .'view/page_url_redirect.php');
    break;
}
?>