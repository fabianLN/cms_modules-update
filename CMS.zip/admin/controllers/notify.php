<?php
_auth();
switch ($action) {
    case 'notify_view':
        if ($routes[2]) {
            $notifys = ORM::for_table('admin_notify')->where('type', $routes[2])->order_by_asc('user_solved')->find_many();
        } else {
            $notifys = ORM::for_table('admin_notify')->order_by_asc('user_solved')->find_many();
        }

        $js_footer = array('notify');
        include(APP_URL . 'view/page_ecom_notify.php');
        break;

    case 'notify_restore':
        $update = ORM::for_table('appconfig')->where('setting', 'admin_notify_update')->find_one();
        $now = date("Y-m-d H:i:s");
        if ((strtotime($update->value) + 86400) < strtotime($now)) {
            $update->value = $now;
            $update->save();
            notify_errors(0);
        }
        if ($_POST['manual']) {
            $update->value = $now;
            $update->save();
            notify_errors(1);
        }
        fin();
        break;

    case 'notify_solved':
        $id = solvedNotify($routes[2]);
        $response = "Se ha marcado como completada";
        $user = ORM::for_table('admin_users')->find_one($_COOKIE['user_id']);
        $arr = array('code' => 1, 'text' => $response, 'user' => $user->userFirst . ' ' . $user->userLast, 'id' => $id);
        echo json_encode($arr);
        break;

    default:
        $response = "No hemos encontrado la función especificada";
        $arr = array('code' => 0, 'text' => $response);
        echo json_encode($arr);
        break;
}

function solvedNotify($id) {
    $notify = ORM::for_table("admin_notify")->find_one($id);
    $notify->user_solved = $_COOKIE['user_id'];
    $notify->save();

    return $notify->id;
}

function notify_errors($manual = false) {
    // Obtener las reglas de notificación desde la tabla admin_notification_rules
    $rules = ORM::for_table('admin_notification_rules')->find_many();

    foreach ($rules as $rule) {
        // Comprobar si se tiene que evaluar según se haya ejecutado la función
        if ($rule->manual == $manual || $manual == 0) {
            // Obtener el nombre de la tabla y el campo de la regla
            $tableName = $rule->type;
            $fieldName = $rule->field;
            $notificationCondition = $rule->notification_condition;
            $expectedValue = $rule->expected_value;

            // Verificar si el campo existe en la tabla antes de proceder
            $tableColumns = ORM::for_table($tableName)->get_columns();
            if (!array_key_exists($fieldName, $tableColumns)) {
                // Continuar con la siguiente regla si el campo no existe
                continue;
            }

            // Realizar la consulta para verificar las condiciones
            $query = ORM::for_table($tableName);

            // Verificar la condición de notificación
            switch ($notificationCondition) {
                case 'empty':
                    $results = $query->where_raw("$fieldName IS NULL OR $fieldName = ''")->find_many();
                    foreach ($results as $result) {
                        setNotification("El campo '$fieldName' en '$tableName' está vacío.", $result->id, $tableName);
                    }
                    break;

                case 'equal':
                    $results = $query->where_raw("$fieldName = ?", [$expectedValue])->find_many();
                    foreach ($results as $result) {
                        setNotification("El campo '$fieldName' en '$tableName' es igual a '$expectedValue'.", $result->id, $tableName);
                    }
                    break;

                case 'not_equal':
                    $results = $query->where_raw("$fieldName <> ?", [$expectedValue])->find_many();
                    foreach ($results as $result) {
                        setNotification("El campo '$fieldName' en '$tableName' no es igual a '$expectedValue'.", $result->id, $tableName);
                    }
                    break;

                case 'less_than':
                    $results = $query->where_raw("$fieldName < ?", [$expectedValue])->find_many();
                    foreach ($results as $result) {
                        setNotification("El campo '$fieldName' en '$tableName' es menor que '$expectedValue'.", $result->id, $tableName);
                    }
                    break;

                case 'greater_than':
                    $results = $query->where_raw("$fieldName > ?", [$expectedValue])->find_many();
                    foreach ($results as $result) {
                        setNotification("El campo '$fieldName' en '$tableName' es mayor que '$expectedValue'.", $result->id, $tableName);
                    }
                    break;

                // Puedes agregar más condiciones aquí según sea necesario
            }
        }
    }
}

function getUrl($type, $id) {
    // Obtener la regla de URL correspondiente al tipo
    $urlRule = ORM::for_table('admin_notification_rules')->where('type', $type)->find_one();

    // Comprobar si se encontró la regla
    if ($urlRule && $urlRule->url_template) {
        // Formatear la URL con el ID
        return URL_POST . sprintf($urlRule->url_template, $id);
    } else {
        // Retornar valor por defecto si no se encuentra el tipo
        return 'javascript:void(0)';
    }
}


function notify_update() {
    $config = ORM::for_table('appconfig')->where('setting', 'notify_update')->find_one();
    $config->value = date('Y-m-d');
    $config->save();
}

function fin() {
    $response = "Proceso realizado correctamente";
    $arr = array('code' => 1, 'text' => $response);
    echo json_encode($arr);
}