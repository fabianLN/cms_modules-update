<?php
_auth();


switch ( $action ) {	
	case 'view-page':
		
		$page = ORM::for_table('custom_pages')->find_one($routes[2]);
		$url_page = ORM::for_table('url_custom')->where('type','custom_pages')->where('id_rel',$page->id)->find_one();
		
		$js_footer = array( 'edit_pages' );
		include(APP_URL. 'view/page_ecom_page_edit.php');
		break;
	
	case 'create-page':

		$js_footer = array( 'edit_pages' );
		include(APP_URL. 'view/page_ecom_page_edit.php');
		break;
		
	
	case 'act-page':
		$page = ORM::for_table('custom_pages')->find_one($_POST['id']);
		$url_page = ORM::for_table('url_custom')->where('type','custom_pages')->where('id_rel',$page->id)->find_one();
		$existe = true;

		if (!$page) {
			$page = ORM::for_table('custom_pages')->create();
			$url_page = ORM::for_table('url_custom')->create();
			$existe = false;
			$page->content = '';
			$page->css = '';
			$page->js = '';
		}

		($_POST['active'] == 'true')? $page->active = 1 : $page->active = 0;
		$page->name = $_POST['nombre'];
		// $page->css = $_POST['css'];
		// $page->js = $_POST['js'];
		// $page->content = $_POST['contenido'];
		$page->meta_title = $_POST['meta_title'];
		$page->meta_key = $_POST['meta_key'];
		$page->meta_description = $_POST['meta_description'];
		$page->meta_robots = $_POST['meta_robots'];
		$old = $url_page->url;
		$new = $_POST['url'];
		$url_page->url = $_POST['url'];
		
		if($page->save()){
			admin_log('Página creada: '.$page->name);
			if (!strpos($url_page->url, get_extension())) {
				$url_page->url = $_POST['url'].get_extension();
				
			}
			$url_page->id_rel = $page->id;
			$url_page->type = 'custom_pages';
			if($url_page->save()){
				if($old!=$new && $existe){
					autoRedirect($old,$new,$url_page->id_rel,'custom_pages');
				}
				echo $page->id;
			}else{
				echo 'Ha ocurrido un error al guardar la url';
			}
		}else{
			echo 'No se ha podido crear la página';
		}
		break;
		
	case 'add-page':
		$page = ORM::for_table('custom_pages')->create();
		$url_page = ORM::for_table('url_custom')->create();

		if($_POST['nombre'] != '' && $_POST['url'] != ''){
		
			($_POST['active'] == 'on')? $page->active = 1 : $page->active = 0;
			$page->name = $_POST['nombre'];
			// $page->css = $_POST['css'];
			// $page->js = $_POST['js'];
			// $page->content = $_POST['contenido'];
			$page->meta_title = $_POST['meta_title'];
			$page->meta_key = $_POST['meta_key'];
			$page->meta_description = $_POST['meta_description'];
			$page->meta_robots = $_POST['meta_robots'];
			
			
			
			if($page->save()){
				admin_log('Página creada: '.$page->name);
				if (strpos($cadena, get_extension()) == false) {
					$url_page->url = $_POST['url'].get_extension();
				}
				$url_page->id_rel = $page->id;
				$url_page->type = 'page';
				if($url_page->save()){
					echo $page->id;
				}else{
					echo 'Ha ocurrido un error al guardar la url';
				}
			}else{
				echo 'No se ha podido crear la página';
			}
		}else{
			echo 'hay campos necasarios que no han sido completados';
		}
		
		break;
		
	case 'delete-page':
		$page = ORM::for_table('custom_pages')->find_one($routes[2]);
		$url_page = ORM::for_table('url_custom')->where('type','custom_pages')->where('id_rel',$page->id)->find_one();

		$name = $page->name;
		if($page->delete() && $url_page->delete()){
			admin_log('Página borrada: '.$name);
			r2d2( URL_POST . 'edit_pages', 's', 'página borrada' );
		}else{
			r2d2( URL_POST . 'edit_pages/view-page/' . $page->id, 'e', 'No se ha podido eliminar el página' );
		}
		break;

	case 'update-desonlytext-builder':
		$html = getbody(TildesHtml($_POST['content']));
		$style = getstyle(TildesHtml($_POST['content']));

		$page = ORM::for_table('custom_pages')->find_one($routes[2]);
		$page->content = $html;
		$page->css = $style;
		$page->save();

		admin_log('Guardado el texto de la pag: '.$page->name);
		echo 'Guardado correctamente';
		break;
	case 'reading_facility':
		include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/admin/lib/modules/reading_facility/reading_facility.php' );
		$rl = new get_level();

		//$url_page = ORM::for_table('url_custom')->where('type','custom_pages')->where('id_rel',$_POST['id'])->find_one();
		//echo $rl->byUrl(str_replace('admin/','',COMPLETE_URL) . $url_page->url);

		echo $rl->byText('custom_pages',$_POST['id'],'content');
		break;

	default: 
		$pages = ORM::for_table('custom_pages')->find_many();
		$url_page = ORM::for_table('url_custom')->where('type','custom_pages')->where('id_rel',$page->id)->find_one();

		include(APP_URL. 'view/page_ecom_pages.php');
		break;
}


function getbody($html) {
	$dom = new DOMDocument;
	$dom->loadHTML($html);
	$bodies = $dom->getElementsByTagName('body');
	assert($bodies->length === 1);
	$body = $bodies->item(0);
	for ($i = 0; $i < $body->children->length; $i++) {
		$body->remove($body->children->item($i));
	}
	$stringbody = $dom->saveHTML($body);
	if (preg_match('/(?:<body[^>]*>)(.*)<\/body>/isU', $stringbody, $matches)) {
        $body = $matches[1];
    }
	return $body;
}

function getstyle($html) {
	$dom = new DOMDocument;
	$dom->loadHTML($html);
	$bodies = $dom->getElementById('vvvebjs-styles');
	
	return $bodies->textContent;
}

function TildesHtml($cadena) 
{ 
    return str_replace(
        array("á", "é", "í", "ó", "ú", "ñ", "Á", "É", "Í", "Ó", "Ú", "Ñ", "¡", "º"),
        array("&aacute;", "&eacute;", "&iacute;", "&oacute;", "&uacute;", "&ntilde;", "&Aacute;", "&Eacute;", "&Iacute;", "&Oacute;", "&Uacute;", "&Ntilde;", "&iexcl;", "&ordm;"), 
        $cadena);     
}

function tag_replace($html){
	$array_replace = array('<h1>','<h2>','<h3>','<h4>','<h5>','<h6>','<p>','<span>');
	//$array_replace = array('<h1','<h2','<h3','<h4','<h5','<h6','<p','<span');
	$subst = ' builder-element="" builder-inline-edit=""';

	for ($i = 0;$i < count($array_replace);$i++) {
		$html = str_replace($array_replace[$i],substr($array_replace[$i], 0, -1).' builder-element="" builder-inline-edit="">',$html);
		//$html = preg_replace('/'.$array_replace[$i].'\s((?!builder-element|builder-inline-edit).)*$/m', $array_replace[$i].$subst, $html);
	}

	return $html;
}
?>