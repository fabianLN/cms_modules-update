
<?php
_auth();

switch ( $action ) {
	case 'clearCache':
		$setting = ORM::for_table('appconfig')->where('setting','files_version')->find_one();
		$setting->value += 1;

		if($setting->save()){
			admin_log('Se ha borrado la caché');
			$arr = array('code' => 1, 'text' => 'Cache limpiada correctamente');
			echo json_encode($arr);
		}else{
			$arr = array('code' => 'error', 'text' => 'Ha ocurrido un error al limpiar la cache');
			echo json_encode($arr);
		}
		break;
	case 'edit-settings':
		$save = false;
		if (isset($_POST['urls'])) {
			$_POST = $_POST['urls'];
		}
		foreach ( array_keys( $_POST ) as $field ) {

			if ( $field != 'general-setting' ) {
				$config = ORM::for_table( 'appconfig' )->where( 'setting', $field )->find_one();

				if ( $_POST[ 'cache' ] == 'unactive' && $field == 'cache' ) {
					$config->value = 0;
				} elseif ( $field == 'cache' ) {
					$config->value = 1;
				} else {
					$config->value = $_POST[ $field ];
				}

				if ( $config->save() ) {
					$save = true;
				}

			}
		}

		if ( $save ) {
			admin_log('Ajustes actualizados');
			r2d2(URL_POST . 'settings#success');
		} else {
			r2d2(URL_POST . 'settings#error');
		}
		
		break;
	case 'dbOptimice':
		// Llamar a la función para optimizar todas las tablas
		$resultado = optimizeAllTables();
		$arr = array('code' => 1, 'text' => 'Base de datos optimizada');
		echo json_encode($arr);
		break;
	case 'check_update':
		$result = checkAndUpdateCmsVersion();

		switch ($result) {
			case 'Nueva versión detectada':
				// Actualizar la fecha de última actualización
				$configDate = ORM::for_table("appconfig")->where('setting', 'cms_update_date')->find_one();
				$currentDate = new DateTime();
				$configDate->value = $currentDate->format('Y-m-d');
				$configDate->save();

				$arr = array('code' => 1, 'text' => $result);
				echo json_encode($arr);
				break;
			case 'La comprobación ya se realizó hoy.':
				break;
			
			default:
				// Actualizar la fecha de última actualización
				$configDate = ORM::for_table("appconfig")->where('setting', 'cms_update_date')->find_one();
				$currentDate = new DateTime();
				$configDate->value = $currentDate->format('Y-m-d');
				$configDate->save();

				setNotification($result,0,'');
				$arr = array('code' => 0, 'text' => $result);
				echo json_encode($arr);
				break;
		}
		break;
	case 'update_cms':
		$config = ORM::for_table("appconfig")->where('setting', 'cms_update')->find_one();
		$result = updateCmsModule();
		if($result != 1){
			setNotification($result,0,'');
			$arr = array('code' => 0, 'text' => $result);
			echo json_encode($arr);
		}else{
			$config->value = 0;
			$config->save();
			r2d2(URL_POST.'dashboard');
		}
		break;

	default:
		$config=ORM::for_table('appconfig')->where('fixed',0)->find_many();

        $js_footer = array('admin_tools');
		include( APP_URL . 'view/settings_admin_tools.php' );
	break;
}

/**
 * Optimiza todas las tablas en la base de datos especificada.
 */
function optimizeAllTables() {
    // Obtener el nombre de la base de datos actual
    $dbName = ORM::get_db()->query('SELECT DATABASE()')->fetchColumn();

    // Obtener todas las tablas en la base de datos
    $tables = ORM::for_table('information_schema.tables')
                ->select('table_name')
                ->where('table_schema', $dbName)
                ->where('table_type', 'BASE TABLE')
                ->find_array();

	$return = '';
    // Optimizar cada tabla
    foreach ($tables as $table) {
        $tableName = $table['table_name'];
        $query = "OPTIMIZE TABLE {$tableName}";
        ORM::get_db()->query($query);
        $return .= "Tabla {$tableName} optimizada.\n";
    }

	return $return;
}
?>