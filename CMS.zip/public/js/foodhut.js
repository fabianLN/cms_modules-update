/*!
=========================================================
* FoodHut Landing page
=========================================================

* Copyright: 2019 DevCRUD (https://devcrud.com)
* Licensed: (https://devcrud.com/licenses)
* Coded by www.devcrud.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// smooth scroll
$(document).ready(function(){
    $(".navbar .nav-link").on('click', function(event) {

        if (this.hash !== "") {

            event.preventDefault();

            var hash = this.hash;

            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 700, function(){
                window.location.hash = hash;
            });
        } 
    });
});


 $(document).ready(function() {
    // Verificar la posición del scroll al cargar la página
    if ($('.fixed_head').scrollTop() === 0) {
        $('nav.custom-navbar').removeClass('fixed-top');
    }
    
    // Agregar el evento de scroll
    $(document).on('scroll', function() {
        // Si el scroll está en la parte superior, quitar la clase 'fixed-top'
        if ($(this).scrollTop() === 0) {
            $('nav.custom-navbar').removeClass('fixed-top');
        } else {
            // Si el scroll no está en la parte superior, agregar la clase 'fixed-top'
            $('nav.custom-navbar').addClass('fixed-top');
        }
    })
});