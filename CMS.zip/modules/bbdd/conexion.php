<?php

    global $db_host, $db_name, $db_user, $db_password;
    require('idiorm.php'); //llama y configura idiorm
    include_once('check_bbdd.php');
    require('Paginator.php');


    // Directorio donde se encuentran los archivos
    $directory = $_SERVER['DOCUMENT_ROOT'] . '/src/entity/';

    // Obtener la lista de archivos en el directorio
    $files = scandir($directory);

    // Iterar sobre los archivos
    foreach ($files as $file) {
        // Excluir los directorios . y ..
        if ($file != "." && $file != "..") {
            // Comprobar si es un archivo
            if (is_file($directory . $file)) {
                // Incluir el archivo
                include_once $directory . $file;
            }
        }
    }



    ORM::configure("mysql:host=$db_host;dbname=$db_name",null);

    ORM::configure('username', $db_user);

    ORM::configure('password', $db_password);

    ORM::configure('driver_options', array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4'));

    ORM::configure('return_result_sets', true);

    $test_appconfig = ORM::forTable('')->raw_query('SHOW TABLES LIKE "appconfig"')->findMany()->count();
    if($test_appconfig > 0 && getSetting('db_version') < getSetting('cms_version')){
        check_bbdd::check_database();
        check_bbdd::update_database();
    }elseif($test_appconfig == 0){
        check_bbdd::check_database();
    }
?>