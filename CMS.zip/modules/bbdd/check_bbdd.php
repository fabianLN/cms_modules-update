<?php 
    class check_bbdd {
        // Crear las tablas necesarias en la base de datos si no existen
        function check_database() {
            global $web_name, $web_logo, $media, $css, $js, $font, $ext;
            $db = ORM::get_db();

            /* funciones para appconfig */
            $test_appconfig = ORM::forTable('')->raw_query('SHOW TABLES LIKE "appconfig"')->findMany()->count();
            if(!$test_appconfig){
                $db->exec("
                    CREATE TABLE IF NOT EXISTS appconfig (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        setting varchar(255) NOT NULL,
                        value varchar(255) NOT NULL,
                        fixed int(11) NOT NULL DEFAULT '0'
                    );
                ");
                $db->exec("
                    INSERT INTO appconfig (id, setting, value, fixed) VALUES
                    (1, 'admin_notify_update', '',1),
                    (2, 'cms_update', '',1),
                    (3, 'cms_update_date', '1996-01-20',1),
                    (4, 'store', '$web_name',0),
                    (5, 'store_logo', '$web_logo',0),
                    (6, 'cms_version', '0',1),
                    (7, 'files_version', '0',1),
                    (8, 'db_version', '0',1),
                    (9, 'media', '$media',0),
                    (10, 'css', '$css',0),
                    (11, 'js', '$js',0),
                    (12, 'font', '$font',0),
                    (13, 'extension', '$ext',0),
                    (14, 'analitica', '1',0),
                    (15, 'sitemap_images', '0',0),
                    (16, 'sitemap_videos', '0',0);
                ");
            }

            /* funciones para admin_log */
            $test_admin_log = $db->exec("
                CREATE TABLE IF NOT EXISTS admin_log (
                    id INTEGER PRIMARY KEY AUTO_INCREMENT,
                    description text NOT NULL,
                    fecha datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    user int(11) NOT NULL
                )
            ");

            /* funciones para url_custom */
            $test_url_custom = ORM::forTable('')->raw_query('SHOW TABLES LIKE "url_custom"')->findMany()->count();
            if(!$test_url_custom){
                $test_url_custom = $db->exec("
                    CREATE TABLE IF NOT EXISTS url_custom (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        url varchar(255) NOT NULL,
                        id_rel int(11) DEFAULT NULL,
                        type varchar(255) NOT NULL COMMENT 'tabla a la que hace referencia',
                        fixed int(11) NOT NULL DEFAULT '0',
                        in_menu INT NOT NULL DEFAULT '0' COMMENT 'indica si se debe incluir en la edicion de menu'
                    )
                ");

                $db->exec("
                    INSERT INTO `url_custom` (id, url, id_rel, type, fixed) VALUES
                    (1, 'index$ext', 1, 'custom_pages', 1);
                ");
            }

            /* funciones para url_redirect */
            $test_url_redirect = $db->exec("
                CREATE TABLE IF NOT EXISTS url_redirect (
                    id INTEGER PRIMARY KEY AUTO_INCREMENT,
                    old_url varchar(255) NOT NULL,
                    new_url varchar(255) NOT NULL,
                    auto int(11) NOT NULL DEFAULT '0',
                    id_rel int(11) NOT NULL,
                    type varchar(255) NOT NULL
                )
            ");

            /* funciones para admin_users */
            $test_admin_users = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_users"')->findMany()->count();
            if(!$test_admin_users){
                $admin_users = $db->exec("
                    CREATE TABLE IF NOT EXISTS admin_users (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        isActive int(11) NOT NULL DEFAULT '1',
                        user varchar(255) NOT NULL COMMENT 'identificador del usuario',
                        password varchar(500) NOT NULL COMMENT 'contraseña del usuario',
                        nombre varchar(255) NOT NULL COMMENT 'nombre completo del usuario',
                        rol int(11) NOT NULL DEFAULT '4',
                        token varchar(500) NOT NULL DEFAULT '' COMMENT 'token para recuperacion de pwd',
                        token_usado varchar(255) NOT NULL DEFAULT '0' COMMENT '1 mail enviado 0 no enviado',
                        lastVisited varchar(255) DEFAULT NULL COMMENT 'ultima fecha de visita',
                        admin_widgets varchar(255) NOT NULL DEFAULT '1,2,3,4,' COMMENT 'widgets que se mostrarán en el dashboard del admin para este usuario',
                        admin_quickviews varchar(255) NOT NULL DEFAULT '' COMMENT 'vista rapida que se mostrarán en el dashboard del admin para este usuario'
                    )
                ");

                $db->exec("
                    INSERT INTO admin_users (id, isActive, user, password, nombre, rol, token, token_usado, lastVisited,admin_widgets) VALUES
                    (1, 1, 'admin@admin', '\$2y\$10\$QFu3LZMVLTzu\/YQ80.NVie3S5dSWtS.zHt3AhIbWI3Od5\/KtZfwDy', 'Admin', 1, '', '0', '','1,2,3,4,')
                ");
            }

            /* funciones para admin_log_view */
            $test_admin_log_view = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_log_view"')->findMany()->count();
            if(!$test_admin_log_view){
                $admin_log_view = $db->exec("
                    CREATE VIEW admin_log_view
                    AS
                        SELECT 
                        al.id AS id,
                        al.description AS description,
                        us.nombre AS user,
                        al.fecha AS fecha 
                        FROM admin_log al
                        JOIN admin_users us ON us.id = al.user
                ");
            }

            /* funciones para admin_menu */
            $test_admin_menu = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_menu"')->findMany()->count();
            if(!$test_admin_menu){
                $admin_menu = $db->exec("
                    CREATE TABLE admin_menu (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        name varchar(255) NOT NULL,
                        url varchar(255) NOT NULL,
                        icon varchar(255) NOT NULL,
                        rol int(11) NOT NULL,
                        pos int(11) NOT NULL,
                        id_parent int(11) NOT NULL DEFAULT '0'
                    )
                ");

                $db->exec("
                    INSERT INTO admin_menu (id, name, url, icon, rol, pos, id_parent) VALUES
                    (1, 'Escritorio', 'dashboard', 'gi gi-display', 10000, 1, 0),
                    (2, 'Informes', '', 'gi gi-charts', 4, 10, 0),
                        (3, 'Analíticas', 'analytics', '', 4, 1, 2),
                    (4, 'Páginas', '', 'gi gi-brush', 3, 20, 0),
                        (5, 'Edición de páginas', 'edit_pages', '', 3, 1, 4),
                    (6, 'Seo', '', 'fab fa-google', 3, 30, 0),
                        (7, 'Redirecciones', 'url_redirect', '', 3, 1, 6),
                        (8, 'Sitemap', 'sitemap', '', 3, 2, 6),
                    (9, 'Herramientas', '', 'gi gi-settings', 1, 999, 0),
                        (10, 'Edición de menu', 'setting_menu', '', 1, 1, 9),
                        (11, 'Módulos', 'pluggins', '', 1, 2, 9),
                    (12, 'Ajustes', '', 'fa fa-cog', 2, 10000, 0),
                        (13, 'Usuarios', 'user', '', 1, 1, 12),
                        (14, 'Configuración', 'settings', '', 1, 2, 12);
                ");
            }

            /* funciones para admin_notification_rules */
            $admin_notification_rules = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_notification_rules"')->findMany()->count();
            if(!$admin_notification_rules){
                $admin_notification_rules = $db->exec("
                    CREATE TABLE admin_notification_rules (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        type varchar(255) NOT NULL,
                        field varchar(255) NOT NULL,
                        notification_condition enum('empty','equal','not_equal','less_than','greater_than') NOT NULL,
                        expected_value text,
                        manual int(11) NOT NULL DEFAULT '0',
                        url_template varchar(255) DEFAULT NULL,
                        created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    )
                ");
            }

            /* funciones para menu */
            $test_menu = ORM::forTable('')->raw_query('SHOW TABLES LIKE "menu"')->findMany()->count();
            if(!$test_menu){
                $menu = $db->exec("
                    CREATE TABLE menu (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        id_parent int(250) UNSIGNED NOT NULL DEFAULT 0,
                        name varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
                        url varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
                        pos tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
                        id_rel int(11) NOT NULL,
                        type varchar(255) CHARACTER SET utf8 NOT NULL
                    )
                ");

                $db->exec("
                    INSERT INTO menu (id, id_parent, name, url, pos, id_rel, type) VALUES
                    (1, 0, 'Inicio', '', 1, 0, ''),
                    (2, 0, 'Sobre nosotros', '#about', 1, 0, ''),
                    (3, 0, 'Galería', '#gallary', 1, 0, ''),
                    (4, 0, 'Reservar mesa', '#book-table', 1, 0, '');
                ");
            }

            /* funciones para custom_pages */
            $test_custom_pages = ORM::forTable('')->raw_query('SHOW TABLES LIKE "custom_pages"')->findMany()->count();
            if(!$test_custom_pages){
                $cp = $db->exec("
                    CREATE TABLE custom_pages (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        name varchar(250) CHARACTER SET utf8 NOT NULL,
                        active int(11) NOT NULL DEFAULT 1,
                        content longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
                        meta_key varchar(250) CHARACTER SET utf8 NOT NULL,
                        meta_description varchar(250) CHARACTER SET utf8 NOT NULL,
                        fixed int(11) NOT NULL DEFAULT 0,
                        css longtext CHARACTER SET utf8 NOT NULL,
                        js longtext CHARACTER SET utf8 NOT NULL,
                        meta_title longtext CHARACTER SET utf8 NOT NULL,
                        meta_robots text COLLATE utf8mb4_spanish_ci NOT NULL
                    )
                ");

                $db->exec("
                    INSERT INTO custom_pages (id, name, active, content, meta_key, meta_description, fixed, css, js, meta_title, meta_robots) VALUES
                    (1, 'Index', 1, '<!-- header -->\r\n<header id=\"home\" class=\"header\">\r\n<div class=\"overlay text-white text-center\">\r\n<h1 class=\"display-2 font-weight-bold my-3\">Food Hut</h1>\r\n<h2 class=\"display-4 mb-5\">Always fresh &amp; Delightful</h2>\r\n<a class=\"btn btn-lg btn-primary\" href=\"#gallary\">View Our gallary</a>\r\n</div>\r\n</header>\r\n\r\n<!--  About Section  -->\r\n<div id=\"about\" class=\"container-fluid wow fadeIn\" id=\"about\" data-wow-duration=\"1.5s\">\r\n<div class=\"row\">\r\n<div class=\"col-lg-6 has-img-bg\"></div>\r\n<div class=\"col-lg-6\">\r\n<div class=\"row justify-content-center\">\r\n<div class=\"col-sm-8 py-5 my-5\">\r\n<h2 class=\"mb-4\">About Us</h2>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, quisquam accusantium nostrum modi, nemo, officia veritatis ipsum facere maxime assumenda voluptatum enim! Labore maiores placeat impedit, vero sed est voluptas!Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita alias dicta autem, maiores doloremque quo perferendis, ut obcaecati harum, <br><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum necessitatibus iste,\r\nnulla recusandae porro minus nemo eaque cum repudiandae quidem voluptate magnam voluptatum? <br>Nobis, saepe sapiente omnis qui eligendi pariatur. quis voluptas. Assumenda facere adipisci quaerat. Illum doloremque quae omnis vitae.</p>\r\n<p><b>Lonsectetur adipisicing elit. Blanditiis aspernatur, ratione dolore vero asperiores explicabo.</b></p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos ab itaque modi, reprehenderit fugit soluta, molestias optio repellat incidunt iure sed deserunt nemo magnam rem explicabo vitae. Cum, nostrum, quidem.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<!--  gallary Section  -->\r\n<div id=\"gallary\" class=\"text-center bg-dark text-light has-height-md middle-items wow fadeIn\">\r\n<h2 class=\"section-title\">OUR MENU</h2>\r\n</div>\r\n<div class=\"gallary row\">\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-1.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-2.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-3.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-4.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-5.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-6.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-7.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-8.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-9.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-10.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-11.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n<div class=\"col-sm-6 col-lg-3 gallary-item wow fadeIn\">\r\n<img src=\"public/media/gallary-12.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"gallary-img\">\r\n<a href=\"#\" class=\"gallary-overlay\">\r\n<i class=\"gallary-icon ti-plus\"></i>\r\n</a>\r\n</div>\r\n</div>\r\n\r\n<!-- book a table Section  -->\r\n<div class=\"container-fluid has-bg-overlay text-center text-light has-height-lg middle-items\" id=\"book-table\">\r\n<div class=\"\">\r\n<h2 class=\"section-title mb-5\">BOOK A TABLE</h2>\r\n<div class=\"row mb-5\">\r\n<div class=\"col-sm-6 col-md-3 col-xs-12 my-2\">\r\n<input type=\"email\" id=\"booktable\" class=\"form-control form-control-lg custom-form-control\" placeholder=\"EMAIL\">\r\n</div>\r\n<div class=\"col-sm-6 col-md-3 col-xs-12 my-2\">\r\n<input type=\"number\" id=\"booktable\" class=\"form-control form-control-lg custom-form-control\" placeholder=\"NUMBER OF GUESTS\" max=\"20\" min=\"0\">\r\n</div>\r\n<div class=\"col-sm-6 col-md-3 col-xs-12 my-2\">\r\n<input type=\"time\" id=\"booktable\" class=\"form-control form-control-lg custom-form-control\" placeholder=\"EMAIL\">\r\n</div>\r\n<div class=\"col-sm-6 col-md-3 col-xs-12 my-2\">\r\n<input type=\"date\" id=\"booktable\" class=\"form-control form-control-lg custom-form-control\" placeholder=\"12/12/12\">\r\n</div>\r\n</div>\r\n<a href=\"#\" class=\"btn btn-lg btn-primary\" id=\"rounded-btn\">FIND TABLE</a>\r\n</div>\r\n</div>\r\n\r\n<!-- BLOG Section  -->\r\n<div id=\"blog\" class=\"container-fluid bg-dark text-light py-5 text-center wow fadeIn\">\r\n<h2 class=\"section-title py-5\">EVENTS AT THE FOOD HUT</h2>\r\n<div class=\"row justify-content-center\">\r\n<div class=\"col-sm-7 col-md-4 mb-5\">\r\n<ul class=\"nav nav-pills nav-justified mb-3\" id=\"pills-tab\" role=\"tablist\">\r\n<li class=\"nav-item\">\r\n<a class=\"nav-link active\" id=\"pills-home-tab\" data-toggle=\"pill\" href=\"#foods\" role=\"tab\" aria-controls=\"pills-home\" aria-selected=\"true\">Foods</a>\r\n</li>\r\n<li class=\"nav-item\">\r\n<a class=\"nav-link\" id=\"pills-profile-tab\" data-toggle=\"pill\" href=\"#juices\" role=\"tab\" aria-controls=\"pills-profile\" aria-selected=\"false\">Juices</a>\r\n</li>\r\n</ul>\r\n</div>\r\n</div>\r\n<div class=\"tab-content\" id=\"pills-tabContent\">\r\n<div class=\"tab-pane fade show active\" id=\"foods\" role=\"tabpanel\" aria-labelledby=\"pills-home-tab\">\r\n<div class=\"row\">\r\n<div class=\"col-md-4\">\r\n<div class=\"card bg-transparent border my-3 my-md-0\">\r\n<img src=\"public/media/blog-1.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"rounded-0 card-img-top mg-responsive\">\r\n<div class=\"card-body\">\r\n<h1 class=\"text-center mb-4\"><a href=\"#\" class=\"badge badge-primary\">$5</a></h1>\r\n<h4 class=\"pt20 pb20\">Reiciendis Laborum </h4>\r\n<p class=\"text-white\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa provident illum officiis fugit laudantium voluptatem sit iste delectus qui ex. </p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4\">\r\n<div class=\"card bg-transparent border my-3 my-md-0\">\r\n<img src=\"public/media/blog-2.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"rounded-0 card-img-top mg-responsive\">\r\n<div class=\"card-body\">\r\n<h1 class=\"text-center mb-4\"><a href=\"#\" class=\"badge badge-primary\">$12</a></h1>\r\n<h4 class=\"pt20 pb20\">Adipisci Totam</h4>\r\n<p class=\"text-white\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa provident illum officiis fugit laudantium voluptatem sit iste delectus qui ex. </p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4\">\r\n<div class=\"card bg-transparent border my-3 my-md-0\">\r\n<img src=\"public/media/blog-3.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"rounded-0 card-img-top mg-responsive\">\r\n<div class=\"card-body\">\r\n<h1 class=\"text-center mb-4\"><a href=\"#\" class=\"badge badge-primary\">$8</a></h1>\r\n<h4 class=\"pt20 pb20\">Dicta Deserunt</h4>\r\n<p class=\"text-white\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa provident illum officiis fugit laudantium voluptatem sit iste delectus qui ex. </p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"tab-pane fade\" id=\"juices\" role=\"tabpanel\" aria-labelledby=\"pills-profile-tab\">\r\n<div class=\"row\">\r\n<div class=\"col-md-4 my-3 my-md-0\">\r\n<div class=\"card bg-transparent border\">\r\n<img src=\"public/media/blog-4.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"rounded-0 card-img-top mg-responsive\">\r\n<div class=\"card-body\">\r\n<h1 class=\"text-center mb-4\"><a href=\"#\" class=\"badge badge-primary\">$15</a></h1>\r\n<h4 class=\"pt20 pb20\">Consectetur Adipisicing Elit</h4>\r\n<p class=\"text-white\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa provident illum officiis fugit laudantium voluptatem sit iste delectus qui ex. </p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4 my-3 my-md-0\">\r\n<div class=\"card bg-transparent border\">\r\n<img src=\"public/media/blog-5.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"rounded-0 card-img-top mg-responsive\">\r\n<div class=\"card-body\">\r\n<h1 class=\"text-center mb-4\"><a href=\"#\" class=\"badge badge-primary\">$29</a></h1>\r\n<h4 class=\"pt20 pb20\">Ullam Laboriosam</h4>\r\n<p class=\"text-white\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa provident illum officiis fugit laudantium voluptatem sit iste delectus qui ex. </p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4 my-3 my-md-0\">\r\n<div class=\"card bg-transparent border\">\r\n<img src=\"public/media/blog-6.jpg\" alt=\"template by DevCRID http://www.devcrud.com/\" class=\"rounded-0 card-img-top mg-responsive\">\r\n<div class=\"card-body\">\r\n<h1 class=\"text-center mb-4\"><a href=\"#\" class=\"badge badge-primary\">$3</a></h1>\r\n<h4 class=\"pt20 pb20\">Fugit Ipsam</h4>\r\n<p class=\"text-white\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa provident illum officiis fugit laudantium voluptatem sit iste delectus qui ex. </p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<!-- REVIEWS Section  -->\r\n<div id=\"testmonial\" class=\"container-fluid wow fadeIn bg-dark text-light has-height-lg middle-items\">\r\n<h2 class=\"section-title my-5 text-center\">REVIEWS</h2>\r\n<div class=\"row mt-3 mb-5\">\r\n<div class=\"col-md-4 my-3 my-md-0\">\r\n<div class=\"testmonial-card\">\r\n<h3 class=\"testmonial-title\">John Doe</h3>\r\n<h6 class=\"testmonial-subtitle\">Web Designer</h6>\r\n<div class=\"testmonial-body\">\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum nobis eligendi, quaerat accusamus ipsum sequi dignissimos consequuntur blanditiis natus. Aperiam!</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4 my-3 my-md-0\">\r\n<div class=\"testmonial-card\">\r\n<h3 class=\"testmonial-title\">Steve Thomas</h3>\r\n<h6 class=\"testmonial-subtitle\">UX/UI Designer</h6>\r\n<div class=\"testmonial-body\">\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum minus obcaecati cum eligendi perferendis magni dolorum ipsum magnam, sunt reiciendis natus. Aperiam!</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-md-4 my-3 my-md-0\">\r\n<div class=\"testmonial-card\">\r\n<h3 class=\"testmonial-title\">Miranda Joy</h3>\r\n<h6 class=\"testmonial-subtitle\">Graphic Designer</h6>\r\n<div class=\"testmonial-body\">\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, nam. Earum nobis eligendi, dignissimos consequuntur blanditiis natus. Aperiam!</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<!-- CONTACT Section  -->\r\n<div id=\"contact\" class=\"container-fluid bg-dark text-light border-top wow fadeIn\">\r\n<div class=\"row\">\r\n<div class=\"col-md-6 px-0\">\r\n<div id=\"map\" style=\"width: 100%; height: 100%; min-height: 400px\"></div>\r\n</div>\r\n<div class=\"col-md-6 px-5 has-height-lg middle-items\">\r\n<h3>FIND US</h3>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit, laboriosam doloremque odio delectus, sunt magnam laborum impedit molestiae, magni quae ipsum, ullam eos! Alias suscipit impedit et, adipisci illo quam.</p>\r\n<div class=\"text-muted\">\r\n<p><span class=\"ti-location-pin pr-3\"></span> 12345 Fake ST NoWhere, AB Country</p>\r\n<p><span class=\"ti-support pr-3\"></span> (123) 456-7890</p>\r\n<p><span class=\"ti-email pr-3\"></span>info@website.com</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', 'meta_key', 'meta_description', 1, 'css', 'js', 'meta_title', 'NOINDEX,NOFOLLOW');
                ");
            }

            /* funciones para admin_modules */
            $test_admin_modules = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_modules"')->findMany()->count();
            if(!$test_admin_modules){
                $am = $db->exec("
                    CREATE TABLE admin_modules (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        name varchar(250) CHARACTER SET utf8 NOT NULL,
                        file varchar(250) CHARACTER SET utf8 NOT NULL,
                        version float(11) NOT NULL DEFAULT 1,
                        update_url varchar(250) CHARACTER SET utf8,
                        last_check timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ultima fecha comprobacion actualizacion',
                        borrable int(11) NOT NULL DEFAULT 1,
                        files longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
                    )
                ");
            }

            /* funciones para admin_modules_config */
            $test_admin_modules_config = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_modules_config"')->findMany()->count();
            if(!$test_admin_modules_config){
                $amc = $db->exec("
                    CREATE TABLE admin_modules_config (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        type varchar(250) CHARACTER SET utf8 NOT NULL,
                        content longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
                    )
                ");
            }

            /* funciones para admin_modules */
            $test_admin_widgets = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_widgets"')->findMany()->count();
            if(!$test_admin_widgets){
                $admin_widgets = $db->exec("
                    CREATE TABLE admin_widgets (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        name varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
                        rol int(11) NOT NULL DEFAULT 4,
                        files varchar(255) CHARACTER SET utf8 NOT NULL
                    )
                ");

                $db->exec("
                    INSERT INTO admin_widgets (id, name, rol, files) VALUES
                    (1, 'Informes', 4, 'analytics.php'),
                    (2, 'Modificar Menú', 2, 'edit_menu.php'),
                    (3, 'Crear nueva página', 2, 'new_page.php'),
                    (4, 'Redirecciones', 2, 'redirects.php');
                ");
            }

            /* funciones para admin_modules */
            $test_admin_quickviews = ORM::forTable('')->raw_query('SHOW TABLES LIKE "admin_quickviews"')->findMany()->count();
            if(!$test_admin_quickviews){
                $admin_quickviews = $db->exec("
                    CREATE TABLE admin_quickviews (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        name varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
                        rol int(11) NOT NULL DEFAULT 4,
                        files varchar(255) CHARACTER SET utf8 NOT NULL
                    )
                ");
            }



            /* Aumenta el nº de version de la bbdd para que no se vuelva a comprobar */
            $db_version = ORM::for_table('appconfig')->where('setting','db_version')->find_one();
            $db_version->value = getSetting('cms_version');
            $db_version->save();
        }

        // Actualiza la bbdd en caso de haber cambios
        function update_database(){

        }
    }
?>