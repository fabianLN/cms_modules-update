<?php 
/* ZONA DE DEFINICIONES */
define("CSS", getSetting('css'));
define("JS", getSetting('js'));
define("FONT", getSetting('font'));
define("MEDIA", getSetting('media'));
define("EXT", getSetting('extension'));
define("URL", ($_SERVER["REQUEST_URI"] != '/')? substr(parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH), 1) : 'index');
define("ACTUAL_LINK", str_replace(EXT,'',search_url(URL)));
define("COMPLETE_URL", str_replace('www.','',strtok((empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]", '?')));
define("FV", getSetting('files_version'));
?>