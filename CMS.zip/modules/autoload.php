<?php 

    class autoload {
        public $loaded = array();
        public $notLoaded = array();

        function __construct(){
            $json = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/modules/autoload.json');
            $json_data = json_decode($json,true); 
        
            $this->load($json_data['packages']);
            if(isset($_SERVER['REDIRECT_URL']) && $_SERVER['REDIRECT_URL'] != '/admin/'){
                $this->load($json_data['modules']);
            }

            if(count($this->notLoaded) > 0){
                $this->load($this->notLoaded);
            }

            if(count($this->notLoaded) > 0){
                $error = "Error al incluir los modulos, modulos no cargados: ";
                foreach ($this->notLoaded as $package) {
                    if($package['type'] === 'basic-plugin'){
                        $error .= $package['name'].' // ';
                    }
                }
                throw new Exception($error, 1);
            }
        }

        private function load($packages){
            $this->notLoaded = array();
            foreach ($packages as $config) {
                if(is_array($config['require'])){
                    if($this->validate($config['require'])){
                        array_push($this->loaded,$config['name']);
                        if(is_file($_SERVER['DOCUMENT_ROOT'].$config['autoload']) && $config['autoload'] != ''){
                            include_once($_SERVER['DOCUMENT_ROOT'].$config['autoload']);
                        }
                    }else{
                        array_push($this->notLoaded,$config);
                    }
                }
            }
        }
    
        private function validate($requires){
            $return = 1;
            foreach ($requires as $key => $require) {
                switch ($key) {
                    case 'php':
                        if (!$this->verificarVersionPHP($require)) {
                            $retunr = 0;
                        }
                        break;
                    case 'modules':
                        foreach ($require as $module) {
                            if(!in_array($module,$this->loaded)){
                                $return = 0;
                            }
                        }
                        break;
                    
                    default:
                        $return = 0;
                        break;
                }
            }
            return $return;
        }
    
        private function verificarVersionPHP($requisito) {
            // Obtiene la versión actual de PHP
            $version_php = phpversion();
            
            // Divide el requisito en partes separadas por "||"
            $requisitos = explode('||', $requisito);
            
            // Itera sobre cada requisito y verifica si la versión cumple con alguno
            foreach ($requisitos as $req) {
                // Elimina los espacios en blanco al principio y al final
                $req = trim($req);
                // Verifica si la versión cumple con el requisito actual
                if (version_compare($version_php, str_replace('^', '', $req), '>=')) {
                    return true;
                }
            }
            
            // Si ninguno de los requisitos se cumple, devuelve false
            return false;
        }
    }

?>