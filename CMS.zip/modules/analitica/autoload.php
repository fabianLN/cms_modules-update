<?php 
    if(getSetting('analitica') && ACTUAL_LINK != 'admin' && strpos($_SERVER['HTTP_REFERER'],'admin') === false){
        include_once('webanalytics.php');
    }
?>