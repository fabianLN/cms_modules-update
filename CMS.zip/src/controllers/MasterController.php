<?php
if(ACTUAL_LINK == 'index'.EXT || ACTUAL_LINK == 'index'){
    $data = getUrlData('index'.EXT);
    $meta_title = $data->meta_title;
    $meta_desc = $data->meta_description;
    $meta_key = $data->meta_key;

    include('./templates/custom-page.php');
}elseif(ACTUAL_LINK == 'custom_pages'){
    $data = getUrlData(URL);
    /* funciones que se necesiten para las custom_pages */

    $meta_title = $data->meta_title;
    $meta_desc = $data->meta_description;
    $meta_key = $data->meta_key;

    include('./templates/custom-page.php');
}else{
    $meta_title = '¡Vaya! No hemos encontrado esta página';
    $meta_desc = 'No te quedes aquí y navega por otras páginas, quizá tenemos lo que buscas';
    $meta_key = 'órgano, iglesia, parroquia, asociación amigos de la iglesia, Cardenete';

    include('./templates/error/404-page.php');
}