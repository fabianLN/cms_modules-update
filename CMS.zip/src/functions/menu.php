<?php 
    Class Menu {
        function getMenu_admin() {
            global $template;
            $menu = ORM::for_table('admin_menu')->order_by_asc('id_parent')->order_by_asc('pos')->find_many();
            $array_resultante = array();
        
            foreach ($menu as $objeto) {
                $datos_objeto = array(
                    'id' => $objeto->id,
                    'name' => $objeto->name,
                    'icon' => $objeto->icon,
                    'rol' => $objeto->rol,
                    'pos' => $objeto->pos,
                );

                if (!empty($objeto->url)) {
                    $datos_objeto['url'] = $template['url_base'] . $objeto->url;
                }
    
                if ($objeto->id_parent != 0) {
                    foreach ($array_resultante as $key => &$elemento) {
                        if ($elemento['id'] == $objeto->id_parent) {
                            $array_resultante[$key]['sub'][] = $datos_objeto;
                        }
                    }
                }else{
                    array_push($array_resultante,$datos_objeto);
                }
            }
    
            return $array_resultante;
        }

        function getMenu() {
            global $template;
            $menu = ORM::for_table('menu')->order_by_asc('id_parent')->order_by_asc('pos')->find_many();
            $array_resultante = array();
        
            foreach ($menu as $objeto) {
                $datos_objeto = array(
                    'id' => $objeto->id,
                    'name' => $objeto->name,
                    'url' => '/'.$template['url_base'].$objeto->url,
                );
    
                if ($objeto->id_parent != 0) {
                    foreach ($array_resultante as $key => &$elemento) {
                        if ($elemento['id'] == $objeto->id_parent) {
                            $array_resultante[$key]['sub'][] = $datos_objeto;
                        }
                    }
                }else{
                    array_push($array_resultante,$datos_objeto);
                }
            }
    
            return $array_resultante;
        }
    }
?>