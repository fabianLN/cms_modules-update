<?php
/* FUNCIONES BASICAS Y COMUNES */

    function getCookie(){
        if(isset($_GET['em'])){
            unset($_COOKIE['em']);
            setcookie('em', $_GET['em'],strtotime( '+30 days' ),'/');
            return $_GET['em'];
        }else{
            return $_COOKIE['em'];
        }
        
    }

    function getSetting($setting){
        $query = ORM::for_table('appconfig')->where('setting',$setting)->find_one();
        return $query->value;
    }

    function search_url($url){
        $query = ORM::for_table('url_custom')->where('url',$url)->find_one();

        if($query){
            return $query->type;
        }else{
            return explode('/',$url)[0];
        }
    }

    function get_routes(){
        $data_url = ORM::for_table("url_custom")->where('url',URL)->find_one();
        $data_redirect = ORM::for_table("url_redirect")->where('old_url',URL)->find_one();

        return array('data_url'=>$data_url,'data_redirect'=>$data_redirect);
    }

    function getUrlData($url){
        $query = ORM::for_table('url_custom')->where('url',$url)->find_one();
        $data = ORM::for_table($query->type)->find_one($query->id_rel);

        if($query->id_rel){
            return $data;
        }else{
            return '';
        }
    }

    function getUrlModuleData($url){
        $query = ORM::for_table('url_custom')->where('url',$url)->find_one();
        $data = ORM::for_table('admin_modules_config')->where_like('type',$query->type)->find_one();

        return json_decode($data->content,true);
    }

    function getUrlById($query,$type){

        $ids = array();
        foreach ($query as $q) {
            array_push($ids, $q->id);
        }

        if(count($ids) == 0){
            return '';
        }

        $results = ORM::for_table("url_custom")->where_in('id_rel',$ids)->where('type',$type)->find_many();

        foreach ($results as $result) {
            $return[$result->id_rel] = $result->url;
        }

        return $return;
    }
?>

