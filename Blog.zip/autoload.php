<?php 
    class bbdd_update {

        function __construct() {
            // Constructor vacío
        }

        // Crear las tablas necesarias en la base de datos si no existen
        function update_database() {
            $db = ORM::get_db();
            $local_folder = $_SERVER['DOCUMENT_ROOT'] . '/public/media/blog/';
            mkdir($local_folder, 0777, true);

            // Funciones para admin_notification_rules
            $admin_notification_rules = ORM::forTable('admin_notification_rules')->where_like('type', '%blog_%')->findMany()->count();
            if (!$admin_notification_rules) {
                $db->exec("
                    select * from admin_notification_rules where type like '%blog_%';
                ");

            }

            // Funciones para url_custom
            $url_custom = ORM::forTable('url_custom')->where('type', 'blog_posts')->findMany()->count();
            if (!$url_custom) {
                $db->exec("
                    INSERT INTO url_custom (id, url, id_rel, type, fixed, in_menu) 
                    VALUES (NULL, 'blog".get_extension()."', '0', 'blog_posts', '1', '1');
                ");
            }

            // Funciones para admin_menu
            $admin_menu = ORM::forTable('admin_menu')->where('name', 'Blog')->findMany()->count();
            if (!$admin_menu) {
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Blog', '', 'gi gi-book_open', 3, 14, 0);
                ");
                $admin_menu_parent = ORM::for_table('admin_menu')->where('name', 'Blog')->find_one();
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Post', 'blog_post', '', 3, 1, $admin_menu_parent->id);
                ");
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Categorías', 'blog_categories', '', 3, 2, $admin_menu_parent->id);
                ");
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Etiquetas', 'blog_tags', '', 3, 3, $admin_menu_parent->id);
                ");
            }

            // Funciones para admin_modules_config
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "blog_post"')->findMany()->count();
            if (!$test_module_config) {
                $db->exec("
                    INSERT INTO admin_modules_config (type, content) VALUES
                    ('blog_posts', '".json_encode(array('h1' => 'Esto es el h1','h2'=>'Este el h2','content'=>'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eligendi, in perferendis voluptatem officiis porro autem, amet, placeat repellendus ab dolores velit fugiat soluta alias est. Vitae earum dicta non. Corporis.','meta_title'=>'Nuestro blog','meta_key'=>'blog, actualidad, noticias','meta_desc'=>'Te presentamos el blog de nuestra web','meta_robots'=>'','url_base'=>'blog','use_url_base'=>1))."');
                ");
            }

            // Funciones para admin_widgets
            $admin_widgets = ORM::forTable('admin_widgets')->where('name', 'Nuevo post')->findMany()->count();
            if (!$admin_widgets) {
                $db->exec("
                    INSERT INTO admin_widgets (name, rol, files) VALUES
                    ('Nuevo post', 3, 'blog_post.php');
                ");
            }

            // Funciones para blog_posts
            $blog_posts = ORM::forTable('')->raw_query('SHOW TABLES LIKE "blog_posts"')->findMany()->count();
            if (!$blog_posts) {
                $db->exec("
                    CREATE TABLE blog_posts (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        active int(11) NOT NULL DEFAULT 1,
                        name longtext CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
                        introduccion varchar(1024) COLLATE utf8mb4_spanish_ci NOT NULL COMMENT 'breve descripcion del post',
                        fecha datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        descripcion longtext CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
                        style text COLLATE utf8mb4_spanish_ci NOT NULL,
                        imagen varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
                        id_admin_users varchar(140) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
                        id_blog_categories int(10) NOT NULL,
                        meta_title varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
                        meta_key varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
                        meta_description varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
                        id_blog_tag_principal int(11) NOT NULL COMMENT 'indica la tag principal del post',
                        id_blog_tag varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
                        id_products text COLLATE utf8mb4_spanish_ci NOT NULL,
                        id_categories text COLLATE utf8mb4_spanish_ci NOT NULL,
                        id_blog_posts varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL COMMENT 'id de los posts relacionados',
                        in_index int(11) NOT NULL DEFAULT 0
                    );
                ");
            }

            // Funciones para blog_categories
            $blog_categories = ORM::forTable('')->raw_query('SHOW TABLES LIKE "blog_categories"')->findMany()->count();
            if (!$blog_categories) {
                $db->exec("
                    CREATE TABLE blog_categories (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        icon varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL COMMENT 'icono de la categoria',
                        name varchar(500) CHARACTER SET utf8 NOT NULL,
                        description longtext CHARACTER SET utf8 NOT NULL,
                        meta_title text CHARACTER SET utf8 NOT NULL,
                        meta_key text CHARACTER SET utf8 NOT NULL,
                        meta_description text CHARACTER SET utf8 NOT NULL,
                        slider int(11) NOT NULL DEFAULT 0 COMMENT 'si se debe mostrar en index',
                        index_position int(11) NOT NULL
                    );
                ");
            }

            // Funciones para blog_tag
            $blog_tag = ORM::forTable('')->raw_query('SHOW TABLES LIKE "blog_tag"')->findMany()->count();
            if (!$blog_tag) {
                $db->exec("
                    CREATE TABLE blog_tag (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        name text CHARACTER SET utf8 NOT NULL
                    )
                ");
            }
        }

        function delete_database() {
            $local_folder = $_SERVER['DOCUMENT_ROOT'] . '/public/media/blog/';
            self::eliminarCarpeta($local_folder);

            $db = ORM::get_db();

            // Funciones para admin_notification_rules
            $admin_notification_rules = ORM::forTable('admin_notification_rules')->where_like('type', '%blog_%')->findMany()->count();
            if ($admin_notification_rules) {
                $db->exec("
                    DELETE FROM admin_notification_rules WHERE type like '%blog_%'
                ");
            }

            // Funciones para url_custom
            $url_customP = ORM::forTable('url_custom')->where('type', 'blog_posts')->findMany()->count();
            if ($url_customP) {
                $db->exec("
                    DELETE FROM url_custom WHERE type = 'blog_posts'
                ");
            }
            $url_customC = ORM::forTable('url_custom')->where('type', 'blog_categories')->findMany()->count();
            if ($url_customC) {
                $db->exec("
                    DELETE FROM url_custom WHERE type = 'blog_categories'
                ");
            }

            // Funciones para admin_menu
            $blog = ORM::forTable('admin_menu')->where_like('url', 'blog_post')->findMany()->count();
            if ($blog) {
                $id_parent = ORM::for_table('admin_menu')->where('name', 'Blog')->find_one();
                $db->exec("
                    DELETE FROM admin_menu WHERE id_parent = $id_parent->id
                ");

                $db->exec("
                    DELETE FROM admin_menu WHERE id = $id_parent->id
                ");
            }

            // Funciones para admin_widgets
            $admin_widgets = ORM::forTable('admin_widgets')->where('name', 'Nuevo post')->findMany()->count();
            if ($admin_widgets) {
                $db->exec("
                    DELETE FROM admin_widgets WHERE name like 'Nuevo post'
                ");
            }

            // Funciones para admin_modules_config
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "blog_posts"')->findMany()->count();
            if ($test_module_config) {
                $db->exec("
                    DELETE FROM admin_modules_config WHERE type like 'blog_posts'
                ");
            }

            // Funciones para blog_posts
            $blog_posts = ORM::forTable('')->raw_query('SHOW TABLES LIKE "blog_posts"')->findMany()->count();
            if ($blog_posts) {
                $db->exec("
                    DROP TABLE blog_posts
                ");
            }

            // Funciones para blog_categories
            $blog_categories = ORM::forTable('')->raw_query('SHOW TABLES LIKE "blog_categories"')->findMany()->count();
            if ($blog_categories) {
                $db->exec("
                    DROP TABLE blog_categories
                ");
            }

            // Funciones para blog_tag
            $blog_tag = ORM::forTable('')->raw_query('SHOW TABLES LIKE "blog_tag"')->findMany()->count();
            if ($blog_tag) {
                $db->exec("
                    DROP TABLE blog_tag
                ");
            }

            // Funciones para menu
            $menu = ORM::forTable('menu')->where('type', 'blog_posts')->findMany()->count();
            if ($menu) {
                $menu = ORM::forTable('menu')->where('type', 'blog_posts')->delete_many();
            }
        }

        public function eliminarCarpeta($carpeta) {
            // Verificar si la carpeta existe
            if (!is_dir($carpeta)) {
                return false;
            }

            // Obtener el contenido de la carpeta
            $archivos = array_diff(scandir($carpeta), array('.', '..'));

            // Eliminar recursivamente los archivos y subcarpetas
            foreach ($archivos as $archivo) {
                $ruta = $carpeta . '/' . $archivo;
                if (is_dir($ruta)) {
                    self::eliminarCarpeta($ruta); // Llamada recursiva para eliminar subcarpetas
                } else {
                    unlink($ruta); // Eliminar archivo
                }
            }

            // Eliminar la carpeta principal
            return rmdir($carpeta);
        }
    }
?>