<?php 
    /* FUNCIONES BlogS */
    function getBlogUrl(){
        $query = ORM::for_table('url_custom')->where('type','blog_posts')->where('id_rel',0)->find_one();
        return $query->url;
    }
    function getBlogCategories(){
        $query = ORM::for_table('blog_categories')->find_many();
        return $query;
    }
    function getPostByCat($id_cat, $tag = 0, $limit = 15){
        if(isset($_GET['p'])){
            $start = ( $_GET['p'] * $limit ) - $limit;
            $count = ORM::for_table('blog_posts')->where('active',1)->count();

            if($start <= $count){
                if($tag > 0){
                    $query = ORM::for_table('blog_posts')->where('active',1)->where('id_blog_categories',$id_cat)->where('id_blog_tag_principal',$tag)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->offset($start)->limit($limit)->find_many();
                }else{
                    $query = ORM::for_table('blog_posts')->where('active',1)->where('id_blog_categories',$id_cat)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->offset($start)->limit($limit)->find_many();
                }
            }
        }else{
            if($tag > 0){
                $query = ORM::for_table('blog_posts')->where('active',1)->where('id_blog_categories',$id_cat)->where('id_blog_tag_principal',$tag)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->limit($limit)->find_many();
            }else{
                $query = ORM::for_table('blog_posts')->where('active',1)->where('id_blog_categories',$id_cat)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->limit($limit)->find_many();
            }
        }

        return $query;
    }
    function getAllPosts(){
        $query = ORM::for_table('blog_posts')->find_many();
        return $query;
    }
    function getPosts($tag = 0, $limit = 15){
        if(isset($_GET['p'])){
            $start = ( $_GET['p'] * $limit ) - $limit;
            $count = ORM::for_table('blog_posts')->where('active',1)->count();

            if($start <= $count){
                if($tag > 0){
                    $query = ORM::for_table('blog_posts')->where('active',1)->where('id_blog_tag_principal',$tag)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->offset($start)->limit($limit)->find_many();
                }else{
                    $query = ORM::for_table('blog_posts')->where('active',1)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->offset($start)->limit($limit)->find_many();
                }
            }
        }else{
            if($tag > 0){
                $query = ORM::for_table('blog_posts')->where('active',1)->where('id_blog_tag_principal',$tag)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->limit($limit)->find_many();
            }else{
                $query = ORM::for_table('blog_posts')->where('active',1)->where_lt('fecha',date('Y-m-d H:i:s',strtotime('now')))->order_by_desc('fecha')->order_by_desc('id')->limit($limit)->find_many();
            }
        }

        return $query;
    }
    function getAllCategories(){
        $query = ORM::for_table('blog_categories')->find_many();

        foreach ($query as $category) {
            $url = ORM::for_table('url_custom')->where('type','blog_categories')->where('id_rel',$category->id)->find_one();
            $return[$category->id]['name'] = $category->name;
            $return[$category->id]['url'] = $url->url;
        }
        return (isset($return))? $return : null;
    }
    function getAllTags(){
        $query = ORM::for_table('blog_tag')->find_many();
        if(count($query) > 0){
            foreach ($query as $tag) {
                $return[$tag->id] = $tag->name;
            }
            return $return;
        }
    }
?>