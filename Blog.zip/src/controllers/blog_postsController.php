<?php 
    $data = getUrlData(URL);
    if($data == ""){
        $data = getUrlModuleData(URL);
        $meta_title = $data['meta_title'];
        $meta_desc = $data['meta_description'];
        $meta_key = $data['meta_key'];
        $blog_categories = getBlogCategories();
        $categories = getAllCategories();

        $paginator = Paginator::bootstrap('blog_posts');

        if($paginator['lastpage'] >= $_GET['p']){
            $posts = getPosts();
            $urlPost = getUrlById($posts,'blog_posts');
        }

        $url_js = getBlogUrl();
        include('./templates/blog.php');
    }else {
        $tags = getAllTags();

        $meta_title = $data['meta_title'];
        $meta_desc = $data['meta_description'];
        $meta_key = $data['meta_key'];

        include('./templates/blog_post.php');
    }
?>