<?php 
    $data = getUrlData(URL);
    $meta_title = $data['meta_title'];
    $meta_desc = $data['meta_description'];
    $meta_key = $data['meta_key'];

    $paginator = Paginator::bootstrap('blog_posts');

    if($paginator['lastpage'] >= $_GET['p']){
        $posts = getPostByCat($data['id']);
        $urlPost = getUrlById($posts,'blog_categories');
    }

    $url_js = URL;
    include('./templates/blog_category.php');