<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?=$meta_desc?>">
        <meta name="author" content="Devcrud">
        <title><?=$meta_title?></title>

        <?php include_once('sections/links-head.php') ?>
        <meta name="robots" content="<?=$data['meta_robots']?>">
    </head>
    <body class="fixed_head" data-spy="scroll" data-target=".navbar" data-offset="40" id="custom-page">
        
        <?php include_once('sections/menu.php') ?>

        <div id="blog_post" class="text-center bg-dark text-light has-height-md middle-items wow fadeIn">
            <div class="row mb-5">
                <div class="col-md-12">
                    <h3><?=$data['name']?></h3>
                    <p><?=$data['introduccion']?></p>
                    <img src="<?=$media.'/blog/blog-completo/'.$data['imagen']?>" alt="<?=$data['name']?>">
                    <ul class="pst-mta">
                        <li><i class="ti-alarm-clock"></i> <?=ceil(str_word_count(strip_tags($data['texto']))/200)?>'</li>
                    </ul>
                    <?=$data['descripcion']?>

                    <div class="col-md-4">
                        <span class="alert alert-warning">#<?=$tags[$data['id_blog_tag_principal']]?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once('sections/footer.php') ?>

        <?php include_once('sections/links-footer.php') ?>

    </body>
</html>