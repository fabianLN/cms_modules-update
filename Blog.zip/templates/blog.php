<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?=$meta_desc?>">
        <meta name="author" content="Devcrud">
        <title><?=$meta_title?></title>

        <?php include_once('sections/links-head.php') ?>
        <meta name="robots" content="<?=$data['meta_robots']?>">
    </head>
    <body class="fixed_head" data-spy="scroll" data-target=".navbar" data-offset="40" id="custom-page">
        
        <?php include_once('sections/menu.php') ?>

        <div id="blog" class="text-center bg-dark text-light has-height-md middle-items wow fadeIn">
            <h1><?=$data['h1']?></h1>
            <h2><?=$data['h2']?></h2>
            <p><?=$data['content']?></p>

            <section class="section-posts mt-5">
                <?php if(isset($posts)){ ?>
                    <div id="posts" class="row">
                        <?php foreach ($posts as $post) { ?>
                            <div class="col-md-4 mb-4">
                                <div class="img-content">
                                    <a href="<?=$urlPost[$post->id]?>">
                                        <img src="<?=$media.'/blog/blog-peq/'.$post->imagen?>" alt="<?=$post->name?>">
                                    </a>
                                </div>
                                <div class="post-content">
                                    <div class="categories">
                                        <a href="<?=$categories[$post->id_blog_categories]['url']?>" class="alert alert-info" role="alert"><?=$categories[$post->id_blog_categories]['name']?></a>
                                    </div>
                                    <h3 class="mt-3">
                                        <a href="<?=$urlPost[$post->id]?>">
                                            <?=$post->name?>
                                        </a>
                                    </h3>
                                </div>
                            </div>
                        <?php } ?>
                        <div id="end_posts" class="row" data-page="<?=(isset($_GET['p']))? $_GET['p'] : 1?>"></div>
                    </div>
                    <?php }else{ ?>
                        <div id="posts" class="row">
                            <div class="col-md-12">
                                <div class="clearfix"></div>
                                <h2>Has llegado al final</h2>
                            </div>
                        </div>
                    <?php } ?>
            </section>

        </div>
        <?php include_once('sections/footer.php') ?>

        <?php include_once('sections/links-footer.php') ?>
        <script>
            const url_js = "<?=$url_js?>"
        </script>
        <script src="/public/js/posts.js"></script>

    </body>
</html>