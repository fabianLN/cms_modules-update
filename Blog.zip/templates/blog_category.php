<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?=$meta_desc?>">
        <meta name="author" content="Devcrud">
        <title><?=$meta_title?></title>

        <?php include_once('sections/links-head.php') ?>
        <meta name="robots" content="<?=$data['meta_robots']?>">
    </head>
    <body class="fixed_head" data-spy="scroll" data-target=".navbar" data-offset="40" id="custom-page">
        
        <?php include_once('sections/menu.php') ?>

        <div id="blog_post" class="text-center bg-dark text-light has-height-md middle-items wow fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <h3><?=$data['name']?></h3>
                    <?=$data['descripcion']?>
                </div>
                <?php if($posts){ ?>
                    <div id="posts" class="row col-md-12">
                        <?php foreach ($posts as $post) { ?>
                            <div class="col-md-4">
                                <div class="img-content">
                                    <a href="<?=$urlPost[$post->id]?>">
                                        <img src="<?=$media.'/blog/blog-peq/'.$post->imagen?>" alt="<?=$post->name?>">
                                    </a>
                                </div>
                                <div class="post-content">
                                    <h3>
                                        <a href="<?=$urlPost[$post->id]?>">
                                            <?=$post->name?>
                                        </a>
                                    </h3>
                                </div>
                            </div>
                        <?php } ?>
                        <div id="end_posts" class="row" data-page="<?=(isset($_GET['p']))? $_GET['p'] : 1?>"></div>
                    </div>
                <?php }else{ ?>
                    <div id="posts" class="row">
                        <div class="col-md-12">
                            <div class="clearfix"></div>
                            <h2>Has llegado al final</h2>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
        <?php include_once('sections/footer.php') ?>

        <?php include_once('sections/links-footer.php') ?>
        <script>
            const url_js = "<?=$url_js?>"
        </script>
        <script src="/public/js/posts.js"></script>

    </body>
</html>