<?php

_auth();

switch ( $action ) {
    
    case 'view-post':
		$url_blog=ORM::for_table('appconfig')->where('setting','url_blog')->find_one();
        $post = ORM::for_table('blog_posts')->find_one($routes[2]);
        $categories = ORM::for_table('blog_categories')->find_many();
        $urlPost = ORM::for_table('url_custom')->where('type','blog_posts')->where('id_rel',$post->id)->find_one();
        $users = ORM::for_table('admin_users')->find_many();
        $tags = ORM::for_table('blog_tag')->find_many();
        
        $js_footer = array( 'blog' );
        include( APP_URL.'view/page_ecom_blog_post.php' );
		break;
	case 'create-post':
		$url_blog=ORM::for_table('appconfig')->where('setting','url_blog')->find_one();
		$categories = ORM::for_table('blog_categories')->find_many();
		$users = ORM::for_table('admin_users')->find_many();
		$tags = ORM::for_table('blog_tag')->find_many();

        $js_footer = array( 'blog' );
        include( APP_URL.'view/page_ecom_blog_post.php' );
		break;
	case 'add-post':
		$public_date = \DateTime::createFromFormat("d/m/Y H:i", $_POST['fecha'])->format('Y-m-d H:i');
		$post = ORM::for_table('blog_posts')->where_like('name',$_POST['name'])->find_one();
		if($post->id){
			echo 'Ya existe un post creado con este mismo título';
			exit;
		}
		$post = ORM::for_table('blog_posts')->create();
		$post->name = $_POST['name'];
		$post->introduccion = $_POST['introduccion'];
		$post->descripcion = getbody(TildesHtml($_POST['texto']));
		$post->style = getstyle(TildesHtml($_POST['texto']),'');
		$post->imagen = $_POST['img_principal'];
		$post->id_admin_users = $_POST['id_admin_users'];
		$post->id_blog_categories = $_POST['category'];
		$post->meta_title = $_POST['title'];
		$post->meta_key = $_POST['keyword'];
		$post->meta_description = $_POST['description'];
		$post->fecha = $public_date;
		$post->in_index = $_POST['index'];
		$post->id_products = '';
		$post->id_categories = '';
		$post->id_blog_posts = '';

		if (is_active($_POST ['name'],$_POST ['category'],$_POST ['title'],$_POST ['description'])) {
			$post->active = ($_POST['borrador'] == 1)? 0:1;
		}else{
			$post->active = 0;
			echo 'Revisa los campos de name, categoria, metas o el texto del post<br>';
			exit;
		}

		$post->id_blog_tag = getTags($_POST['tag_pricipal'],$_POST['tags']);
		$post->id_blog_tag_principal = $_POST['id_blog_tag_principal'];

		if($post->save()){
			url_compare($_POST['url'],true);
			$post_url = validateUrl($_POST['url']);

			if(setURL($post->id, 'blog_posts', $post_url)){
				admin_log('Creado el post: '.$post->id);
				echo $post->id;
			}else{
				echo 'Algo ha fallado al crear la url del post';
			}
		}else{
			echo 'Algo ha fallado al crear el post';
		}
		break;
	case 'update-post':
		$public_date = \DateTime::createFromFormat("d/m/Y H:i", $_POST['fecha'])->format('Y-m-d H:i');
		$post = ORM::for_table('blog_posts')->find_one($routes[2]);
		$post->name = $_POST['name'];
		//$post->fecha = date("Y-m-d"); //actualiza la fecha de publicacion
		$post->introduccion = $_POST['introduccion'];
		$post->descripcion = getbody(TildesHtml($_POST['texto']));
		$post->style = getstyle(TildesHtml($_POST['texto']),$post->style);
		$post->id_admin_users = $_POST['id_admin_users'];
		$post->id_blog_categories = $_POST['category'];
		$post->meta_title = $_POST['title'];
		$post->meta_key = $_POST['keyword'];
		$post->meta_description = $_POST['description'];
		$post->fecha = $public_date;
		$post->in_index = $_POST['index'];
		
		if (is_active($_POST ['name'],$_POST ['category'],$_POST ['title'],$_POST ['description'])) {
			$post->active = ($_POST['borrador'] == 1)? 0:1;
		}else{
			$post->active = 0;
			echo 'Revisa los campos de name, categoria, metas o el texto del post<br>';
		}

		$post->id_blog_tag = getTags($_POST['id_blog_tag_principal'],$_POST['tags'],$post->id_blog_tag_principal,$post->id_blog_tag);
		$post->id_blog_tag_principal = $_POST['id_blog_tag_principal'];
		
		if($post->save()){
			url_compare($_POST['url']);
			$post_url = validateUrl($_POST['url']);

			if(setURL($post->id, 'blog_posts', $post_url)){
				admin_log('Actualizado el post: '.$post->id);
				echo $post->id;
			}else{
				echo 'Algo ha fallado al actualizar la url del post';
			}
		}else{
			echo 'Algo ha fallado al actualizar el post';
		}
		break;
	case 'text_update':
		$post = ORM::for_table('blog_posts')->find_one($_POST['id']);
		$post->descripcion = getbody(TildesHtml($_POST['texto']));
		$post->style = getstyle(TildesHtml($_POST['texto']),$post->style);
		if($post->save()){
			//admin_log('Actualizado el texto del post: '.$post->id);
			echo $post->id;
		}else{
			echo 'Algo ha fallado al actualizar el texto del post';
		}
		break;

	case 'content_update':
		$post = ORM::for_table('blog_posts')->find_one($routes[2]);
		$post->descripcion = getbody(TildesHtml($_POST['content']));
		$post->style = getstyle(TildesHtml($_POST['content']),$post->style);
		if($post->save()){
			//admin_log('Actualizado el texto del post: '.$post->id);
			echo 'Post guardado correctamente';
		}else{
			echo 'Algo ha fallado al actualizar el texto del post';
		}
		break;

	case 'add_tag':
		$tag = ORM::for_table('blog_tag')->create();
		$tag->name = $_POST['name'];

		if($tag->save()){
			admin_log('Creada la tag: '.$tag->name);
			if(isset($_POST['post_id'])){
				$post = ORM::for_table('blog_posts')->find_one($_POST['post_id']);
				$tagsId = array_filter(explode('|',$post->id_blog_tag));
			}
			$tags = ORM::for_table('blog_tag')->find_many();
			?>
			<div id="select_tag" class="col-md-10 pd-0">
				<select id="tags" name="tags[]" class="select-chosen" data-placeholder="Selecciona las etiquetas..." multiple>
					<?php foreach($tags as $tag){ ?>
					<option value='<?= $tag->id ?>' <?php if(isset($_POST['post_id'])){ if(in_array($tag->id,$tagsId)){ echo 'Selected'; } }?>><?= $tag->name ?></option>
					<?php } ?>
				</select>
			</div>
			<?php }else{
				echo 'Algo ha fallado al crear la etiqueta';
			}
		break;

	case 'related':
		$post = ORM::for_table('blog_posts')->find_one($_POST['post_id']);
		switch($_POST['action']){
			case 'act':
				admin_log('Actualizados productos relacionados del post: '.$post->id);
				$post->id_products .= '|'.$_POST['product'].'|'; 
				break;
			case 'del':
				admin_log('Borrados productos relacionados del post: '.$post->id);
				$post->id_products = str_replace('|'.$_POST['product'].'|','',$post->id_products);
				break;
		}
		if($post->save()){
			echo $post->id;
		}else{
			echo 'error';
		}
		break;

	case 'category_related':
		$post = ORM::for_table('blog_posts')->find_one($_POST['post_id']);
		switch($_POST['action']){
			case 'act':
				admin_log('Actualizadas categorias relacionadas del post: '.$post->id);
				$post->id_categories .= '|'.$_POST['category'].'|'; 
				break;
			case 'del':
				admin_log('Borradas categorias relacionadas del post: '.$post->id);
				$post->id_categories = str_replace('|'.$_POST['category'].'|','',$post->id_categories);
				break;
		}
		if($post->save()){
			echo $post->id;
		}else{
			echo 'error';
		}
		break;

	case 'post_related':
		$post = ORM::for_table('blog_posts')->find_one($_POST['post_id']);
		switch($_POST['action']){
			case 'act':
				admin_log('Actualizados post relacionados del post: '.$post->id);
				$post->id_blog_posts .= '|'.$_POST['post'].'|'; 
				break;
			case 'del':
				admin_log('Borrados post relacionados del post: '.$post->id);
				$post->id_blog_posts = str_replace('|'.$_POST['post'].'|','',$post->id_blog_posts);
				break;
		}
		if($post->save()){
			echo $post->id;
		}else{
			echo 'error';
		}
		break;

	case 'delete-post':
		$post = ORM::for_table('blog_posts')->find_one($routes[2]);
		$url = ORM::for_table('url_custom')->where('id_rel',$post->id)->where('type','blog_posts')->find_one();
		$id = $post->id;
		if($post->delete() && $url->delete()){
			admin_log('Borrado el post: '.$id);
			r2d2( URL_POST . 'blog_post', 's', 'Se ha borrado el post' );
		}else{
			r2d2( URL_POST . 'blog_post/view-post/' . $post->id, 'e', 'No se ha podido borrar el post' );
		}
		break;

	case 'get_categoryUrl':
		$ext = get_setting('url_extension');
		$url = ORM::for_table('url_custom')->where('id_rel',$_POST['categoria'])->where('type','blog_category')->find_one();
		echo str_replace($ext, "", $url->url);
		break;
	case 'reading_facility':
		include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/admin/lib/modules/reading_facility/reading_facility.php' );
		$rl = new get_level();

		//$url_page = ORM::for_table('url_custom')->where('type','blog_posts')->where('id_rel',$_POST['id'])->find_one();
		//echo $rl->byUrl(str_replace('admin/','',COMPLETE_URL) . $url_page->url);

		echo $rl->byContent($_POST['content']);
		break;
	default:
		$filters = 'blog_posts';
		include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/filters/query.php';
		/* devuelve la consulta en $results */

		$blog_categories = ORM::for_table('blog_categories')->find_many();

		$js_footer = array( 'blog' );
		include( APP_URL.'view/page_ecom_blog.php' );
		break;
}

function is_active($title,$category,$metaTitle,$metaDesc){
	//echo '1 '.$title;echo '2 '.$category;echo '3 '.$metaTitle;echo '4 '.$metaDesc;echo '5 '.$desc;exit;
	if ($title != '' && $category != '' && $metaTitle != '' && $metaDesc != '') {
		return true;
	}else{
		return false;
	}
}

function getTags($id_blog_tag_principal,$tags,$old_principal = false,$old_tags = false){
	// 1. Si la tag principal no esta la agrega
	// 2. Si la tag principal cambia, la modifica

	if (($old_principal == 0 || $old_tags == '') && empty($tags)) {
		//si el post no tiene tags asignadas no devuelve nada
		return '';
	}

	if($id_blog_tag_principal != $old_principal && is_array($tags)){
		//Si son distintas, quita la vieja si esta
		if (($key = array_search($old_principal, $tags)) !== false) {
			unset($tags[$key]);
		}
	}

	if (!in_array($id_blog_tag_principal,$tags) && $id_blog_tag_principal != 0) {
		//agrega la principal si no esta en el array
		array_push($tags,$id_blog_tag_principal);
	}

	$return = '|'.implode('||',$tags).'|';
	return $return;
}

function getbody($html) {
	$dom = new DOMDocument;
	$dom->loadHTML($html);
	$bodies = $dom->getElementsByTagName('body');
	assert($bodies->length === 1);
	$body = $bodies->item(0);
	for ($i = 0; $i < $body->children->length; $i++) {
		$body->remove($body->children->item($i));
	}
	$stringbody = $dom->saveHTML($body);
	if (preg_match('/(?:<body[^>]*>)(.*)<\/body>/isU', $stringbody, $matches)) {
        $body = $matches[1];
    }
	return $body;
}

function getstyle($html,$style) {
	$dom = new DOMDocument;
	$dom->loadHTML($html);
	$bodies = $dom->getElementById('vvvebjs-styles');

	return ($bodies->textContent != '')?$bodies->textContent : $style;
}

function TildesHtml($cadena) 
{ 
	return str_replace(
		array("á","é","í","ó","ú","ñ","Á","É","Í","Ó","Ú","Ñ","¡","!","º"),
		array("&aacute;","&eacute;","&iacute;","&oacute;","&uacute;","&ntilde;","&Aacute;","&Eacute;","&Iacute;","&Oacute;","&Uacute;","&Ntilde;","&iexcl;","&iexcl;",'&ordm;'), 
		$cadena);     
}

function url_compare($url,$add = false){
	$url_blog=ORM::for_table('appconfig')->where('setting','url_blog')->find_one();
	$ext = get_setting('url_extension');
	$Aurl = explode('/',$url);
	
	if($url_blog->value == 1){
		$cat = ORM::for_table('url_custom')->where('url',$Aurl[0].$ext)->find_one();
		if($cat->type != 'blog_category'){echo 'La parte de URL "'.$Aurl[0].$ext.'", no pertenece al blog';exit;}
	}
	$post = ORM::for_table('url_custom')->where('url',$url)->find_one();

	if($post && $post->type != 'blog_posts'){echo 'La URL "'.$url.'" no es válida';exit;}
}

function validateUrl($url){
	$qConfig = ORM::for_table('admin_modules_config')->where('type','blog_posts')->find_one();
	$config = json_decode($qConfig->content,true);
	$url_base = str_replace(get_extension(),'',$config['url_base']) . '/';
	$base = ($config['use_url_base']==1)?$url_base:'';

	if (strpos($url,$url_base)!==false) {
		return $url;
	}else{
		if($base!=''){
			return $base.$url;
		}else{
			return $url;
		}
	}
}
?>