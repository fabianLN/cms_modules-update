<?php
_auth();

switch ( $action ) {
    
    case 'view-category':
        $category = ORM::for_table('blog_categories')->find_one($routes[2]);
		$posts = ORM::for_table('blog_posts')->where('id_blog_categories',$routes[2])->find_many();
        $urlCategory = ORM::for_table('url_custom')->where('type','blog_categories')->where('id_rel',$category->id)->find_one();
        
        $js_footer = array( 'blog_categories' );
        include( APP_URL.'view/page_ecom_blog_category.php' );
    break;
    
    case 'create-category':
        $js_footer = array( 'blog_categories' );
        include( APP_URL.'view/page_ecom_blog_category.php' );
    break;

    case 'add-category':
		$category = ORM::for_table('blog_categories')->create();
		$category->icon = $_POST['icon'];
		$category->name = $_POST['name'];
		$category->description = $_POST['texto'];
		$category->meta_title = $_POST['title'];
		$category->meta_key = $_POST['keyword'];
		$category->meta_description = $_POST['description'];
		$category->slider = $_POST['index'];
		$category->index_position = ($_POST['index_position'])? $_POST['index_position'] : 0;

		$cat_url = validateUrl($_POST['url']);

		if($category->save()){
			if(setURL($category->id, 'blog_categories', $cat_url)){
				admin_log('Creada la categoría del blog: '.$category->name);
				echo $category->id;
			}else{
				echo 'Algo ha fallado al crear la url de la categoria';
			}
		}else{
			echo 'Algo ha fallado al crear la categoría';
		}
	break;

    case 'update-category':
		$category = ORM::for_table('blog_categories')->find_one($routes[2]);
		$category->icon = $_POST['icon'];
		$category->name = $_POST['name'];
		$category->description = $_POST['texto'];
		$category->meta_title = $_POST['title'];
		$category->meta_key = $_POST['keyword'];
		$category->meta_description = $_POST['description'];
		$category->slider = $_POST['index'];
		$category->index_position = $_POST['index_position'];

		if($category->save()){
			$cat_url = validateUrl($_POST['url']);

			if(setURL($category->id, 'blog_categories', $cat_url)){
				admin_log('Actualizada la categoría del blog: '.$category->name);
				echo $category->id;
			}else{
				echo 'Algo ha fallado al actualizar la url de la categoria';
			}
		}else{
			echo 'Algo ha fallado al actualizar la categoría';
		}
	break;
    
    case 'delete-category':
        $category = ORM::for_table('blog_categories')->find_one($routes[2]);
        $urlCategory = ORM::for_table('url_custom')->where('type','blog_categories')->where('id_rel',$category->id)->find_one();
		$name = $category->name;
        
		$existen = ORM::for_table('blog_posts')->where('id_blog_categories',$routes[2])->find_one();
		if ($existen) {
			r2d2( URL_POST . 'blog_categories/view-category/' . $category->id, 'e', 'No se ha podido borrar la categoría, tiene post asociados' );
		}

		if($category->delete() && $urlCategory->delete()){
			admin_log('Borrada la categoría del blog: '.$name);
			r2d2( URL_POST . 'blog_categories', 's', 'Se ha borrado la categoría' );
		}else{
			r2d2( URL_POST . 'blog_categories/view-category/' . $category->id, 'e', 'No se ha podido borrar la categoría' );
		}
    break;

    default:
        $filters = 'blog_categories';
        include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/filters/query.php';
        /* devuelve la consulta en $results */

		include( APP_URL.'view/page_ecom_blog_categories.php' );
		break;
}

function validateUrl($url){
	$qConfig = ORM::for_table('admin_modules_config')->where('type','blog_posts')->find_one();
	$config = json_decode($qConfig->content,true);
	$url_base = str_replace(get_extension(),'',$config['url_base']) . '/';
	$base = ($config['use_url_base']==1)?$url_base:'';

	if (strpos($url,$url_base)!==false) {
		return $url;
	}else{
		if($base!=''){
			return $base.$url;
		}else{
			return $url;
		}
	}
}
?>