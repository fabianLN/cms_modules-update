<?php
_auth();

switch ( $action ) {
    
    case 'view-tag':
        $tag = ORM::for_table('blog_tag')->find_one($routes[2]);
		$posts = ORM::for_table('blog_posts')->where('id_blog_tag',$routes[2])->find_many();
        
        $js_footer = array( 'blog_tags' );
        include( APP_URL.'view/page_ecom_blog_tag.php' );
    break;
    
    case 'create-tag':
        
        $js_footer = array( 'blog_tags' );
        include( APP_URL.'view/page_ecom_blog_tag.php' );
    break;

    case 'add-tag':
		$tag = ORM::for_table('blog_tag')->create();
		$tag->name = $_POST['name'];

		if($tag->save()){
            admin_log('Creada la etiqueta del blog: '.$tag->name);
            echo $tag->id;
		}else{
			echo 'Algo ha fallado al crear la etiqueta';
		}
	break;

    case 'update-tag':
		$tag = ORM::for_table('blog_tag')->find_one($routes[2]);
		$tag->name = $_POST['name'];

		if($tag->save()){
            autoRedirect($old,$new,$tag->id,'blog_tag');
            admin_log('Actualizada la etiqueta del blog: '.$tag->name);
            echo $tag->id;
		}else{
			echo 'Algo ha fallado al actualizar la etiqueta';
		}
	break;
    
    case 'delete-tag':
        $tag = ORM::for_table('blog_tag')->find_one($routes[2]);
		$name = $tag->name;
        
		$existen = ORM::for_table('blog_posts')->where('id_blog_tag',$routes[2])->find_one();
		if ($existen) {
			r2d2( URL_POST . 'blog_tags/view-tag/' . $tag->id, 'e', 'No se ha podido borrar la etiqueta, tiene post asociados' );
		}

		if($tag->delete()){
			admin_log('Borrada la etiqueta del blog: '.$name);
			r2d2( URL_POST . 'blog_tags', 's', 'Se ha borrado la etiqueta' );
		}else{
			r2d2( URL_POST . 'blog_tags/view-tag/' . $tag->id, 'e', 'No se ha podido borrar la etiqueta' );
		}
    break;

    default:
        $filters = 'blog_tag';
        include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/filters/query.php';
        /* devuelve la consulta en $results */

        $js_footer = array( 'blog_tags' );
		include( APP_URL.'view/page_ecom_blog_tags.php' );
		break;
}

?>