$('.crearcategory').click(function(){
	var icon = $('#category-icon').val();//name
	var name = $('#category-name').val();//name
	var texto = CKEDITOR.instances['ckeditor'].getData()//texto
	var url = $('#category-url').val();//url
	var title = $('#category-meta-title').val();//title
	var keyword = $('#category-meta-keywords').val();//keyword
	var description = $('#category-meta-description').val();//description
	var index = ($("#category-index").is(":checked")) ? 1 : 0
	var index_position = $('#index_position').val()

	if(name != '' && url != ''){
		$.ajax({
			method: "POST",
			url: '?cf=blog_categories/add-category',
			data: {
				icon:icon,
				name:name,
                url:url,
                texto:texto,
                title:title,
				keyword:keyword,
				description:description,
				index:index,
				index_position:index_position,
			},
			async: false
		}).done(function (data) {
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Categoría guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		location.href = '?cf=blog_categories/view-category/' + data_basic;
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('.guardarcategoryV').click(function(){
	var id = $('#category-id').val();//id
	var icon = $('#category-icon').val();//name
    var name = $('#category-name').val();//name
    var texto = CKEDITOR.instances['ckeditor'].getData()//texto
	var url = $('#category-url').val();//url
	var title = $('#category-meta-title').val();//title
	var keyword = $('#category-meta-keywords').val();//keyword
	var description = $('#category-meta-description').val();//description
	var index = ($("#category-index").is(":checked")) ? 1 : 0
	var index_position = $('#index_position').val()

	if(name != '' && url != ''){
		$.ajax({
			method: "POST",
			url: '?cf=blog_categories/update-category/'+id,
			data: {
				icon:icon,
				name:name,
				texto:texto,
                url:url,
                title:title,
				keyword:keyword,
				description:description,
				index:index,
				index_position:index_position,
			},
			async: false
		}).done(function (data) {
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Categoría guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		//location.href = '?cf=blog/view-category/' + data_basic; //al actualizar no hace falta recargar la pag ya que los cambios quedan registrados
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('.namecategory').on('input',function(){
	var name = $('#category-name').val().toLowerCase().normalize('NFKD').replace(/[^\w\s.-_\/]/g, '').replace(/ /g,'-').replace(/\?/g, '');
	$('#category-url').val(name);
});