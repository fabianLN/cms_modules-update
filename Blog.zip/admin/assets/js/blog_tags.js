$(function(){ EcomOrders.init(); });
$(document).ready(function() {
    $('#ecom-blog_post').DataTable();
} );

$('.creartag').click(function(){
	var name = $('#tag-name').val();//name
	if(name != ''){
		$.ajax({
			method: "POST",
			url: '?cf=blog_tags/add-tag',
			data: {
				name:name,
			},
			async: false
		}).done(function (data) {
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Etiqueta guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		location.href = '?cf=blog_tags/view-tag/' + data_basic;
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('.guardartagV').click(function(){
	var id = $('#tag-id').val();//id
    var name = $('#tag-name').val();//name
	if(name != ''){
		$.ajax({
			method: "POST",
			url: '?cf=blog_tags/update-tag/'+id,
			data: {
				name:name
			},
			async: false
		}).done(function (data) {
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Etiqueta guardada con éxito</div>');
		$(".avisoOpciones").show('slow');
		//location.href = '?cf=blog/view-tag/' + data_basic; //al actualizar no hace falta recargar la pag ya que los cambios quedan registrados
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('.nametag').on('input',function(){
	var name = $('#tag-name').val().toLowerCase().normalize('NFKD').replace(/[^\w\s.-_\/]/g, '').replace(/ /g,'-').replace(/\?/g, '');
	$('#tag-url').val(name);
});