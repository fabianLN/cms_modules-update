$(document).ready(function() {
	if($('.datepicker').length > 0){
		$('.datepicker').flatpickr({ "dateFormat":"d/m/Y H:i","locale":"es","minuteIncrement":"1" });
	}
});

$(document).ready(function() {
    let typingTimer; // Temporizador de espera
    const doneTypingInterval = 2000; // Intervalo de 5 segundos

    // Escuchar el evento de instancia lista de CKEditor
	if (typeof CKEDITOR !== 'undefined' && Object.keys(CKEDITOR.instances).length > 0) {
		CKEDITOR.on('instanceReady', function(event) {
			var editor = event.editor;

			// Escuchar el evento de cambio en el editor
			editor.on('change', function () {
				clearTimeout(typingTimer); // Reiniciar el temporizador
				typingTimer = setTimeout(function () {
					// Acción después de 5 segundos de inactividad
					const content = editor.getData();

					$.ajax({
						method: "POST",
						url: '?cf=blog_post/reading_facility',
						data: {
							content
						},
						async: false
					}).done(function (data) {
						value = JSON.parse(data);
						$('.reading_facility').text('Lectura: '+value.text);
						$('.reading_facility').css('backgroundColor', value.color);
						$('.reading_facility').attr('data-original-title', 'El texto tiene una facilidad de lectura de '+value.score+' sobre 100');
					});
				}, doneTypingInterval);
			});
		});
	}
});

$('.crearPost').click(function(){
	var name = $('#post-name').val();//name
	var category = $('#post-category').val();//categoria
	var introduccion = CKEDITOR.instances['ckeditor-introduccion'].getData()//introduccion
	var texto = CKEDITOR.instances['ckeditor'].getData()//texto
	var img_principal = '';//img principal
	var id_admin_users = $('#creado-por').val();//creado por
	var url = $('#post-url').val();//url
	var title = $('#post-meta-title').val();//title
	var keyword = $('#post-meta-keywords').val();//keyword
	var description = $('#post-meta-description').val();//description
	var id_blog_tag_principal = $('#id_blog_tag_principal').val(); //id_blog_tag_principal
	var tags = $('#tags').val(); //tags
	var fecha = $('#publicacion').val(); //fecha
	var borrador = $(this).data('borrador');
	var index = ($("#post-index").is(":checked")) ? 1 : 0

	if(name != '' && url != '' && id_blog_tag_principal != ''){
		$.ajax({
			method: "POST",
			url: '?cf=blog_post/add-post',
			data: {
				name:name,
				category:category,
				introduccion:introduccion,
				texto:texto,
				img_principal:img_principal,
				id_admin_users:id_admin_users,
				url:url,title:title,
				keyword:keyword,
				description:description,
				id_blog_tag_principal:id_blog_tag_principal,
				tags:tags,
				fecha:fecha,
				borrador:borrador,
				index:index,
			},
			async: false
		}).done(function (data) {
			$('#post_img_id').val(data)
			save_img_blog()
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Post guardado con éxito</div>');
		$(".avisoOpciones").show('slow');
		setTimeout(function() {
			// Redirigir la página después de 1 segundo
			location.href = '?cf=blog_post/view-post/' + data_basic;
		}, 1000);
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('.guardarpostV').click(function(){
	var id = $('#post-id').val();//id
	var name = $('#post-name').val();//name
	var category = $('#post-category').val();//categoria
	var introduccion = CKEDITOR.instances['ckeditor-introduccion'].getData()//introduccion
	var texto = CKEDITOR.instances['ckeditor'].getData()//texto
	var img_principal = '';//img principal
	var id_admin_users = $('#creado-por').val();//creado por
	var url = $('#post-url').val();//url
	var title = $('#post-meta-title').val();//title
	var keyword = $('#post-meta-keywords').val();//keyword
	var description = $('#post-meta-description').val();//description
	var id_blog_tag_principal = $('#id_blog_tag_principal').val(); //id_blog_tag_principal
	var tags = $('#tags').val(); //tags
	var fecha = $('#publicacion').val(); //fecha
	var borrador = $(this).data('borrador');
	var index = ($("#post-index").is(":checked")) ? 1 : 0
	
	if(name != '' && url != '' && id_blog_tag_principal != ''){
		$.ajax({
			method: "POST",
			url: '?cf=blog_post/update-post/'+id,
			data: {
				name:name,
				category:category,
				introduccion:introduccion,
				texto:texto,
				img_principal:img_principal,
				id_admin_users:id_admin_users,
				url:url,
				title:title,
				keyword:keyword,
				description:description,
				id_blog_tag_principal:id_blog_tag_principal,
				tags:tags,
				fecha:fecha,
				borrador:borrador,
				index:index,
			},
			async: false
		}).done(function (data) {
			data_basic = data;
		});
	} else {
		data_basic = 'Hay campos obligatorios vacios';
	}

	if ($.isNumeric(data_basic)) {
		$(".avisoOpciones").remove();
		$("#page-content").prepend('<div class="alert alert-success avisoOpciones" style="display:none" role="alert">Post guardado con éxito</div>');
		$(".avisoOpciones").show('slow');
		if(!is_active(name,category,img_principal,title,description,texto)){
			$('.etiqueta_estado').removeClass('label-success').addClass('label-info').text('Borrador');
		}else{
			$('.etiqueta_estado').removeClass('label-info').addClass('label-success').text('Publicado');
		}
		//location.href = '?cf=blog_post/view-post/' + data_basic; //al actualizar no hace falta recargar la pag ya que los cambios quedan registrados
	}else{
		$(".avisoOpciones").remove();
			$("#page-content").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">' + data_basic + '</div>');
			$(".avisoOpciones").show('slow');
	}
});


$('#post-category').on('change',function(){
	const categoria = $('#post-category').val()
	const name = $('#post-name').val().toLowerCase().normalize('NFKD').replace(/[^\w\s.-_\/]/g, '').replace(/ /g,'-').replace(/\?/g, '').replace(/\./g, '')
	const ext = $('#ext').val()
	const blog_url = $('#blog_url').val()
	if(blog_url == 1){
		$.ajax({
			method: "POST",
			url: '?cf=blog_post/get_categoryUrl',
			data: {
				categoria,
			},
			async: false
		}).done(function (data) {
			$('#post-url').val(data+'/'+name+ext);
		});
	}else{
		$('#post-url').val(name+ext);
	}
});

$('#post-name').on('input',function(){
	const categoria = $('#post-category').val()
	const name = $('#post-name').val().toLowerCase().normalize('NFKD').replace(/[^\w\s.-_\/]/g, '').replace(/ /g,'-').replace(/\?/g, '').replace(/\./g, '')
	const ext = $('#ext').val()
	const blog_url = $('#blog_url').val()
	if(blog_url == 1){
		$.ajax({
			method: "POST",
			url: '?cf=blog_post/get_categoryUrl',
			data: {
				categoria,
			},
			async: false
		}).done(function (data) {
			$('#post-url').val(data+'/'+name+ext);
		});
	}else{
		$('#post-url').val(name+ext);
	}
});

$('#addTag').on('click',function(){
	bootbox.dialog({ 
		size: "medium",
		title: "Crear nueva etiqueta",
		message: add_tag,
	});
});

function create_tag(){
	var name = $('#tag_name').val();
	var id = $('#post-id').val();
	if(name.length>0){
		$.ajax({
			method: "POST",
			url: '?cf=blog_post/add_tag',
			data: {
				name:name,
				post_id:id,
			},
			async: false
		}).done(function (data) {
			$('.bootbox-close-button').click();
			$('#select_tag').replaceWith(data);
			$('#tags').select2({
				width:'100%'
			});
		});
	}else{
		$('#tag_name').css('border','1px solid red');
	}
}

$('#ecom-products-blog').on('change','.product-related',function(){
	if($(this).prop('checked')){
		var action = 'act';
	}else{
		var action = 'del';
	}
	var product = $(this).data('product');
	var post_id = $('#post_id').val();

	$.ajax({
		method: "POST",
		url: '?cf=blog_post/related',
		data: {
			action:action,
			product:product,
			post_id:post_id
		}
	}).done(function (data) { });
});

$('.post-related').on('change',function(){
	if($(this).prop('checked')){
		var action = 'act';
	}else{
		var action = 'del';
	}
	var post = $(this).data('post');
	var post_id = $('#post_id').val();

	$.ajax({
		method: "POST",
		url: '?cf=blog_post/post_related',
		data: {
			action:action,
			post:post,
			post_id:post_id
		}
	}).done(function (data) { });
});

$('.category-related').on('change',function(){
	if($(this).prop('checked')){
		var action = 'act';
	}else{
		var action = 'del';
	}
	var category = $(this).data('category');
	var post_id = $('#post_id').val();

	$.ajax({
		method: "POST",
		url: '?cf=blog_post/category_related',
		data: {
			action:action,
			category:category,
			post_id:post_id
		}
	}).done(function (data) { });
});

function is_active(title,category,imagen,metaTitle,metaDesc,desc){
	if (title != '' && category != '' && imagen != '' && metaTitle != '' && metaDesc != '' && desc != '') {
		return true;
	}else{
		return false;
	}
}


/* update tab */
$('.updateText').on('click',function(){
	var id = $('#post-id').val();//id
	var texto = CKEDITOR.instances['ckeditor'].getData()//texto

	window.location = '/admin/lib/modules/VvvebJs/editor_post.php?action=post_text&post='+id
	
	/*
	$(".avisoOpciones").remove();
	$.ajax({
		url: '?cf=blog_post/text_update',
		method: 'POST',
		data: {
			id:id,
			texto:texto,
		},
		success: function(data){
			if(!$.isNumeric(data)){
				var a = 'danger';
				$("#page-content").prepend('<div class="alert alert-'+a+' avisoOpciones" style="display:none" role="alert">' + data + '</div>');
				$(".avisoOpciones").show('slow');
			}else{
				window.location = '/admin/lib/modules/VvvebJs/editor_post.php?action=post_text&post='+id
			}
		}
	});
	*/
})

/* tabla de productos relacionados */
$(function(){ 
	EcomOrders.init(); 
	$('#ecom-blog_post').DataTable();
	$('#ecom-blog_post').DataTable();
	$("#ecom-products-blog").DataTable().destroy();
	table = $("#ecom-products-blog").DataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
            'url': "/admin/lib/modules/dataTables/basic_products.php",
            "type": "POST",
			"data": {
				"route1": $('#products-related').val()
			},
        },
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': ''
		},
		"columns": [
			{ data: 0,render: function (data, type, row) {
				let ids = $('#products-related').val().split(',')
				if (ids.indexOf(data) !== -1) {
					return '<label class="switch switch-success"><input type="checkbox" class="product-related" name="product-related" checked data-product="'+data+'"><span></span></label>';
				}else{
					return '<label class="switch switch-success"><input type="checkbox" class="product-related" name="product-related" data-product="'+data+'"><span></span></label>';
				}
			} },
			{ data: 1,render: function (data, type, row) { var arr = Object.keys(row).map(function (key) { return row[key]; });return '<a href="?cf=products/view-product/'+arr[0]+'"><strong>'+arr[0]+'/'+data+'</strong></a>'; } },
			{ data: 2,render: function (data, type, row) { var arr = Object.keys(row).map(function (key) { return row[key]; });return '<a href="?cf=products/view-product/'+arr[0]+'"><strong>'+data+'</strong></a>'; } },
		],
		"columnDefs": [{
			"targets": 0,
			"orderable": false,
			className: 'text-center'
		},{
			"targets": 1,
			className: 'text-center'
		},{
			"targets": 2,
			className: 'w-75'
		}
		],
		"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Todas"]]
	} );
});

var dropzoneImg;

dropzoneImg = $("#my-awesome-dropzone").dropzone({
	maxFiles: 10,
	maxFilesize: 2,
	url: URL + "lib/modules/ImageCache/blog-img-upload.php",
	success: function (file, response) {
		this.removeFile(file);
		reloadImg(response);
	}
});

dropzoneImgNew = $("#my-awesome-dropzone-new").dropzone({
	autoProcessQueue: false,
	maxFiles: 10,
	maxFilesize: 3,
	url: URL + "lib/modules/ImageCache/blog-img-upload.php",
	init: function() {
		this.on("sending", function(file, xhr, formData) {
			formData.append("post_img_id", $('#post_img_id').val());
		});
	},
	success: function (file, response) {
		this.removeFile(file);
		reloadImg(response);
	}
});

const save_img_blog = () => {
	dropzoneImgNew[0].dropzone.processQueue();
}

const reloadImg = (img) => {
	$('#image-preview').attr('src',img+'?'+Math.random())
}