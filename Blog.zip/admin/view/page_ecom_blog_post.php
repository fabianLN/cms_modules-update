<?php include 'sections/template_start.php';?>
<?php include 'sections/page_head.php';?>
<!-- Page content -->
<div id="page-content">
    <!-- post Edit Content -->
    <?php if (isset($routes[2])) {?>
        <div class="row">
			<div class="col-lg-9">
				<div class="block">
					<div class="block-title">
					<?php
					$labels['0']['class']   = "label-info";
					$labels['0']['text']    = "Borrador";
					$labels['1']['class']   = "label-success";
					$labels['1']['text']    = "Publicado";
					?>
						<h2>
							<i class="fa fa-pencil"></i>
							<strong>Datos</strong>
							generales
						</h2>
						<span class="etiqueta_estado label<?php echo ($labels[$post->active]['class']) ? " " . $labels[$post->active]['class'] : ""; ?>"><?php echo $labels[$post->active]['text']; ?></span>
						<a href="javascript:void(0)" id="backLink" data-toggle="tooltip" title="Atrás" class="pull-right btn btn-warning"><i class="gi gi-delete"></i> Atrás</a>
						<button class="btn btn btn-success pull-right mr-10 guardarpostV"><i class="fa fa-floppy-o"></i> Guardar</button>
						<button class="btn btn btn-info pull-right mr-10 guardarpostV" data-borrador="1"><i class="fa fa-floppy-o"></i> Borrador</button>
						<a href="#modalDeletepost" class="btn btn btn-danger pull-right mr-10 deleteField" url_action="<?=URL_POST?>blog_post/delete-post/<?=$post->id?>"><i class="fas fa-trash-alt"></i> Borrar</a>
					</div>
					<div class="row">
						<input type="hidden" value="<?=$post->id?>" id="post_id" name="post_id">
						<div class="col-md-2">
							<label for="post-id">Id</label>
							<div>
								<input type="text" id="post-id" name="post-id" class="form-control" value="<?=$post->id?>" disabled>
							</div>
						</div>
						<div class="col-md-7">
							<label for="post-name">Título</label>
							<div>
								<input type="text" id="post-name" name="post-name" class="form-control" value="<?=$post->name?>">
							</div>
						</div>
						<div class="col-md-3">
							<label for="post-categoria">Categoría</label>
							<div>
							<?php $ext = get_setting('url_extension'); ?>
							<input type="hidden" id="ext" value="<?=$ext?>">
							<select id="post-category" name="post-categoria" class="select-chosen" data-placeholder="Selecciona la categoria del post..." style="width: 250px;">
									<option>Selecciona una categoría</option>
									<?php foreach ($categories as $categoria) {?>
										<option value='<?=$categoria->id?>' <?php if ($post->id_blog_categories == $categoria->id) {echo 'selected';}?>><?=$categoria->name?></option>
									<?php }?>
								</select>
							</div>
						</div>
						<div class="col-md-12 mt-20 pd-0">
							<div class="col-md-3">
								<label for="creado-por">Creado por</label>
								<div>
								<select id="creado-por" name="creado-por" class="select-chosen" data-placeholder="Selecciona el creador del post..." style="width: 250px;">
									<?php foreach($users as $user){ ?>
									<option value='<?= $user->id ?>' <?php if($post->admin_users == $user->id){ echo 'Selected'; } ?>><?= $user->nombre ?></option>
									<?php } ?>
								</select>
								<small>*No se muestran los usuarios desactivados</small>
								</div>
							</div>
							<div class="col-md-7">
								<div class="col-md-4">
									<label for="tags">Etiqueta principal</label>
									<div class="col-md-12 pd-0">
										<div  id="select_tag">
											<select id="id_blog_tag_principal" name="id_blog_tag_principal" class="select-chosen" data-placeholder="Selecciona la etiqueta principal...">
												<option value="0">Selecciona una etiqueta...</option>
												<?php foreach($tags as $tag){ ?>
												<option value='<?= $tag->id ?>' <?php if($tag->id == $post->id_blog_tag_principal){ echo 'Selected'; } ?>><?= $tag->name ?></option>
												<?php } ?>
											</select>
										</div>
									</div>		
								</div>
								<div class="col-md-8">
									<label for="tags">Etiquetas</label>
									<div class="col-md-12 pd-0">
										<div  id="select_tag" class="col-md-9 pl-0">
											<?php $tagsId = array_filter(explode('|',$post->id_blog_tag)); ?>
											<select id="tags" name="tags[]" class="select-chosen" data-placeholder="Selecciona las etiquetas..." multiple>
												<?php foreach($tags as $tag){ ?>
												<option value='<?= $tag->id ?>' <?php if(in_array($tag->id,$tagsId)){ echo 'Selected'; } ?>><?= $tag->name ?></option>
												<?php } ?>
											</select>
										</div>
										<div class="col-md-3 pr-0">
											<a href="javascript:void(0)" id="addTag" class="btn btn-alt btn-sm pull-right btn-success" data-toggle="tooltip" title="Añadir nueva"><i class="fa fa-plus"></i> Crear nueva</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="publicacion">Fecha de publicación</label>
									<?php $public_date = ($post->fecha != '')? $post->fecha : date('Y-m-d H:i:s') ?>
									<input id="publicacion" class="form-control bg-white datepicker" data-date-format="m/d/Y G:iK" data-enable-time="true" value="<?=date("d/m/Y H:i:s", strtotime($public_date))?>">
								</div>
							</div>
						</div>
					</div>
					<div class="mt-20 row mb-20">
						<div class="col-md-8">
							<div class="form-group">
								<label class="col-md-12" for="post-introduccion">Introducción</label>
								<div class="col-md-12">
									<textarea id="ckeditor-introduccion" name="ckeditor-introduccion" class="ckeditor">
										<?=$post->introduccion?>
									</textarea>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<label class="col-md-12 pl-0">Arrastrar imagen principal</label>
							<form id="my-awesome-dropzone" class="dropzone mt-20" method="post">
								<input type="hidden" name="post_img_id" id="post_img_id" value="<?=$post->id?>">
							</form>
							<img id="image-preview" src="<?=$web.'/public/media/blog/blog-peq/'.$post->imagen?>" alt="<?=$post->name?>" style="width: 65%;margin-top: 15px;">
						</div>
					</div>
					<div class="mt-20 row mb-20">
						<div class="form-group">
							<label class="col-md-10" for="post-description">Descripción <span class="reading_facility" data-toggle="tooltip" data-placement="top" data-original-title=""></span></label>
							<div class="col-md-12">
								<button class="btn btn btn-success pull-right mr-10 updateText"><i class="fa fa-pencil"></i> Editor avanzado</button>
								<textarea id="ckeditor" name="descripcion" class="ckeditor"><?=$post->descripcion?></textarea>
							</div>
						</div>
					</div>
				</div>

			</div>
			<div class="col-lg-3">
				<!-- Meta Data Block -->
				<div class="block">
					<!-- Meta Data Title -->
					<div class="block-title">
						<h2><i class="fab fa-google"></i>
							<strong>SEO</strong>
						</h2>
					</div>
					<div class="form-horizontal form-bordered">
						<div class="form-group">
							<label class="col-md-3 control-label">Mostrar en index</label>
							<div class="col-md-9">
								<label class="switch switch-success">
								<input type="checkbox" id="post-index" name="post-index" <?php if ($post->in_index == 1) {echo 'checked';}?>>
								<span></span>
								</label>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-url">URL</label>
							<div class="col-md-9">
								<input type="text" id="post-url" name="post-url" class="form-control" placeholder="Introduce una url..." value="<?=$urlPost->url?>">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-meta-title">Meta Title</label>
							<div class="col-md-9">
								<input type="text" id="post-meta-title" name="post-meta-title" class="form-control" placeholder="Introduce el meta title..." value="<?=$post->meta_title?>">
								<div class="help-block">55 Carácteres Max</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-meta-keywords">Meta Keywords</label>
							<div class="col-md-9">
								<input type="text" id="post-meta-keywords" name="post-meta-keywords" class="form-control" placeholder="keyword1, keyword2, keyword3" value="<?=$post->meta_key?>">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-meta-description">Meta Description</label>
							<div class="col-md-9">
								<textarea id="post-meta-description" name="post-meta-description" class="form-control" rows="6" placeholder="Introduce meta description..."><?=$post->meta_description?></textarea>
								<div class="help-block">115 Carácteres Max</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<!-- post relacionadas -->
				<div class="panel panel-default">
					<div class="panel-heading" role="tab" id="post-cparent">
						<a role="button" class="btn linkCollapse collapsed" data-toggle="collapse" data-parent="#accordion" href="#post-edit" aria-expanded="false" aria-controls="collapseOne">
						<i class="far fa-random"></i> <strong>Post relacionados</strong>
						</a>
					</div>
					<div id="post-edit" class="panel-collapse collapse" role="tabpanel" aria-labelledby="post-cparent" aria-expanded="false" style="height: 0px;padding-top: 20px;">
						<?php if($post->id_blog_posts){ ?>
						<?php $idsRelated = array_values(array_filter(explode('|',$post->id_blog_posts))) ?>
						<?php $postRelacionadas = ORM::for_table('blog_posts')->where_in('id',$idsRelated)->find_many(); ?>
						<?php $postsRelated = ORM::for_table('blog_posts')->where_not_in('id',$idsRelated)->find_many(); ?>
						<?php }else{
							$postsRelated = ORM::for_table('blog_posts')->where_not_equal('id',$post->id)->find_many();
						} ?>
						<div class="panel-body">
							<!-- categorias -->
							<table id="ecom-related-blog" class="table table-bordered table-striped table-vcenter">
								<thead>
									<tr>
										<th class="text-center">Relacionado</th>
										<th class="text-center">ID</th>
										<th class="text-center">Nombre</th>
									</tr>
								</thead>
								<tbody>
									<?php if($postRelacionadas){ foreach ($postRelacionadas as $postRelated) {?>
									<tr>
										<td class="text-center" width="20%"><label class="switch switch-success"><input type="checkbox" class="post-related" name="post-related" checked data-post="<?=$postRelated->id?>"><span></span></label></td>
										<td class="text-center"><a href="?cf=categories/view-post/<?=$postRelated->id?>"><strong><?=$postRelated->id?></strong></a></td>
										<td class="text-center"><a href="?cf=categories/view-post/<?=$postRelated->id?>"><strong><?=$postRelated->name?></strong></a></td>
									</tr>
									<?php } } ?>
									<?php foreach ($postsRelated as $postRelated) {?>
									<tr>
										<td class="text-center" width="20%"><label class="switch switch-success"><input type="checkbox" class="post-related" name="post-related" data-post="<?=$postRelated->id?>"><span></span></label></td>
										<td class="text-center"><a href="?cf=categories/view-post/<?=$postRelated->id?>"><strong><?=$postRelated->id?></strong></a></td>
										<td class="text-center"><a href="?cf=categories/view-post/<?=$postRelated->id?>"><strong><?=$postRelated->name?></strong></a></td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<!-- categorias relacionadas -->
				<?php $test_categories = ORM::forTable('')->raw_query('SHOW TABLES LIKE "categories"')->findMany()->count(); ?>
				<?php if($test_categories){?>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="category-cparent">
							<a role="button" class="btn linkCollapse collapsed" data-toggle="collapse" data-parent="#accordion" href="#category-edit" aria-expanded="false" aria-controls="collapseOne">
							<i class="far fa-random"></i> <strong>Categorías relacionadas</strong>
							</a>
						</div>
						<div id="category-edit" class="panel-collapse collapse" role="tabpanel" aria-labelledby="category-cparent" aria-expanded="false" style="height: 0px;padding-top: 20px;">
							<?php if($post->id_blog_categoriess){ ?>
							<?php $idsRelated = array_values(array_filter(explode('|',$post->id_blog_categoriess))) ?>
							<?php $categoriasRelacionadas = ORM::for_table('categories')->where_in('id',$idsRelated)->find_many(); ?>
							<?php $categorias = ORM::for_table('categories')->where_not_in('id',$idsRelated)->find_many(); ?>
							<?php }else{
								$categorias = ORM::for_table('categories')->find_many();
							} ?>
							<div class="panel-body">
								<!-- categorias -->
								<table id="ecom-categories-blog" class="table table-bordered table-striped table-vcenter">
									<thead>
										<tr>
											<th class="text-center">Relacionado</th>
											<th class="text-center">ID</th>
											<th class="text-center">Nombre</th>
										</tr>
									</thead>
									<tbody>
										<?php if($categoriasRelacionadas){ foreach ($categoriasRelacionadas as $categoria) {?>
										<tr>
											<td class="text-center" width="20%"><label class="switch switch-success"><input type="checkbox" class="category-related" name="category-related" checked data-category="<?=$categoria->id?>"><span></span></label></td>
											<td class="text-center"><a href="?cf=categories/view-category/<?=$categoria->id?>"><strong><?=$categoria->id?></strong></a></td>
											<td class="text-center"><a href="?cf=categories/view-category/<?=$categoria->id?>"><strong><?=$categoria->name?></strong></a></td>
										</tr>
										<?php } } ?>
										<?php foreach ($categorias as $categoria) {?>
										<tr>
											<td class="text-center" width="20%"><label class="switch switch-success"><input type="checkbox" class="category-related" name="category-related" data-category="<?=$categoria->id?>"><span></span></label></td>
											<td class="text-center"><a href="?cf=categories/view-category/<?=$categoria->id?>"><strong><?=$categoria->id?></strong></a></td>
											<td class="text-center"><a href="?cf=categories/view-category/<?=$categoria->id?>"><strong><?=$categoria->name?></strong></a></td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				<?php } ?>
				<!-- productos relacionados -->
				<?php $test_products = ORM::forTable('')->raw_query('SHOW TABLES LIKE "products"')->findMany()->count(); ?>
				<?php if($test_products){?>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="filter-cparent">
							<a role="button" class="btn linkCollapse collapsed" data-toggle="collapse" data-parent="#accordion" href="#filter-edit" aria-expanded="false" aria-controls="collapseOne">
							<i class="far fa-random"></i> <strong>Productos relacionados</strong>
							</a>
						</div>
						<div id="filter-edit" class="panel-collapse collapse" role="tabpanel" aria-labelledby="filter-cparent" aria-expanded="false" style="height: 0px;padding-top: 20px;">
							<div class="panel-body">
								<!-- productos -->
								<?php
									if($post->id_products){
										$idsRelated_p = array_values(array_filter(explode('|',$post->id_products)));
									}
								?>
								<input type="hidden" id="products-related" value="<?php if(!empty($idsRelated_p)){echo implode(',',$idsRelated_p);}else{echo 'undefined';}?>">
								<table id="ecom-products-blog" class="table table-bordered table-striped table-vcenter" style="width: 100%;">
									<thead>
										<tr>
											<th class="text-center">Relacionado</th>
											<th class="text-center">ID/SKU</th>
											<th class="text-center" width="100%">Nombre</th>
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
    <?php } else {?>
		<div class="row">
			<div class="col-lg-9">
				<div class="block">
					<div class="block-title">
						<h2><i class="fa fa-pencil"></i>
							<strong>Datos</strong>
							generales</h2>
						<a href="<?=$_SESSION['prevpag']?>" data-toggle="tooltip" title="Atrás" class="pull-right btn btn-warning"><i class="gi gi-delete"></i> Atrás</a>
						<button class="btn btn btn-success pull-right mr-10 crearPost"><i class="fa fa-floppy-o"></i> Guardar</button>
						<button class="btn btn btn-info pull-right mr-10 crearPost" data-borrador="1"><i class="fa fa-floppy-o"></i> Borrador</button>
					</div>
					<div class="row">
						<div class="col-md-9">
							<label for="post-name">Título</label>
							<div>
								<input type="text" id="post-name" name="post-name" class="form-control namePost" value="">
							</div>
						</div>
						<div class="col-md-3">
							<label for="post-categoria">Categoría</label>
							<div>
							<select id="post-category" name="post-categoria" class="select-chosen categoriasPost" data-placeholder="Selecciona la categoria del post..." style="width: 250px;">
									<?php foreach ($categories as $categoria) {?>
										<option value='<?=$categoria->id?>'><?=$categoria->name?></option>
									<?php }?>
								</select>
							</div>
						</div>
						<div class="col-md-12 mt-20 pd-0">
							<div class="col-md-3">
								<label for="creado-por">Creado por</label>
								<div>
								<select id="creado-por" name="creado-por" class="select-chosen" data-placeholder="Selecciona el creador del post..." style="width: 250px;">
								<?php foreach($users as $user){ ?>
									<option value='<?= $user->id ?>'><?= $user->nombre ?></option>
									<?php } ?>
								</select>
								<small>*No se muestran los usuarios desactivados</small>
								</div>
							</div>
							<div class="col-md-7">
								<div class="col-md-4">
									<label for="tags">Etiqueta principal</label>
									<div class="col-md-12 pd-0">
										<div  id="select_tag">
											<select id="id_blog_tag_principal" name="id_blog_tag_principal" class="select-chosen" data-placeholder="Selecciona la etiqueta principal...">
												<?php foreach($tags as $tag){ ?>
												<option value='<?= $tag->id ?>'><?= $tag->name ?></option>
												<?php } ?>
											</select>
										</div>
									</div>		
								</div>
								<div class="col-md-8">
									<label for="tags">Etiquetas</label>
									<div class="col-md-12 pd-0">
										<div  id="select_tag" class="col-md-9 pl-0">
											<select id="tags" name="tags[]" class="select-chosen" data-placeholder="Selecciona las etiquetas..." multiple>
												<?php foreach($tags as $tag){ ?>
												<option value='<?= $tag->id ?>'><?= $tag->name ?></option>
												<?php } ?>
											</select>
										</div>
										<div class="col-md-3 pr-0">
											<a href="javascript:void(0)" id="addTag" class="btn btn-alt btn-sm pull-right btn-success" data-toggle="tooltip" title="Añadir nueva"><i class="fa fa-plus"></i> Crear nueva</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="publicacion">Fecha de publicación</label>
									<?php $public_date =  date('Y-m-d H:i:s') ?>
									<input id="publicacion" class="form-control bg-white datepicker" data-date-format="m/d/Y G:iK" data-enable-time="true" value="<?=date("d/m/Y H:i:s", strtotime($public_date))?>">
								</div>
							</div>
						</div>
					</div>
					<div class="mt-20 row mb-20">
						<div class="col-md-8">
							<div class="form-group">
								<label class="col-md-12" for="post-introduccion">Introducción</label>
								<div class="col-md-12">
									<textarea id="ckeditor-introduccion" name="ckeditor-introduccion" class="ckeditor"><ul><li></li></ul></textarea>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<label class="col-md-12 pl-0">Arrastrar imagen principal</label>
							<form id="my-awesome-dropzone-new" class="dropzone mt-20" method="post">
								<input type="hidden" name="post_img_id" id="post_img_id" value="">
							</form>
							<img id="image-preview" src="" alt="" style="width: 65%;margin-top: 15px;display:none;">
						</div>
					</div>
					<div class="mt-20 row mb-20">
						<div class="form-group">
							<label class="col-md-12" for="post-description">Descripción (Guarda el post para acceder al editor avanzado)</label>
							<div class="col-md-12">
								<textarea id="ckeditor" name="descripcion" class="ckeditor"></textarea>
							</div>
						</div>
					</div>
				</div>

			</div>
			<div class="col-lg-3">
				<!-- Meta Data Block -->
				<div class="block">
					<!-- Meta Data Title -->
					<div class="block-title">
						<h2><i class="fab fa-google"></i>
							<strong>SEO</strong>
						</h2>
					</div>
					<div class="form-horizontal form-bordered">
					<div class="form-group">
							<label class="col-md-3 control-label">Mostrar en index</label>
							<div class="col-md-9">
								<label class="switch switch-success">
								<input type="checkbox" id="post-index" name="post-index">
								<span></span>
								</label>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-url">URL</label>
							<div class="col-md-9">
								<?php $ext = get_setting('url_extension'); ?>
								<input type="hidden" id="ext" value="<?=$ext?>">
								<input type="text" id="post-url" name="post-url" class="form-control" placeholder="Introduce una url..." value="">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-meta-title">Meta Title</label>
							<div class="col-md-9">
								<input type="text" id="post-meta-title" name="post-meta-title" class="form-control" placeholder="Introduce el meta title..." value="">
								<div class="help-block">55 Carácteres Max</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-meta-keywords">Meta Keywords</label>
							<div class="col-md-9">
								<input type="text" id="post-meta-keywords" name="post-meta-keywords" class="form-control" placeholder="keyword1, keyword2, keyword3" value="">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="post-meta-description">Meta Description</label>
							<div class="col-md-9">
								<textarea id="post-meta-description" name="post-meta-description" class="form-control" rows="6" placeholder="Introduce meta description..."></textarea>
								<div class="help-block">115 Carácteres Max</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    <?php }?>
	<input type="hidden" name="blog_url" id="blog_url" value="<?=$url_blog->value?>">
    <!-- END post Edit Content -->
</div>
<!-- END Page Content -->
<?php include 'sections/page_footer.php';?>
<?php include 'sections/template_scripts.php';?>
<script src="assets/js/helpers/ckeditor/ckeditor.js"></script>
<script>
var URL = '<?=URL?>';
var add_tag = '<form id="add_tag" method="post" class="form-horizontal form-bordered"><div class="form-group"><div class="col-md-12 pd-0"><label class="col-md-3 control-label" for="tag_name">Nombre</label> <div class="col-md-9"><input type="text" id="tag_name" name="tag_name" class="form-control" placeholder="Introduce el nombre de la etiqueta" value=""><a href="javascript:void(0)" onclick="create_tag()" data-toggle="tooltip" title="Añadir nueva" class="btn btn-alt btn-sm btn-success pull-right mt-20"><i class="fa fa-plus"></i> Crear</a></div></div></div></form>';
</script>
<?php include 'sections/template_end.php';?>
<script src="assets/js/pages/ecomOrders.js"></script>

<link rel="stylesheet" type="text/css" href="https://npmcdn.com/flatpickr/dist/themes/material_blue.css">
<script src="https://npmcdn.com/flatpickr/dist/flatpickr.min.js"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/es.js"></script>