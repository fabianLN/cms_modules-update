<?php include 'sections/template_start.php'; ?>
<?php include 'sections/page_head.php'; ?>
<?php $_SESSION['prevpag'] = sprintf("%s://%s%s",isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'],$_SERVER['REQUEST_URI']) ?>
<!-- Page content -->
<div id="page-content">
    <!-- Quick Stats -->
    <div class="row text-center">
        
        <div class="col-sm-6 col-lg-3">
            <a href="javascript:void(0)" class="widget widget-hover-effect2">
                <div class="widget-extra themed-background-dark">
                    <h4 class="widget-content-light"><strong>Todas</strong> las categorías</h4>
                </div>
                <div class="widget-extra-full"><span class="h2 themed-color-dark animation-expandOpen"><?= count(ORM::for_table('blog_categories')->find_many()) ?></span></div>
            </a>
        </div>
		<div class="col-sm-6 col-lg-3 pull-right">
            <a href="?cf=blog_categories/create-category" class="widget widget-hover-effect2">
                <div class="widget-extra themed-background-success">
                    <h4 class="widget-content-light"><strong>Añadir</strong> nueva categoría</h4>
                </div>
                <div class="widget-extra-full"><span class="h2 text-success animation-expandOpen"><i class="fa fa-plus"></i></span></div>
            </a>
        </div>
    </div>
    <!-- END Quick Stats -->

    <!-- All Products Block -->
    <div class="block full">
        <!-- All Products Title -->
        <div class="block-title">
            <h2><strong>Todas</strong> las Categorías</h2>
        </div>
        <!-- END All Products Title -->

        <!-- All Products Content -->
		<?php if(count($results)>0){ ?>
			<table id="ecom-blog_post" class="table table-bordered table-striped table-vcenter">
				<thead>
					<tr>
						<th class="text-center" style="width: 70px;">ID</th>
						<th>Nombre</th>
						<th class="text-center" style="width: 10%;">Nº posts</th>
						<th class="text-center" style="width: 10%;">Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($results as $category) { ?>
					<tr>
						<td class="text-center">
							<a href="?cf=blog_categories/view-category/<?= $category->id ?>">
								<strong>
									<?= $category->id ?>
								</strong>
							</a>
						</td>
						<td>
							<a href="?cf=blog_categories/view-category/<?= $category->id ?>">
								<?= $category->name ?>
							</a>
						</td>
						<td class="text-center">
							<?php $posts = ORM::for_table('blog_posts')->where('id_blog_categories',$category->id)->find_many(); ?>
							<strong>
								<?= count($posts) ?>
							</strong>
						</td>
						<td class="text-center">
							<div class="btn-group btn-group-sm">
								<a href="?cf=blog_categories/view-category/<?= $category->id ?>" data-toggle="tooltip" title="Editar" class="btn btn-default"><i class="fa fa-pencil"></i></a>
								<a href="#" data-toggle="tooltip" title="Borrar" url_action="<?= URL_POST ?>blog_categories/delete-category/<?= $category->id ?>" class="btn btn-xs btn-danger deleteField"><i class="fa fa-times"></i></a>
							</div>
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		<?php }else{ echo '<p class="no_exite">No existen categorías todavía, <a href="?cf=blog_categories/create-category">Crea la primera</a></p>';} ?>
        <!-- END All Products Content -->
    </div>
    <!-- END All Products Block -->
<form action="inc/funciones.php" method="post" class="form-horizontal form-bordered" id="delete-product">
	<input type="hidden" id="delete-product-input" name="delete-product" value="">
</form>

</div>

<!-- END Page Content -->
<?php include 'sections/page_footer.php'; ?>
<?php include 'sections/template_scripts.php'; ?>

<?php include 'sections/template_end.php'; ?>

<!-- Load and execute javascript code used only in this page -->
<script src="assets/js/pages/ecomOrders.js"></script>
<script>$(function(){ EcomOrders.init(); });</script>
<script>
$(document).ready(function() {
    $('#ecom-blog_post').DataTable();
} );
</script>