<?php include 'sections/template_start.php'; ?>
<?php include 'sections/page_head.php'; ?>
<?php $_SESSION['prevpag'] = sprintf("%s://%s%s",isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'],$_SERVER['REQUEST_URI']) ?>
<!-- Page content -->
<div id="page-content">
    <!-- Quick Stats -->
    <div class="row text-center">
        
        <div class="col-sm-6 col-lg-3">
            <a href="javascript:void(0)" class="widget widget-hover-effect2">
                <div class="widget-extra themed-background-dark">
                    <h4 class="widget-content-light"><strong>Todos</strong> los posts</h4>
                </div>
                <div class="widget-extra-full"><span class="h2 themed-color-dark animation-expandOpen"><?= count($results) ?></span></div>
            </a>
        </div>
		<div class="col-sm-6 col-lg-3 pull-right">
            <a href="?cf=blog_post/create-post" class="widget widget-hover-effect2">
                <div class="widget-extra themed-background-success">
                    <h4 class="widget-content-light"><strong>Añadir</strong> nuevo post</h4>
                </div>
                <div class="widget-extra-full"><span class="h2 text-success animation-expandOpen"><i class="fa fa-plus"></i></span></div>
            </a>
        </div>
    </div>
    <!-- END Quick Stats -->

    <!-- All Products Block -->
    <div class="block full">
        <!-- All Products Title -->
        <div class="block-title">
            <h2><strong>Todos</strong> los Post</h2>
        </div>
        <!-- END All Products Title -->

        <!-- All Products Content -->
		<?php 
		if(!empty($results)){
		?>
		<?php if(count($results)>0){ ?>
		<?php
		$labels['0']['class']   = "label-info";
		$labels['0']['text']    = "Borrador";
		$labels['1']['class']   = "label-success";
		$labels['1']['text']    = "Publicado";
		?>
			<table id="ecom-blog_post" class="table table-bordered table-striped table-vcenter">
				<thead>
					<tr>
						<th class="text-center" style="width: 70px;">ID</th>
						<th>Título</th>
						<th class="text-center">Estado</th>
						<th class="text-center">Fecha</th>
						<th class="text-center">Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($results as $post) { ?>
					<tr>
						<td class="text-center">
							<a href="?cf=blog_post/view-post/<?= $post->id ?>">
								<strong>
									<?= $post->id ?>
								</strong>
							</a>
						</td>
						<td>
							<a href="?cf=blog_post/view-post/<?= $post->id ?>">
								<?= $post->name ?>
							</a>
						</td>
						<td class="text-center"><span class="etiqueta_estado label<?php echo ($labels[$post->active]['class']) ? " " . $labels[$post->active]['class'] : ""; ?>"><?php echo $labels[$post->active]['text']; ?></span></td>
						<td class="text-center">
							<?php $date = new DateTime($post->fecha); ?>
							<?= $date->format('d/m/Y'); ?>
						</td>
						<td class="text-center">
							<div class="btn-group btn-group-sm">
								<a href="?cf=blog_post/view-post/<?= $post->id ?>" data-toggle="tooltip" title="Editar" class="btn btn-default"><i class="fa fa-pencil"></i></a>
								<a href="#" data-toggle="tooltip" title="Borrar" url_action="<?= URL_POST ?>blog_post/delete-post/<?= $post->id ?>" class="btn btn-xs btn-danger deleteField"><i class="fa fa-times"></i></a>
							</div>
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		<?php }else{ echo '<p class="no_exite">No existen posts todavía, <a href="?cf=blog_post/create-post">Crea el primero</a></p>';} ?>
		<?php
		}else{ ?>
		<div class="text-center"><span>No hay categorías</span>   <a href="?cf=blog_categories/create-category" data-toggle="tooltip" title="Añadir la primera" class="btn btn-default"><i class="fa fa-pencil"></i></a></div>
		<?php } ?>
        <!-- END All Products Content -->
    </div>
    <!-- END All Products Block -->

</div>

<!-- END Page Content -->
<?php include 'sections/page_footer.php'; ?>
<?php include 'sections/template_scripts.php'; ?>

<?php include 'sections/template_end.php'; ?>

<!-- Load and execute javascript code used only in this page -->
<script src="assets/js/pages/ecomOrders.js"></script>

<?php $module_type = 'blog_posts'?>
<?php include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/ModuleConfig/autoload.php'; ?>