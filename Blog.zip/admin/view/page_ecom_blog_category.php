<?php include 'sections/template_start.php';?>
<?php include 'sections/page_head.php';?>
<!-- Page content -->
<div id="page-content">
    <!-- category Edit Content -->
    <?php if (isset($routes[2])) {?>
        <div class="row">
			<div class="col-lg-9">
				<div class="block">
					<div class="block-title">
						<h2><i class="fa fa-pencil"></i>
							<strong>Datos</strong>
							generales (Nº posts: <?= count($posts) ?>)</h2>
						<a href="javascript:void(0)" id="backLink" data-toggle="tooltip" title="Atrás" class="pull-right btn btn-warning"><i class="gi gi-delete"></i> Atrás</a>
						<button class="btn btn btn-success pull-right mr-10 guardarcategoryV"><i class="fa fa-floppy-o"></i> Guardar</button>
						<a href="#modalDeletecategory" class="btn btn btn-danger pull-right mr-10 deleteField" url_action="<?=URL_POST?>blog_categories/delete-category/<?=$category->id?>"><i class="fas fa-trash-alt"></i> Borrar</a>
					</div>
					<div class="row">
						<input type="hidden" value="<?=$category->id?>" id="category_id" name="category_id">
						<div class="col-md-2">
							<label for="category-id">Id</label>
							<div>
								<input type="text" id="category-id" name="category-id" class="form-control" value="<?=$category->id?>" disabled>
							</div>
						</div>
						<div class="col-md-2">
							<label for="category-name">Icono</label>
							<div>
								<input type="text" id="category-icon" name="category-icon" class="form-control iconcategory" value="<?=$category->icon?>" placeholder="fab fa-500px">
							</div>
						</div>
						<div class="col-md-8">
							<label for="category-name">Nombre</label>
							<div>
								<input type="text" id="category-name" name="category-name" class="form-control" value="<?=$category->name?>">
							</div>
						</div>
					</div>
					<div class="mt-20 row mb-20">
						<div class="form-group">
							<label class="col-md-12" for="category-description">Descripción</label>
							<div class="col-md-12">
								<textarea id="ckeditor" name="descripcion" class="ckeditor"><?=$category->description?></textarea>
							</div>
						</div>
					</div>
				</div>

			</div>
			<div class="col-lg-3">
				<!-- Meta Data Block -->
				<div class="block">
					<!-- Meta Data Title -->
					<div class="block-title">
						<h2><i class="fab fa-google"></i>
							<strong>SEO</strong>
						</h2>
					</div>
					<div class="form-horizontal form-bordered">
						<div class="form-group">
							<label class="col-md-3 control-label">Mostrar en index</label>
							<div class="col-md-3">
								<label class="switch switch-success">
								<input type="checkbox" id="category-index" name="category-index" <?php if ($category->slider == 1) {echo 'checked';}?>>
								<span></span>
								</label>
							</div>
							<label class="col-md-3 control-label">Posición</label>
							<div class="col-md-3">
								<input type="number" class="form-control iconcategory" id="index_position" value="<?=$category->index_position?>">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-url">URL</label>
							<div class="col-md-9">
								<input type="text" id="category-url" name="category-url" class="form-control" placeholder="Introduce una url..." value="<?=$urlCategory->url?>">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-meta-title">Meta Title</label>
							<div class="col-md-9">
								<input type="text" id="category-meta-title" name="category-meta-title" class="form-control" placeholder="Introduce el meta title..." value="<?=$category->meta_title?>">
								<div class="help-block">55 Carácteres Max</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-meta-keywords">Meta Keywords</label>
							<div class="col-md-9">
								<input type="text" id="category-meta-keywords" name="category-meta-keywords" class="form-control" placeholder="keyword1, keyword2, keyword3" value="<?=$category->meta_key?>">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-meta-description">Meta Description</label>
							<div class="col-md-9">
								<textarea id="category-meta-description" name="category-meta-description" class="form-control" rows="6" placeholder="Introduce meta description..."><?=$category->meta_description?></textarea>
								<div class="help-block">115 Carácteres Max</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="block pb-5">
					<div class="block-title">
						<h2><i class="fa fa-paste"></i>
							<strong>Entradas</strong>
							en la categoría </h2>
					</div>
					<div class="row">
						<?php if(count($posts)>0){ 
							$labels['0']['class']   = "label-info";
							$labels['0']['text']    = "Borrador";
							$labels['1']['class']   = "label-success";
							$labels['1']['text']    = "Publicado";
							?>
						<table id="ecom-blog_post" class="table table-bordered table-striped table-vcenter">
							<thead>
								<tr>
									<th class="text-center" style="width: 70px;">ID</th>
									<th>Título</th>
									<th class="text-center">Estado</th>
									<th class="text-center">Fecha</th>
									<th class="text-center">Acciones</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach($posts as $post) { ?>
								<tr>
									<td class="text-center">
										<a href="?cf=blog/view-post/<?= $post->id ?>">
											<strong>
												<?= $post->id ?>
											</strong>
										</a>
									</td>
									<td>
										<a href="?cf=blog/view-post/<?= $post->id ?>">
											<?= $post->name ?>
										</a>
									</td>
									<td class="text-center"><span class="etiqueta_estado label<?php echo ($labels[$post->active]['class']) ? " " . $labels[$post->active]['class'] : ""; ?>"><?php echo $labels[$post->active]['text']; ?></span></td>
									<td class="text-center">
										<?php $date = new DateTime($post->fecha); ?>
										<?= $date->format('d/m/Y'); ?>
									</td>
									<td class="text-center">
										<div class="btn-group btn-group-sm">
											<a href="?cf=blog/view-post/<?= $post->id ?>" data-toggle="tooltip" title="Editar" class="btn btn-default"><i class="fa fa-pencil"></i></a>
											<a href="#" data-toggle="tooltip" title="Borrar" url_action="<?= URL_POST ?>blog_post/delete-post/<?= $post->id ?>" class="btn btn-xs btn-danger deleteField"><i class="fa fa-times"></i></a>
										</div>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					<?php }else{ echo '<p class="no_exite">No existen posts todavía, <a href="?cf=blog_post/create-post">Crea el primero</a></p>';} ?>
				</div>
			</div>
		</div>
    <?php } else {?>
		<div class="row">
			<div class="col-lg-9">
				<div class="block">
					<div class="block-title">
						<h2><i class="fa fa-pencil"></i>
							<strong>Datos</strong>
							generales</h2>
						<a href="<?=$_SESSION['prevpag']?>" data-toggle="tooltip" title="Atrás" class="pull-right btn btn-warning"><i class="gi gi-delete"></i> Atrás</a>
						<button class="btn btn btn-success pull-right mr-10 crearcategory"><i class="fa fa-floppy-o"></i> Guardar</button>
					</div>
					<div class="row">
						<div class="col-md-4">
							<label for="category-name">Icono</label>
							<div>
								<input type="text" id="category-icon" name="category-icon" class="form-control iconcategory" value="" placeholder="fab fa-500px">
							</div>
						</div>
						<div class="col-md-7">
							<label for="category-name">Nombre</label>
							<div>
								<input type="text" id="category-name" name="category-name" class="form-control namecategory" value="">
							</div>
						</div>
					</div>
					<div class="mt-20 row mb-20">
						<div class="form-group">
							<label class="col-md-12" for="category-description">Descripción</label>
							<div class="col-md-12">
								<textarea id="ckeditor" name="descripcion" class="ckeditor"></textarea>
							</div>
						</div>
					</div>
				</div>

			</div>
			<div class="col-lg-3">
				<!-- Img picker -->
				<div class="block">
				<!-- Meta Data Block -->
				<div class="block">
					<!-- Meta Data Title -->
					<div class="block-title">
						<h2><i class="fab fa-google"></i>
							<strong>SEO</strong>
						</h2>
					</div>
					<div class="form-horizontal form-bordered">
						<div class="form-group">
							<label class="col-md-3 control-label">Mostrar en index</label>
							<div class="col-md-3">
								<label class="switch switch-success">
								<input type="checkbox" id="category-index" name="category-index" <?php if ($category->slider == 1) {echo 'checked';}?>>
								<span></span>
								</label>
							</div>
							<label class="col-md-3 control-label">Posición</label>
							<div class="col-md-3">
								<input type="number" class="form-control iconcategory" id="index_position" value="">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-url">URL</label>
							<div class="col-md-9">
								<input type="text" id="category-url" name="category-url" class="form-control" placeholder="Introduce una url..." value="">
								<span>(Al crear, concatena las categorías)</span>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-meta-title">Meta Title</label>
							<div class="col-md-9">
								<input type="text" id="category-meta-title" name="category-meta-title" class="form-control" placeholder="Introduce el meta title..." value="">
								<div class="help-block">55 Carácteres Max</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-meta-keywords">Meta Keywords</label>
							<div class="col-md-9">
								<input type="text" id="category-meta-keywords" name="category-meta-keywords" class="form-control" placeholder="keyword1, keyword2, keyword3" value="">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label" for="category-meta-description">Meta Description</label>
							<div class="col-md-9">
								<textarea id="category-meta-description" name="category-meta-description" class="form-control" rows="6" placeholder="Introduce meta description..."></textarea>
								<div class="help-block">115 Carácteres Max</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    <?php }?>
    <!-- END category Edit Content -->
</div>
</div>
<!-- END Page Content -->
<?php include 'sections/page_footer.php';?>
<?php include 'sections/template_scripts.php';?>
<script src="assets/js/helpers/ckeditor/ckeditor.js"></script>
<script> var URL = '<?=URL?>';</script>
<?php include 'sections/template_end.php';?>

<!-- Load and execute javascript code used only in this page -->
<script src="assets/js/pages/ecomOrders.js"></script>
<script>$(function(){ EcomOrders.init(); });</script>
<script>
$(document).ready(function() {
    $('#ecom-blog_post').DataTable();
} );
</script>