<?php include 'sections/template_start.php';?>
<?php include 'sections/page_head.php';?>
<!-- Page content -->
<div id="page-content">
    <!-- tag Edit Content -->
    <?php if (isset($routes[2])) {?>
        <div class="row">
		<div class="col-lg-12">
			<div class="block">
				<div class="block-title">
					<h2><i class="fa fa-pencil"></i>
						<strong>Datos</strong>
						generales (Nº posts: <?= count($posts) ?>)</h2>
					<a href="javascript:void(0)" id="backLink" data-toggle="tooltip" title="Atrás" class="pull-right btn btn-warning"><i class="gi gi-delete"></i> Atrás</a>
					<button class="btn btn btn-success pull-right mr-10 guardartagV"><i class="fa fa-floppy-o"></i> Guardar</button>
					<a href="#modalDeletetag" class="btn btn btn-danger pull-right mr-10 deleteField" url_action="<?=URL_POST?>blog_tags/delete-tag/<?=$tag->id?>"><i class="fas fa-trash-alt"></i> Borrar</a>
				</div>
				<div class="row">
					<input type="hidden" value="<?=$tag->id?>" id="tag_id" name="tag_id">
					<div class="col-md-2">
						<label for="tag-id">Id</label>
						<div>
							<input type="text" id="tag-id" name="tag-id" class="form-control" value="<?=$tag->id?>" disabled>
						</div>
					</div>
					<div class="col-md-10 mb-20">
						<label for="tag-name">Nombre</label>
						<div>
							<input type="text" id="tag-name" name="tag-name" class="form-control" value="<?=$tag->name?>">
						</div>
					</div>
				</div>
			</div>

		</div>
    <?php } else {?>
		<div class="row">
		<div class="col-lg-12">
			<div class="block">
				<div class="block-title">
					<h2><i class="fa fa-pencil"></i>
						<strong>Datos</strong>
						generales</h2>
					<a href="<?=$_SESSION['prevpag']?>" data-toggle="tooltip" title="Atrás" class="pull-right btn btn-warning"><i class="gi gi-delete"></i> Atrás</a>
					<button class="btn btn btn-success pull-right mr-10 creartag"><i class="fa fa-floppy-o"></i> Guardar</button>
				</div>
				<div class="row">
					<div class="col-md-12 mb-20">
						<label for="tag-name">Nombre</label>
						<div>
							<input type="text" id="tag-name" name="tag-name" class="form-control nametag" value="">
						</div>
					</div>
				</div>
			</div>

		</div>
		</div>
    <?php }?>
    <!-- END tag Edit Content -->
</div>
</div>
<!-- END Page Content -->
<?php include 'sections/page_footer.php';?>
<?php include 'sections/template_scripts.php';?> 
<script> var URL = '<?=URL?>';</script>
<?php include 'sections/template_end.php';?>