<?php if($usuario->rol <= 3){ ?>
    <div class="col-sm-6 col-lg-3">
        <!-- Widget -->
        <a href="<?= URL_POST ?>blog_post/create-post" class="widget widget-hover-effect1">
            <div class="widget-simple">
                <div class="widget-icon pull-left themed-background-spring animation-fadeIn">
                    <i class="gi gi-book_open"></i>
                </div>
                <h3 class="widget-content text-right animation-pullDown">
                    <strong>Crear Post</strong><br>
                    <?php /* ?><small>LO QUE QUIERAS</small><?php */ ?>
                </h3>
            </div>
        </a>
        <!-- END Widget -->
    </div>
<?php } ?>