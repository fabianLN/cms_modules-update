// this function runs every time you are scrolling

$(window).scroll(function() {
    const element = $("#end_posts")
    if(element.length > 0){
        const top_of_element = element.offset().top;
        const bottom_of_element = element.offset().top + element.outerHeight();
        const bottom_of_screen = $(window).scrollTop() + $(window).innerHeight();
        const top_of_screen = $(window).scrollTop();

        if ((bottom_of_screen > top_of_element) && (top_of_screen < bottom_of_element)){
            // the element is visible, do something
            const page = parseInt(element.data('page')) + 1
            element.remove()
            $.ajax({
                method: "POST",
                url: '/'+url_js+'?p='+page,
                async: false
            }).done(function (data) {
                const posts = $(data).find('#posts').html()
                $('#posts').append(posts)
            });
        } else {
            // the element is not visible, do something else
        }
    }
});