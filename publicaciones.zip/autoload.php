<?php 
    class bbdd_update {

        function __construct(){

        }

        // Crear las tablas necesarias en la base de datos si no existen
        function update_database() {
            $db = ORM::get_db();

            /* funciones para publicaciones */
            $test_publicaciones = ORM::forTable('')->raw_query('SHOW TABLES LIKE "Publicaciones"')->findMany()->count();
            if(!$test_publicaciones){
                $db->exec("
                    CREATE TABLE Publicaciones (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        portada varchar(255) NOT NULL,
                        libro varchar(255) NOT NULL,
                        tipo int(11) NOT NULL DEFAULT '0' COMMENT '0: libro / 1: folleto',
                        file_route varchar(255) NOT NULL
                    )
                ");
                
                $db->exec("
                    INSERT INTO url_custom (url, id_rel, type, fixed, in_menu) VALUES
                    ('publicaciones".get_extension()."',0,'Publicaciones',1,1);
                ");

                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Publicaciones', 'publicaciones', '', 3, 2, 4);
                ");
            }

            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "Publicaciones"')->findMany()->count();
            if(!$test_module_config){
                $db->exec("
                    INSERT INTO admin_modules_config (type, content) VALUES
                    ('Publicaciones', '".json_encode(array('h1'=>'Nuestras publicaciones','content'=>'Te dejamos una selección de nuestras publicaciones','meta_title'=>'Nuestras publicaciones','meta_description'=>'Las mejores publicaciones que hemos hecho hasta la fecha','meta_key'=>''))."');
                ");
            }
        }

        function delete_database(){
            $db = ORM::get_db();

            //borra los pdf y las imagenes que se hayan subido
            $publicaciones = ORM::forTable('Publicaciones')->find_many();
            foreach($publicaciones as $publicacion){
                //borrar portada
                unlink($_SERVER['DOCUMENT_ROOT'].$publicacion->portada);

                //borrar pdf
                unlink($_SERVER['DOCUMENT_ROOT'].$publicacion->file_route);
            }

            /* funciones para publicaciones */
            $test_publicaciones = ORM::forTable('')->raw_query('SHOW TABLES LIKE "Publicaciones"')->findMany()->count();
            if($test_publicaciones){
                $db->exec("
                    DROP TABLE Publicaciones
                ");
                $db->exec("
                    DELETE FROM admin_menu WHERE url = 'publicaciones'
                ");
                $db->exec("
                    DELETE FROM url_custom WHERE url = 'publicaciones".get_extension()."'
                ");
            }

        }
    }
?>