<?php
    $data = getUrlModuleData(URL);
    $libros = getPublicaciones(0);
    $folletos = getPublicaciones(1);

    $meta_title = $data['meta_title'];
    $meta_desc = $data['meta_description'];
    $meta_key = $data['meta_key'];

    include('./templates/publicaciones.php');