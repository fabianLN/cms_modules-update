<?php 

function getPublicaciones($id){
    $query = ORM::for_table('Publicaciones')->where('tipo',$id)->find_array();

    return $query;
}

?>