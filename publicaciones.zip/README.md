# cms_module-libros
Módulo que agrega la posibilidad de visualizar como libros los archivos pdf
