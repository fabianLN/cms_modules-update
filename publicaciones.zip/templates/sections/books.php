<?php $cont = 0 ?>
<?php foreach($publicaciones as $key => $book){ ?>
    <?php if($cont == 0){ ?>
    <div class="col-md-12 col-lg-10 mb-1">
        <div class="bookshelf_container">
            <div class='col-md-12 pd-0 text-center list-inline bookshelf'>
                <?php } ?>
                    <div class='col-md-2 col-xs-6 mt-2'>
                        <div class="book" data-pdf="<?=$book['file_route']?>">
                            <img src='<?=$book['portada']?>' />
                        </div>
                    </div>
            <?php if($cont == 6 || count($publicaciones) - 1 == $key){ ?>
            </div>
        </div>
    </div>
    <?php } ?>
    <?php if($cont <= 6){ $cont++; }else{ $cont = 0;} ?>
<?php } ?>