<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?=$meta_desc?>">
        <meta name="author" content="Fabian">
        <title><?=$meta_title?></title>

        <?php include_once('sections/links-head.php') ?>
        <link rel="stylesheet" href="public/css/book.css">

        <meta name="robots" content="<?=$data['meta_robots']?>">
    </head>
    <body class="fixed_head" data-spy="scroll" data-target=".navbar" data-offset="40" id="custom-page">
        
        <?php include_once('sections/menu.php') ?>

        <section class="container">
            <h1><?=$data['h1']?></h1>
            <p><?=$data['content']?></p>
        </section>

        <!--======= Libros =========-->
        <section class="container sec-100px">
            <div class="mb-5">
                <!-- libros -->
                <?php if(count($libros) > 0){ ?>
                    <div class="col-md-7">
                        <h2>Nuestros libros</h2>
                    </div>
                    <?php $publicaciones = $libros ?>
                    <?php include('sections/books.php') ?>
                <?php } ?>

                <!-- folletos -->
                <?php if(count($folletos) > 0){ ?>
                    <div class="col-md-7 mt-4">
                        <h2>Nuestros folletos</h2>
                    </div>
                    <?php $publicaciones = $folletos ?>
                    <?php include('sections/books.php') ?>
                <?php } ?>
            </div>


            <div class="col-md-12 mt-3 mb-5 iframe_container" style="display: none">
                <iframe id="book_iframe" src="" onload='javascript:(function(o){o.style.height="900px";console.log(o.contentWindow.document.body.scrollHeight)}(this));' style="height:200px;width:100%;border:none;overflow:hidden;"></iframe>
            </div>
        </section>


        <?php include_once('sections/footer.php') ?>

        <?php include_once('sections/links-footer.php') ?>
        <script src="public/js/book.js"></script>

    </body>
</html>
