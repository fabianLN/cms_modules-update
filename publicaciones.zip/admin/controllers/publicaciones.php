
<?php
_auth();

switch ( $action ) {
    case 'add-update-publicacion':
        $portada = filter_filename($_FILES['files']['name'][0]);
        $libro = filter_filename($_FILES['files']['name'][1]);
        $tipo = $_POST['tipo'];

        $tempName_portada = $_FILES['files']['tmp_name'][0];
        $tempName_libro = $_FILES['files']['tmp_name'][1];

        if(isset($_POST['id'])){
            $p =  ORM::for_table('Publicaciones')->find_one($_POST['id']);
            $text = 'Actualizada una publicación: ';
        }else{
            $p =  ORM::for_table('Publicaciones')->create();
            $text = 'Creada una nueva publicación: ';
        }

        $p->libro = $libro;
        $p->tipo = $tipo;
        $p->portada = save_file($tempName_portada,$portada);
        $p->file_route = save_file($tempName_libro,$libro);

        if($p->save()){
            admin_log($text.$p->id);
            echo json_encode(array('code' => 1, 'class' => 'success', 'id' => $p->id, 'text' => 'Publicación guardada con éxito'));
        }else{
            echo json_encode(array('code' => 0, 'class' => 'danger', 'id' => $p->id, 'text' => 'La publicación no se ha podido guardar'));
        }
        break;
    case 'delete-publicacion':
        $p =  ORM::for_table('Publicaciones')->find_one($routes[2]);

        unlink($_SERVER['DOCUMENT_ROOT'] . '/public/pdf/'.$p->portada);
        unlink($_SERVER['DOCUMENT_ROOT'] . '/public/pdf/'.$p->libro);

        $id = $p->id;
        if($p->delete()){
            admin_log('Publicación borrada con éxito: '.$p->id);
            r2d2('?cf=publicaciones', $ntype = 's', $msg = 'Publicación borrada con éxito');
        }else{
            r2d2('?cf=publicaciones', $ntype = 'e', $msg = 'No se ha podido borrar la publicación');
        }
        break;
    default:
        $results =  ORM::for_table('Publicaciones')->find_many();

        $js_footer = array( 'publicaciones' );

		include( APP_URL . 'view/publicaciones.php' );
        break;
}

function filter_filename($name) {
    $sanitized = strtolower(preg_replace('/[^a-zA-Z0-9\-\._]/','', $name));
    return $sanitized;
}

function save_file($file,$nombre){
    move_uploaded_file($file,$_SERVER['DOCUMENT_ROOT'] . '/public/pdf/'.$nombre);

    return '/public/pdf/'.$nombre;
}

?>