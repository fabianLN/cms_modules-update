$(document).ready(function() {
	EcomOrders.init();
})

$('.editPublicacion').on('click',function(){
    const id = $(this).data('id')
    const tipo = $(this).data('tipo')
    $('#tipo').val(tipo)
    $('#savePublicacion').data('id',id)
})

$('#saveNewPublicacion').on('click',function(){
    var formData = new FormData();

    formData.append('files[]', $('#new-portada').prop('files')[0])
    formData.append('files[]', $('#new-libro').prop('files')[0])
    formData.append('tipo', $('#new-tipo').val())

    const portada = $('#new-portada').val()
    const libro = $('#new-libro').val()
    const tipo = $('#new-tipo').val()

    if(portada != '' && libro != '' && tipo != ''){
        $.ajax({
            method: "POST",
            url: '?cf=publicaciones/add-update-publicacion',
            dataType: 'text',
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false
        }).done(function (data) {
            data = JSON.parse(data)
            $("#createPublicacion .bootbox-body").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
            $(".avisoOpciones").show('slow')
            setTimeout(function() {
                    window.location.href = '?cf=publicaciones'
            }, 5000);
        });
	} else {
		$("#createPublicacion .bootbox-body").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">Hay campos obligatorios vacios</div>');
		$(".avisoOpciones").show('slow');
	}
})

$('#savePublicacion').on('click',function(){
    var formData = new FormData();

    formData.append('files[]', $('#portada').prop('files')[0])
    formData.append('files[]', $('#libro').prop('files')[0])
    formData.append('tipo', $('#tipo').val())
    formData.append('id', $(this).data('id'))

    const portada = $('#portada').val()
    const libro = $('#libro').val()
    const tipo = $('#tipo').val()

    if(portada != '' && libro != '' && tipo != ''){
        $.ajax({
            method: "POST",
            url: '?cf=publicaciones/add-update-publicacion',
            dataType: 'text',
            data: formData,
            type: 'POST',
            processData: false,
            contentType: false
        }).done(function (data) {
            data = JSON.parse(data)
            $("#update-publicacion .bootbox-body").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
            $(".avisoOpciones").show('slow')
            setTimeout(function() {
                    window.location.href = '?cf=publicaciones'
            }, 5000);
        });
	} else {
		$("#update-publicacion .bootbox-body").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">Hay campos obligatorios vacios</div>');
		$(".avisoOpciones").show('slow');
	}
})