<?php include 'sections/template_start.php'; ?>
<?php include 'sections/page_head.php'; ?>
<?php $_SESSION['prevpag'] = sprintf("%s://%s%s",isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'],$_SERVER['REQUEST_URI']) ?>
<!-- Page content -->
<div id="page-content">
    <!-- Quick Stats -->
    <div class="row text-center">
        
        <div class="col-sm-6 col-lg-3">
            <a href="javascript:void(0)" class="widget widget-hover-effect2">
                <div class="widget-extra themed-background-dark">
                    <h4 class="widget-content-light"><strong>Todas</strong> las publicaciones</h4>
                </div>
                <div class="widget-extra-full"><span class="h2 themed-color-dark animation-expandOpen"><?= count($results) ?></span></div>
            </a>
        </div>
		<div class="col-sm-6 col-lg-3 pull-right">
			<a href="#createPublicacion" class="widget widget-hover-effect2 newPublicacion" data-toggle="modal">
                <div class="widget-extra themed-background-success">
                    <h4 class="widget-content-light"><strong>Añadir</strong> nueva publicación</h4>
                </div>
                <div class="widget-extra-full"><span class="h2 text-success animation-expandOpen"><i class="fa fa-plus"></i></span></div>
            </a>
        </div>
    </div>

	<div class="bootbox modal fade bootbox-confirm in" id="createPublicacion" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close btn-close-modal" data-dismiss="modal" aria-hidden="true">×</button>
				</div>
				<div class="modal-body">
					<div class="bootbox-body">

						<div class="form-group">
							<label for="portada">Portada</label>
							<input class="form-control" type="file" id="new-portada" name="portada" value="">
						</div>
						<div class="form-group">
							<label for="libro">Publicación</label>
							<input class="form-control" type="file" id="new-libro" name="libro" value="">
						</div>
						<div class="form-goup">
							<label for="tipo">tipo</label>
							<div>
								<select class="form-control" id="new-tipo" name="tipo">
									<option value="">Selecciona un tipo de publicación</option>
									<option value="0">Libro</option>
									<option value="1">Folleto</option>
								</select>
							</div>
						</div>

					</div>
				</div>
				<div class="modal-footer"><button type="button" class="btn btn-danger bootbox-cancel">Cancelar</button>
				<button type="button" id="saveNewPublicacion" class="btn btn-success bootbox-accept">Confirmar</button></div>
			</div>
		</div>
	</div>

    <!-- END Quick Stats -->

    <!-- All Products Block -->
    <div class="block full">
        <!-- All Products Title -->
        <div class="block-title">
            <h2><strong>Todos</strong> los publicaciones</h2>
			<div class="block-options pull-right"></div>
        </div>
        <!-- END All Products Title -->

        <!-- All Products Content -->
		<?php 
		if(count($results) > 0){
		?>
        <table id="ecom-publicaciones" class="table table-bordered table-striped table-vcenter">
			<thead>
				<tr>
					<th class="text-center" style="width: 70px;">ID</th>
					<th>Portada</th>
					<th class="text-center">Ruta del libro</th>
					<th class="text-center">tipo</th>
					<th class="text-center">Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php if(count($results)>0){ ?>
				<?php foreach($results as $publicacion) { ?>
				<tr>
					<td class="text-center">
						<strong>
							<?= $publicacion->id ?>
						</strong>
					</td>
					<td>
						<img src="<?= $publicacion->portada ?>" width="50px" heigth="50px">
					</td>
					<td>
						<a href="?cf=publicaciones/view-publicacion/<?= $publicacion->id ?>">
							<?= $publicacion->libro ?>
						</a>
					</td>
					<td>
                        <?php $tipo = array(
                            0 => 'libro',
                            1 => 'folleto',
                        )?>
						<?= $tipo[$publicacion->tipo] ?>
					</td>
					<td class="text-center">
						<div class="btn-group btn-group-sm">
							<a href="#update-publicacion"  data-toggle="modal" class="btn btn-default editPublicacion" data-id="<?=$publicacion->id?>" data-tipo="<?=$publicacion->tipo?>"><i class="fa fa-pencil"></i></a>
							<a href="#" data-toggle="tooltip" title="Borrar" url_action="<?= URL_POST ?>publicaciones/delete-publicacion/<?= $publicacion->id ?>" class="btn btn-xs btn-danger deleteField"><i class="fa fa-times"></i></a>
						</div>
					</td>
				</tr>
				<?php } ?>
				<?php }else{ echo '<p class="no_exite">No existen publicaciones todavía, <a href="#createPublicacion" class="newPublicacion" data-toggle="modal">Crea el primero</a></p>';} ?>
			</tbody>
		</table>

		<div class="bootbox modal fade bootbox-confirm in" id="update-publicacion" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close btn-close-modal" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body">
						<div class="bootbox-body">

							<div class="form-group">
								<label for="portada">Portada</label>
								<input class="form-control" type="file" id="portada" name="portada" value="">
							</div>
							<div class="form-group">
								<label for="libro">Publicación</label>
								<input class="form-control" type="file" id="libro" name="libro" value="">
							</div>
							<div class="form-goup">
								<label for="tipo">tipo</label>
								<div>
									<select class="form-control" id="tipo" name="tipo">
										<option value="">Selecciona un tipo de publicación</option>
										<option value="0">Libro</option>
										<option value="1">Folleto</option>
									</select>
								</div>
							</div>

						</div>
					</div>
					<div class="modal-footer"><button type="button" class="btn btn-danger bootbox-cancel">Cancelar</button>
					<button type="button" id="savePublicacion" class="btn btn-success bootbox-accept" data-id="">Confirmar</button></div>
				</div>
			</div>
		</div>

		<?php
		}else{ ?>
		<div class="text-center"><p class="no_exite">No existen publicaciones todavía, <a href="#createPublicacion" class="newPublicacion" data-toggle="modal">Crea el primero</a></p></div>
		<?php } ?>
        <!-- END All Products Content -->
    </div>
    <!-- END All Products Block -->

</div>

<!-- END Page Content -->
<?php include 'sections/page_footer.php'; ?>
<?php include 'sections/template_scripts.php'; ?>

<?php include 'sections/template_end.php'; ?>

<?php $module_type = 'Publicaciones'?>
<?php include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/ModuleConfig/autoload.php'; ?>

<script src="/<?= URL ?>assets/js/pages/ecomOrders.js"></script>