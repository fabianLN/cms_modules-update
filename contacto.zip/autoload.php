<?php 
    class bbdd_update {

        function __construct(){

        }

        // Crear las tablas necesarias en la base de datos si no existen
        function update_database() {
            $db = ORM::get_db();

            /* funciones para admin_modules_config */
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "Contacto"')->findMany()->count();
            if(!$test_module_config){
                $db->exec("
                    INSERT INTO admin_modules_config (type, content) VALUES
                    ('Contacto', '".json_encode(array('contact_mail'=>'CORREO PARA RECIBIR LOS CONTACTOS','h1' => 'Esto es el h1','h2'=>'Este el h2','content'=>'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eligendi, in perferendis voluptatem officiis porro autem, amet, placeat repellendus ab dolores velit fugiat soluta alias est. Vitae earum dicta non. Corporis.','meta_title'=>'','meta_key'=>'','meta_desc'=>''))."');
                ");
            }

            /* funciones para url_custom */
            $test_url_custom = ORM::forTable('url_custom')->where('type','Contacto')->count();
            if($test_url_custom == 0){
                $db->exec("
                    INSERT INTO url_custom (url, id_rel, type, fixed, in_menu) VALUES
                    ('contacto".get_extension()."',0,'Contacto',1,1);
                ");
            }

            /* funciones para admin_menu */
            $test_admin_menu = ORM::forTable('admin_menu')->where('url','contacto')->find_one();
            if($test_admin_menu == 0){
                $parent = ORM::forTable('admin_menu')->where_like('name','Páginas')->find_one();
                $db->exec("
                    INSERT INTO admin_menu (name, url, rol, pos, id_parent, icon) VALUES
                    ('Contacto','contacto',1,3,".$parent->id.",'');
                ");
            }
        }

        function delete_database(){
            $db = ORM::get_db();

            /* funciones para admin_modules_config */
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "Contacto"')->findMany()->count();
            if(!$test_module_config){
                $db->exec("
                    DELETE FROM admin_modules_config where type = 'Contacto';
                ");
            }

            /* funciones para url_custom */
            $test_url_custom = ORM::forTable('url_custom')->where('type','Contacto')->count();
            if($test_url_custom == 0){
                $db->exec("
                    DELETE FROM url_custom WHERE url = 'contacto".get_extension()."'
                ");
            }

            /* funciones para admin_menu */
            $test_admin_menu = ORM::forTable('admin_menu')->where('url','contacto')->find_one();
            if($test_admin_menu != 0){
                $test_admin_menu->delete();
            }
        }
    }
?>