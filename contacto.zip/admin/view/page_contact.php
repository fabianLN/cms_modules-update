<?php include 'sections/template_start.php'; ?>
<?php include 'sections/page_head.php'; ?>
<!-- Page content -->
<div id="page-content">
    <!-- Product Edit Content -->
		<div class="col-md-12">
			<div id="message" class="alert mt-20" style="display: none;"></div>
		</div>
		<div class="row">
			<div class="col-lg-9">
				<!-- General Data Block -->
				<div class="block">
					<!-- General Data Title -->
					<div class="block-title">
						<h2><i class="fa fa-gear"></i> <strong>Configuración</strong> contacto</h2>
						<a href="javascript:void(0)" id="backLink" data-toggle="tooltip" title="Editar" class="pull-right btn btn-warning"><i class="gi gi-delete"></i> Atrás</a>
						<button id="actualizarContacto" class="btn btn btn-success pull-right mr-10"><i class="fa fa-floppy-o"></i> Guardar</button>
					</div>
					<!-- END General Data Title -->
					<!-- General Data Content -->
					<div class="form-horizontal form-bordered">
					<input type="hidden" id="page_id" name="page_id" value="<?= $page->id ?>">
						<div class="form-group">
							<div class="col-md-7">
								<label class="col-md-2 contact-title">Titulo</label>
								<div class="col-md-10">
								<input type="text" id="contact-title" name="contact-title" class="form-control" placeholder="Titulo pagina contacto..." value="<?= $data['h1'] ?>" required>
								</div>
							</div>
							<div class="col-md-5">
								<label class="col-md-3 control-label" for="contact-subtitle">Subtitulo</label>
								<div class="col-md-9">
								<input type="text" id="contact-subtitle" name="contact-subtitle" class="form-control" placeholder="Subtitulo pagina contacto..." value="<?= $data['h2'] ?>" required>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<label class="col-md-3 control-label" for="contact-email">Correo para recibir los contactos</label>
								<div class="col-md-9">
								<input type="text" id="contact-email" name="contact-email" class="form-control" placeholder="Correo de contacto..." value="<?= $data['contact_mail'] ?>" required>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<label class="control-label" for="page-name">Texto</label>
								<textarea id="ckeditor" name="descripcion" class="ckeditor"><?=$data['content']?></textarea>
							</div>
						</div>

					</div>
					<!-- END General Data Content -->
				</div>
				<!-- END General Data Block -->
			</div>
			
			<!-- SEO -->
			<div class="col-lg-3">
				<!-- General Data Block -->
				<div class="block">
					<!-- General Data Title -->
					<div class="block-title">
						<h2><i class="fab fa-google"></i> <strong>SEO</strong></h2>
					</div>
					<!-- END General Data Title -->
					<!-- General Data Content -->
					<div class="form-horizontal form-bordered">
						<div class="col-md-12 mb-20">
							<div class="form-group">
								<label class="col-md-3 control-label" for="page-url">URL</label>
								<div class="col-md-9">
									<input type="text" id="contact-url" name="contact-url" class="form-control" placeholder="Introduce una url..." value="<?=$url_contacto->url?>">
								</div>
							</div>
						</div>
						<div class="col-md-12 mb-20">
							<div class="form-group">
								<label class="col-md-3 control-label" for="page-meta-title">Meta Title</label>
								<div class="col-md-9">
									<input type="text" id="page-meta-title" name="page-meta-title" class="form-control" placeholder="Introduce el meta title..." value="<?=$data['meta_title']?>">
									<div class="help-block">55 Carácteres Max</div>
								</div>
							</div>
						</div>
						<div class="col-md-12 mb-20">
							<div class="form-group">
								<label class="col-md-3 control-label" for="page-meta-keywords">Meta Keywords</label>
								<div class="col-md-9">
									<input type="text" id="page-meta-keywords" name="page-meta-keywords" class="form-control" placeholder="keyword1, keyword2, keyword3" value="<?=$data['meta_key']?>">
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group"> 
								<label class="col-md-12" for="page-meta-description">Meta Description</label>
								<div class="col-md-12">
									<textarea id="page-meta-description" name="page-meta-description" class="form-control" rows="6" placeholder="Introduce meta description..."><?=$data['meta_desc']?></textarea>
									<div class="help-block">115 Carácteres Max</div>
								</div>
							</div>
						</div>
					</div>
					<!-- END General Data Content -->
				</div>
				<!-- END General Data Block -->
			</div>
			<!-- Fin SEO -->

		</div>
</div>
<!-- END Page Content -->
<?php include 'sections/page_footer.php'; ?>
<?php include 'sections/template_scripts.php'; ?>

<script>var url_post = '<?=URL_POST?>'; </script>
<script src="assets/js/helpers/ckeditor/ckeditor.js"></script>

<?php include 'sections/template_end.php'; ?>
