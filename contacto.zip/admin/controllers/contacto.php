<?php
_auth();

switch ( $action ) {
	case 'saveData':
		$url_contacto = ORM::forTable('url_custom')->where_like('type','Contacto')->find_one();
		$contacto = ORM::forTable('admin_modules_config')->where('type','Contacto')->find_one();

		$contacto->content = $_POST['data'];
		$url_contacto->url = (strpos($_POST['url'],get_extension()))? $_POST['url']: $_POST['url'].get_extension();

		if($contacto->save() && $url_contacto->save()){
			admin_log('Guardados los ajustes de contacto');
            echo json_encode(array('code'=>1,'text'=>'Se ha guardado correctamente'));
		}else{
			echo json_encode(array('code'=>0,'text'=>'No se ha podido guardar'));
		}
		break;
	default:
		$url_contacto = ORM::forTable('url_custom')->where_like('type','Contacto')->find_one();
		$contacto = ORM::forTable('admin_modules_config')->where('type','Contacto')->find_one();
		$data = json_decode($contacto->content,true);

        $js_footer = array('contacto');
		include(APP_URL.'view/page_contact.php');
}