$(document).ready(function() {
	$('#actualizarContacto').on('click',function(){
		const url = $('#contact-url').val()

		const data = {
			contact_mail: $('#contact-email').val(),
			h1: $('#contact-title').val(),
			h2: $('#contact-subtitle').val(),
			content: CKEDITOR.instances['ckeditor'].getData(),
			meta_title: $('#page-meta-title').val(),
			meta_key: $('#page-meta-keywords').val(),
			meta_desc: $('#page-meta-description').val()
		}

		$.ajax({
			url: url_post + 'contacto/saveData',
			method: 'POST',
			data:{
				url,
				data: JSON.stringify(data)
			},
			success: function(data){
				showMessage(data);
				interval = setInterval(hiddeMessage, 1500);
			}
		});
	})
})