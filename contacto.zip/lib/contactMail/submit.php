<?php
	$internal = true;
	include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/config/init.php' );
	include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/modules/mailing_list/mailingClass.php' );

	// specify your email here
	$email = ORM::for_table('admin_modules_config')->where('type','Contacto')->find_one();
	$config = json_decode($email->content,true);
	$to = $config['contact_mail'];
	$idList = $config['addList'];
	// Assigning data from $_POST array to variables
    if (isset($_POST['name'])) { $name = $_POST['name']; }
    if (isset($_POST['email'])) { $from = $_POST['email']; }
    if (isset($_POST['message'])) { $message = $_POST['message']; }
	
	// Construct subject of the email
	$subject = 'Nuevo contacto web: ' . $name;

	// Construct email body
	$body_message .= 'Nombre: 	' . $name . "\r\n";
	$body_message .= 'Email: 	' . $from . "\r\n";
	$body_message .= 'Teléfono: 	' . $company . "\r\n";
	$body_message .= 'Consulta: 	' . $message . "\r\n";

	// Construct headers of the message
	$headers = 'From: ' . $from . "\r\n";
	$headers .= 'Reply-To: ' . $from . "\r\n";

	$mail_sent = mail($to, $subject, $body_message, $headers);

	if (function_exists('addLead')) {
		$id_lead = addLead($from, $name);
		suscribeLead($id_lead, $idList);
	}

	if ($mail_sent == true){ 
		header("Location: ../../contacto.php?success");
	} else {
		header("Location: ../../contacto.php?error");
	} // End else
?>
