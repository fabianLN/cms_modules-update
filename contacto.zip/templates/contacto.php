<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?=$meta_desc?>">
        <meta name="author" content="Devcrud">
        <title><?=$meta_title?></title>

        <?php include_once('sections/links-head.php') ?>
        <meta name="robots" content="<?=$data['meta_robots']?>">
    </head>
    <body data-spy="scroll" data-target=".navbar" data-offset="40" id="contact-page" class="fixed_head">
        
        <?php include_once('sections/menu.php') ?>

        <section class="container sec-100px">

            <div class="row">
                <div class="col-md-12">
                    <h1><?=$data['h1']?></h1>
                </div>
                <div class="col-md-12">
                    <?php if(isset($_GET['success'])){ ?>
                        <p class="alert alert-success">El correo se ha enviado correctamente</p>
                    <?php } ?>
                    <?php if(isset($_GET['error'])){ ?>
                        <p class="alert alert-danger">No hemos podido enviar el correo, prueba de nuevo</p>
                    <?php } ?>
                </div>
                <div class="col-md-6">
                    <form action="lib/contactMail/submit.php" method="post" class="form-group"> 
                        <label>Nombre y apellido: <span class="text-danger">*</span>
                            <input type="text" name="name" placeholder="Nombre y apellido" class="form-control" required>
                        </label><br>
                        
                        <label>Email: <span class="text-danger">*</span>
                            <input type="email" name="email" placeholder="Email" class="form-control" required>
                        </label><br>
                        
                        <label>Consulta:
                            <textarea name="message" class="form-control" ></textarea>
                        </label><br>

                        <button type="submit" class="btn btn-success">Enviar</button>
                        <p><small>*Al enviar, estás aceptando las <a href="/politica-privacidad.php">Política de privacidad</a></small></p>
                    </form>
                </div>
                <div class="col-md-6">
                    <h2><?=$data['h2']?></h2>
                    <p><?=$data['content']?></p>
                </div>
            </div>

        </section>


        <?php include_once('sections/footer.php') ?>

        <?php include_once('sections/links-footer.php') ?>

    </body>
</html>