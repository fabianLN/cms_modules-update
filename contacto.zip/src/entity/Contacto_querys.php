<?php 
    function getContactoData(){
        $amc = ORM::forTable('admin_modules_config')->where('type','Contacto')->find_one();

        return json_decode($amc->content,true);
    }
?>