<?php
    $data = getContactoData();
    $meta_title = $data['meta_title'];
    $meta_desc = $data['meta_description'];
    $meta_key = $data['meta_key'];

    include('./templates/contacto.php');