<?php

    //Agrega un nuevo lead, obligatorio el email. Devuelve el id del lead o false si hay error
    function addLead($email,$name='',$telf=null,$web='',$tipo=1){
        try{
            $lead = ORM::for_table('leads')->where('email',$email)->find_one();
            if(!$lead){
                $lead = ORM::for_table('leads')->create();
                $lead->email = $email;
                $lead->nombre = $name;
                $lead->telefono = $telf;
                $lead->web = $web;
                $lead->tipo = $tipo;
                $lead->send_mails = 1;

                $lead->save();
            }

            return $lead->id;
        }catch(Exception $e){
            return false;
        }
    }

    //Suscribe al lead a la lista, ambos campos obligarios. Devuelve true/false
    function suscribeLead($id_lead,$id_list){
        try{
            $suscriptor = ORM::for_table('lead_users_lists')->where('id_leads',$id_lead)->where('id_leads_lists',$id_list)->find_one();
            if(!$suscriptor){
                $suscriptor = ORM::for_table('lead_users_lists')->create();
                $suscriptor->id_leads = $id_lead;
                $suscriptor->id_leads_lists = $id_list;

                $suscriptor->save();
            }

            return true;
        }catch(Exception $e){
            return false;
        }
    }

    //Elimina un lead, obligatorio el email. Devuelve true/false si hay error
    function deleteLead($email){
        try{
            $lead = ORM::for_table('leads')->where('email',$email)->delete();

            return true;
        }catch(Exception $e){
            return false;
        }
    }

    //Elimina al lead a la lista, ambos campos obligarios. Devuelve true/false
    function deleteLeadList($id_lead,$id_list){
        try{
            $suscriptor = ORM::for_table('lead_users_lists')->where('id_leads',$id_lead)->where('id_leads_lists',$id_list)->delete();

            return true;
        }catch(Exception $e){
            return false;
        }
    }
?>