<?php 
    class bbdd_update {

        function __construct() {
            // Constructor vacío
        }

        // Crear las tablas necesarias en la base de datos si no existen
        function update_database() {
            $db = ORM::get_db();

            // Funciones para admin_widgets
            $admin_widgets = ORM::forTable('admin_widgets')->where('name', 'Enviar Correos')->findMany()->count();
            if (!$admin_widgets) {
                $db->exec("
                    INSERT INTO admin_widgets (name, rol, files) VALUES
                    ('Enviar Correos', 3, 'mailing.php');
                ");
            }

            // Funciones para admin_modules_config
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "mailing"')->findMany()->count();
            if (!$test_module_config) {
                $db->exec("
                    INSERT INTO admin_modules_config (type, content) VALUES
                    ('Envío correos', '".json_encode(array('correo'=>'correo@prueba.com','nombre'=>'Tu nombre'))."');
                ");
            }

            // Funciones para admin_menu
            $admin_menu = ORM::forTable('admin_menu')->where('url', 'mailing')->findMany()->count();
            if (!$admin_menu) {
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Envío de correos', 'mailing', 'gi gi-envelope', 3, 35, 0);
                ");
            }

            // Funciones para leads
            $leads = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads"')->findMany()->count();
            if (!$leads) {
                $db->exec("
                    CREATE TABLE leads (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        activo int(11) NOT NULL DEFAULT '1',
                        nombre text COLLATE utf8_spanish_ci,
                        telefono int(9) DEFAULT NULL,
                        email varchar(255) COLLATE utf8_spanish_ci NOT NULL,
                        web varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
                        tipo int(1) NOT NULL DEFAULT '1',
                        send_mails int(1) NOT NULL DEFAULT '1' COMMENT 'Indica si podemos enviar correos a la direccion'
                    );
                ");
            }

            // Funciones para leads_type
            $leads_type = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads_type"')->findMany()->count();
            if (!$leads_type) {
                $db->exec("
                    CREATE TABLE leads_type (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        type varchar(255) COLLATE utf8_spanish_ci NOT NULL
                    );
                ");
                $db->exec("
                    INSERT INTO leads_type (type) VALUES
                    ('general');
                ");
            }
        }

        function delete_database() {
            $db = ORM::get_db();


            // Funciones para admin_widgets
            $admin_widgets = ORM::forTable('admin_widgets')->where('name', 'Enviar Correos')->findMany()->count();
            if ($admin_widgets) {
                $db->exec("
                    DELETE FROM admin_widgets WHERE name like 'Enviar Correos'
                ");
            }

            // Funciones para admin_modules_config
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "mailing"')->findMany()->count();
            if ($test_module_config) {
                $db->exec("
                    DELETE FROM admin_modules_config WHERE type like 'mailing'
                ");
            }

            // Funciones para leads
            $leads = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads"')->findMany()->count();
            if ($leads) {
                $db->exec("
                    DROP TABLE leads
                ");
            }

            // Funciones para leads_type
            $leads_type = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads_type"')->findMany()->count();
            if ($leads_type) {
                $db->exec("
                    DROP TABLE leads_type
                ");
            }
        }
    }
?>