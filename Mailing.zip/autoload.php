<?php 
    class bbdd_update {

        function __construct() {
            // Constructor vacío
        }

        // Crear las tablas necesarias en la base de datos si no existen
        function update_database() {
            $db = ORM::get_db();
            $local_folder = $_SERVER['DOCUMENT_ROOT'] . '/public/media/list_mailing/';
            mkdir($local_folder, 0777, true);

            // Funciones para admin_widgets
            $admin_widgets = ORM::forTable('admin_widgets')->where('name', 'Enviar Correos')->findMany()->count();
            if (!$admin_widgets) {
                $db->exec("
                    INSERT INTO admin_widgets (name, rol, files) VALUES
                    ('Enviar Correos', 3, 'mailing.php');
                ");
            }

            // Funciones para admin_modules_config
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "mailing"')->findMany()->count();
            if (!$test_module_config) {
                $db->exec("
                    INSERT INTO admin_modules_config (type, content) VALUES
                    ('mailing', '".json_encode(array('correo'=>'correo@prueba.com','nombre'=>'Tu nombre'))."');
                ");
            }

            // Funciones para admin_menu
            $admin_menu = ORM::forTable('admin_menu')->where('url', 'mailing')->findMany()->count();
            if (!$admin_menu) {
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Gestión correos', '', 'fal fa-envelope', 3, 35, 0);
                ");
                $padre = ORM::forTable('admin_menu')->where('name', 'Gestión correos')->find_one();
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Envío de correos', 'mailing', '', 3, 1, $padre->id);
                ");
                $db->exec("
                    INSERT INTO admin_menu (name, url, icon, rol, pos, id_parent) VALUES
                    ('Listas de envío', 'list_mailing', '', 3, 2, $padre->id);
                ");
            }

            // Funciones para leads
            $leads = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads"')->findMany()->count();
            if (!$leads) {
                $db->exec("
                    CREATE TABLE leads (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        activo int(11) NOT NULL DEFAULT '1',
                        nombre text COLLATE utf8_spanish_ci,
                        telefono int(9) DEFAULT NULL,
                        email varchar(255) COLLATE utf8_spanish_ci NOT NULL,
                        web varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
                        tipo int(1) NOT NULL DEFAULT '1',
                        send_mails int(1) NOT NULL DEFAULT '1' COMMENT 'Indica si podemos enviar correos a la direccion'
                    );
                ");
                $db->exec("
                    INSERT INTO leads_type (type) VALUES ('general');
                ");
            }

            // Funciones para leads_type
            $leads_type = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads_type"')->findMany()->count();
            if (!$leads_type) {
                $db->exec("
                    CREATE TABLE leads_type (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        type varchar(255) COLLATE utf8_spanish_ci NOT NULL
                    );
                ");
                $db->exec("
                    INSERT INTO leads_type (type) VALUES
                    ('general');
                ");
            }

            // Funciones para leads_list
            $leads_list = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads_lists"')->findMany()->count();
            if (!$leads_list) {
                $db->exec("
                    CREATE TABLE leads_list (
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        active int(11) NOT NULL DEFAULT '0',
                        name varchar(255) NOT NULL,
                        tipos varchar(255) NOT NULL COMMENT 'tipos a los que enviar la lista'
                    )
                ");
            }

            // Funciones para lead_lists_pasos
            $lead_lists_pasos = ORM::forTable('')->raw_query('SHOW TABLES LIKE "lead_lists_pasos"')->findMany()->count();
            if (!$lead_lists_pasos) {
                $db->exec("
                    CREATE TABLE lead_lists_pasos (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        id_leads_lists INT NOT NULL,
                        numero_paso INT NOT NULL,
                        tiempo_espera INT,
                        subject varchar(255),
                        email_content text,
                        style text
                    )
                ");
            }

            // Funciones para lead_users_lists
            $lead_users_lists = ORM::forTable('')->raw_query('SHOW TABLES LIKE "lead_users_lists"')->findMany()->count();
            if (!$lead_users_lists) {
                $db->exec("
                    CREATE TABLE lead_users_lists (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        id_leads int(11) NOT NULL,
                        id_leads_lists int(11) NOT NULL,
                        active int(11) NOT NULL DEFAULT '1',
                        paso int(11) NOT NULL DEFAULT '0',
                        last_email_sent_time DATETIME NULL
                    )
                ");
            }
        }

        function delete_database() {
            $db = ORM::get_db();
            $local_folder = $_SERVER['DOCUMENT_ROOT'] . '/public/media/list_mailing/';
            self::eliminarCarpeta($local_folder);

            // Funciones para admin_widgets
            $admin_widgets = ORM::forTable('admin_widgets')->where('name', 'Enviar Correos')->findMany()->count();
            if ($admin_widgets) {
                $db->exec("
                    DELETE FROM admin_widgets WHERE name like 'Enviar Correos'
                ");
            }

            $admin_menu = ORM::forTable('admin_menu')->where('name', 'Gestión correos')->findMany()->count();
            if ($admin_menu) {
                $id_parent = ORM::for_table('admin_menu')->where('name', 'Gestión correos')->find_one();
                $db->exec("
                    DELETE FROM admin_menu WHERE id_parent = $id_parent->id
                ");

                $db->exec("
                    DELETE FROM admin_menu WHERE id = $id_parent->id
                ");
            }

            // Funciones para admin_modules_config
            $test_module_config = ORM::forTable('')->raw_query('SELECT * FROM admin_modules_config WHERE type LIKE "mailing"')->findMany()->count();
            if ($test_module_config) {
                $db->exec("
                    DELETE FROM admin_modules_config WHERE type like 'mailing'
                ");
            }

            // Funciones para leads
            $leads = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads"')->findMany()->count();
            if ($leads) {
                $db->exec("
                    DROP TABLE leads
                ");
            }

            // Funciones para leads_type
            $leads_type = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads_type"')->findMany()->count();
            if ($leads_type) {
                $db->exec("
                    DROP TABLE leads_type
                ");
            }

            // Funciones para leads_lists
            $leads_lists = ORM::forTable('')->raw_query('SHOW TABLES LIKE "leads_lists"')->findMany()->count();
            if ($leads_lists) {
                $db->exec("
                    DROP TABLE leads_lists
                ");
            }

            // Funciones para lead_lists_pasos
            $lead_lists_pasos = ORM::forTable('')->raw_query('SHOW TABLES LIKE "lead_lists_pasos"')->findMany()->count();
            if ($lead_lists_pasos) {
                $db->exec("
                    DROP TABLE lead_lists_pasos
                ");
            }

            // Funciones para lead_users_lists
            $lead_users_lists = ORM::forTable('')->raw_query('SHOW TABLES LIKE "lead_users_lists"')->findMany()->count();
            if ($lead_users_lists) {
                $db->exec("
                    DROP TABLE lead_users_lists
                ");
            }
        }

        public function eliminarCarpeta($carpeta) {
            // Verificar si la carpeta existe
            if (!is_dir($carpeta)) {
                return false;
            }

            // Obtener el contenido de la carpeta
            $archivos = array_diff(scandir($carpeta), array('.', '..'));

            // Eliminar recursivamente los archivos y subcarpetas
            foreach ($archivos as $archivo) {
                $ruta = $carpeta . '/' . $archivo;
                if (is_dir($ruta)) {
                    self::eliminarCarpeta($ruta); // Llamada recursiva para eliminar subcarpetas
                } else {
                    unlink($ruta); // Eliminar archivo
                }
            }

            // Eliminar la carpeta principal
            return rmdir($carpeta);
        }
    }
?>