# cms_module-demo
Crea un fichero para poder utilizar las funcionalidades desde otros modulos, es el caso de contacto por ejemplo.
Estas clases permite, crear, alistar y borrar a usuarios del sistema de mailing:

addLead: Agrega un nuevo lead, obligatorio el email. Devuelve el id del lead o false si hay error || addLead($email,$name='',$telf=null,$web='',$tipo=1)

suscribeLead: Suscribe al lead a la lista, ambos campos obligarios. Devuelve true/false ||suscribeLead($id_lead,$id_list)

deleteLead: Elimina un lead, obligatorio el email. Devuelve true/false si hay error || deleteLead($email)

deleteLeadList: Elimina al lead a la lista, ambos campos obligarios. Devuelve true/false || deleteLeadList($id_lead,$id_list)
