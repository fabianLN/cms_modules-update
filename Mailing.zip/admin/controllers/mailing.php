<?php
_auth();

switch ( $action ) {
    case 'create-act-leads':
		if($_POST['id'] != ''){
			$lead = ORM::for_table( 'leads' )->find_one($_POST['id']);
            $admin_text = 'Guardado lead ';
		}else{
			$lead = ORM::for_table( 'leads' )->create();
            $admin_text = 'Creado el lead ';
		}

		if(!isset($_POST['nombre'])){
			echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'El nombre es obligatorio'));
		}
		if(!isset($_POST['correo'])){
			echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'El correo es obligatorio'));
		}

		$lead->nombre = $_POST['nombre'];
		$lead->email = $_POST['correo'];
		$lead->telefono = (isset($_POST['telefono']) && is_numeric($_POST['telefono']))? $_POST['telefono'] : 0;
		$lead->web = (isset($_POST['web']))? $_POST['web'] : '';
		$lead->tipo = (isset($_POST['tipo']))? $_POST['tipo'] : '';

		if($lead->save()){
			admin_log($admin_text.$lead->id);
			echo json_encode(array('code' => 1, 'class' => 'success', 'text' => 'Registro guardado'));
		}else{
			echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'No se ha podido guardar el registro'));
		}
		break;
	case 'delete_lead':
		$lead = ORM::for_table( 'leads' )->find_one($_POST['id']);
		$id = $lead->id;

		if($lead->delete()){
			admin_log('Borrado el lead: '.$id);
			echo json_encode(array('code' => 1, 'class' => 'success', 'text' => 'Borrado correctamente'));
		}else{
			echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'No se ha podido borrar el registro'));
		}
		break;
	case 'send_mail':
		include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/admin/lib/modules/PHPMailer/SendMail.php' );

		//las otras variables
		$asunto = $_POST['asunto'];
		$contenido = $_POST['cuerpo'];

		// Llama a la función enviarCorreo() para enviar el correo electrónico
		$correos = explode(',',$_POST['correos']);

		if(count($correos) > 0){
			$enviarFichero = false;
			if($_FILES['fichero']['name'] != ''){
				$uploadfile = tempnam(sys_get_temp_dir(), hash('sha256', $_FILES['fichero']['name']));
				if (!move_uploaded_file($_FILES['fichero']['tmp_name'], $uploadfile)) {
					if($_FILES['fichero']['error'] == 2){
						echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'El tamaño supera el límite'));
						exit;
					}else{
						echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'El fichero contiene errores'));
						exit;
					}
				}
			}

			for ($i=0;count($correos)>=$i;$i++) {
				if($_FILES['fichero']['name'] != ''){
					$resultado .= enviarCorreo($correos[$i],$asunto,$contenido,$_FILES['fichero']['name'],$uploadfile);
				}else{
					$resultado .= enviarCorreo($correos[$i],$asunto,$contenido);
				}
			}
		}else{
			echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'No hay correos para enviar'));
			exit;
		}

		// Muestra el resultado
		if($resultado != ''){
			echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => $resultado));
		}else{
			echo json_encode(array('code' => 1, 'class' => 'success', 'text' => 'Envío realizado correctamente'));
		}
		break;
	case 'addTipo':
		$leads_type = ORM::for_table( 'leads_type' )->create();
		$leads_type->type = $_POST['newTipo'];

		if($leads_type->save()){
			admin_log('Guardado el nuevo tipo: '.$leads_type->id);
			echo json_encode(array('code' => 1, 'class' => 'success', 'text' => 'Guardado el nuevo tipo'));
		}else{
			echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'No se ha podido guardar el nuevo tipo'));
		}
		break;

	default:
		$leads = ORM::for_table( 'leads' )->where('activo',1)->where('send_mails',1)->find_many();
		$leads_type = ORM::for_table( 'leads_type' )->find_many();

		foreach ($leads_type as $type) {
			$types[$type->id]['id'] = $type->id;
			$types[$type->id]['type'] = $type->type;
		}

		$js_footer = array( 'mailing' );
		include( './admin/view/page_ecom_correos.php' );
		break;
}
?>