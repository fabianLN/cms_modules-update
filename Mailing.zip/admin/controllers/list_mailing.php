<?php
_auth();

switch ( $action ) {
    case 'view-list':
        $list = ORM::for_table( 'leads_lists' )->find_one($routes[2]);
		$leads_type = ORM::for_table( 'leads_type' )->find_many();
		$emails = ORM::for_table('lead_users_lists') ->select('lead_users_lists.*') ->select('leads.email') ->join('leads', array( 'lead_users_lists.id_leads', '=', 'leads.id' )) ->where('lead_users_lists.id_leads_lists', $list->id) ->find_many();
		$pasos = ORM::for_table( 'lead_lists_pasos' )->where('id_leads_lists', $list->id)->order_by_asc('numero_paso')->find_many();

		foreach ($leads_type as $type) {
			$types[$type->id]['id'] = $type->id;
			$types[$type->id]['type'] = $type->type;
		}

		// Inicializar un array para almacenar los pasos
		$datos_pasos = [];

		// Recorrer los pasos y agregarlos al array
		foreach ($pasos as $paso) {
			$datos_pasos[] = [
				'id' => $paso->id,
				'numero_paso' => $paso->numero_paso,
				'tiempoEspera' => $paso->tiempo_espera,
				'subject' => $paso->subject
			];
		}

		// Convertir el array de pasos a formato JSON
		$json_pasos = json_encode($datos_pasos);
		$contPasos = count($pasos);

		$js_footer = array( 'mailingList' );
		include( './admin/view/page_ecom_email_list.php' );
        break;
    case 'create-list':
        $leads_type = ORM::for_table( 'leads_type' )->find_many();

		foreach ($leads_type as $type) {
			$types[$type->id]['id'] = $type->id;
			$types[$type->id]['type'] = $type->type;
		}

		$js_footer = array( 'mailingList' );
		include( './admin/view/page_ecom_email_list.php' );
        break;
    case 'act_create_list':
        if(isset($_POST['id']) && $_POST['id'] != ''){
            $list = ORM::for_table( 'leads_lists' )->find_one($_POST['id']);
            $existe = true;
        }else{
            $list = ORM::for_table( 'leads_lists' )->create();
            $existe = false;
        }

        ($_POST['active'] == 'true')? $list->active = 1 : $list->active = 0;
        $list->name = $_POST['name'];
        $list->tipos = implode(',',$_POST['tipo']);

        if($list->save()){
            if($existe){
                admin_log('Lista de mailing actualizada: '.$list->name);
                echo json_encode(array('code' => 1, 'class' => 'success', 'text' => 'Guardada la lista'));
            }else{
                admin_log('Lista de mailing creada: '.$list->name);
                echo json_encode(array('code' => 1, 'class' => 'success', 'text' => 'Creada la lista', 'id' => $list->id));
            }
		}else{
			echo json_encode(array('code' => 0, 'class' => 'danger', 'text' => 'No se ha podido guardar la lista'));
		}
        break;
	case 'activeCron':
		include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/admin/lib/modules/CronJob/CronManager.php' );
		switch ($_POST['action']) {
			case 'crear':
				$result = manageCronJob('crear', '* * * * *', 'sendMails.php', 'envio_mails');
				break;
			case 'borrar':
				$result = manageCronJob('borrar', '', '', 'envio_mails');
				break;
			default:
				echo json_encode(array('code' => 1, 'class' => 'danger', 'text' => 'No has enviado una acción clara'));
				exit;
				break;
		}

		$result = json_decode($result,true);
		admin_log("La tarea cron ".$result['id']." ha sido ".$result['action'].' con éxito');
		echo json_encode(array('code' => 1, 'text' => $result['action']));
		break;
	case 'save_pasos':
		// Obtener el JSON enviado por AJAX
		$input = file_get_contents('php://input');
		$data = json_decode($input, true);
	
		if (!empty($data['pasos'])) {
			// Obtener los IDs de los pasos enviados por el usuario
			$ids_pasos_enviados = array_column($data['pasos'], 'id');
	
			// Obtener los IDs de los pasos existentes en la base de datos para esta lista
			$ids_pasos_db = ORM::for_table('lead_lists_pasos')
				->where('id_leads_lists', $data['listaId'])
				->select('id')
				->find_array();
	
			$ids_pasos_db = array_column($ids_pasos_db, 'id');
	
			// Identificar los IDs de pasos que ya no están presentes en la lista enviada por el usuario
			$ids_pasos_a_eliminar = array_diff($ids_pasos_db, $ids_pasos_enviados);
	
			// Eliminar los pasos que ya no están presentes en la lista enviada por el usuario
			if (!empty($ids_pasos_a_eliminar)) {
				ORM::for_table('lead_lists_pasos')
					->where('id', $ids_pasos_a_eliminar)
					->delete_many();
			}
	
			// Recorrer los pasos enviados por el usuario para actualizar o crear en la base de datos
			foreach ($data['pasos'] as $paso) {
				// Verificar si el paso ya existe en la base de datos
				$qPaso = ORM::for_table('lead_lists_pasos')->where('id_leads_lists', $data['listaId'])->where('numero_paso', $paso['numero_paso'])->find_one();
	
				if (!$qPaso) {
					// Si el paso no existe, crearlo
					$qPaso = ORM::for_table('lead_lists_pasos')->create();
				}
	
				$qPaso->id_leads_lists = $data['listaId'];
				$qPaso->subject = $paso['subject'];
				$qPaso->numero_paso = $paso['numero_paso'];
				$qPaso->tiempo_espera = isset($paso['tiempoEspera']) ? $paso['tiempoEspera'] : null;
				$qPaso->save();
			}
	
			admin_log('Pasos guardados de la lista '.$data['listaId']);
			echo json_encode(['status' => 'success', 'class' => 'success', 'text' => 'Pasos guardados exitosamente']);
		} else {
			// Si no se recibieron pasos, eliminar todos los pasos asociados con esta lista
			ORM::for_table('lead_lists_pasos')
				->where('id_leads_lists', $data['listaId'])
				->delete_many();
	
			admin_log('Borrados los pasos de la lista: '.$list->name);
			echo json_encode(['status' => 'error', 'class' => 'danger', 'text' => 'No se recibieron pasos, se ha dejado la lista en blanco']);
		}
		break;
	case 'content_update':
		$list = ORM::for_table('lead_lists_pasos')->find_one($routes[2]);
		$list->email_content = getbody(TildesHtml($_POST['content']));
		$list->style = getstyle(TildesHtml($_POST['content']),$list->style);
		if($list->save()){
			admin_log('Actualizado el texto de la lista: '.$list->id);
			echo 'list guardado correctamente';
		}else{
			echo 'Algo ha fallado al actualizar el texto del list';
		}
		break;
	case 'getLeads':
		$leads = ORM::for_table('leads')
		->select('leads.id', 'id')
		->select('leads.email')
		->left_outer_join('lead_users_lists', array('leads.id', '=', 'lead_users_lists.id_leads'))
		->where_raw('lead_users_lists.id_leads_lists IS NULL OR lead_users_lists.id_leads_lists != ?', array($_POST['id']))
		->find_many();

		$return = '<label class="nuevos_inscritos col-md-2">Seleccionar:</label>
		<select class="form-control col-md-10" id="nuevos_inscritos" placeholder="Para filtrar los contactos" name="nuevos_inscritos[]" multiple>';
			foreach ($leads as $lead) {
				$return .= '<option value="'.$lead->id.'">'.$lead->email.'</option>';
			}
		$return .= '</select>';

		echo $return;
		break;
	case 'setInscritos':
		foreach ($_POST['inscritos'] as $id) { 
			$inscrito = ORM::for_table( 'lead_users_lists' )->where('id_leads',$id)->find_one();
			if(!$inscrito){$inscrito = ORM::for_table( 'lead_users_lists' )->create();}
			$inscrito->id_leads = $id;
			$inscrito->id_leads_lists = $_POST['id'];
			$inscrito->save();
		}

		admin_log('Nuevo inscrito a la lista: '.$_POST['id']);
		echo json_encode(['status' => 'success', 'class' => 'success', 'text' => 'Inscritos guardados exitosamente']);
		break;
	case 'activeUser':
		$inscrito = ORM::for_table( 'lead_users_lists' )->where('id_leads_lists',$_POST['list'])->find_one($_POST['id']);
		$inscrito->active = ($_POST['active']=='true')? 1 : 0;
		$inscrito->save();
		admin_log('Cambiado el estado del inscrito: '.$_POST['id'].' de la lista: '.$_POST['list']);
		break;
	default:
		$lists = ORM::for_table( 'leads_lists' )->find_many();
		$leads_type = ORM::for_table( 'leads_type' )->find_many();

		foreach ($leads_type as $type) {
			$types[$type->id]['id'] = $type->id;
			$types[$type->id]['type'] = $type->type;
		}

		$identifier = "envio_mails";
		if (cronJobExists($identifier)) {
			$cron['class'] = 'success';
			$cron['text'] = 'Activada';
			$cron['action'] = 'borrar';
		} else {
			$cron['class'] = 'danger';
			$cron['text'] = 'No activada';
			$cron['action'] = 'crear';
		}

		$js_footer = array( 'mailingList' );
		include( './admin/view/page_ecom_email_all_list.php' );
		break;
}


function getbody($html) {
	$dom = new DOMDocument;
	$dom->loadHTML($html);
	$bodies = $dom->getElementsByTagName('body');
	assert($bodies->length === 1);
	$body = $bodies->item(0);
	for ($i = 0; $i < $body->children->length; $i++) {
		$body->remove($body->children->item($i));
	}
	$stringbody = $dom->saveHTML($body);
	if (preg_match('/(?:<body[^>]*>)(.*)<\/body>/isU', $stringbody, $matches)) {
        $body = $matches[1];
    }
	return $body;
}

function getstyle($html,$style) {
	$dom = new DOMDocument;
	$dom->loadHTML($html);
	$bodies = $dom->getElementById('vvvebjs-styles');

	return ($bodies->textContent != '')?$bodies->textContent : $style;
}

function TildesHtml($cadena) 
{ 
	return str_replace(
		array("á","é","í","ó","ú","ñ","Á","É","Í","Ó","Ú","Ñ","¡","!","º"),
		array("&aacute;","&eacute;","&iacute;","&oacute;","&uacute;","&ntilde;","&Aacute;","&Eacute;","&Iacute;","&Oacute;","&Uacute;","&Ntilde;","&iexcl;","&iexcl;",'&ordm;'), 
		$cadena);     
}

function cronJobExists($identifier) {
    // Ejecutar el comando para listar las tareas cron del usuario actual
    $output = [];
    exec('crontab -l', $output);

    // Recorrer las líneas del crontab buscando el identificador
    foreach ($output as $line) {
        if (strpos($line, $identifier) !== false) {
            return true;
        }
    }

    return false;
}
?>