<?php if($usuario->rol <= 3){ ?>
    <div class="col-sm-6 col-lg-3">
        <!-- Widget -->
        <a href="<?= URL_POST ?>mailing" class="widget widget-hover-effect1">
            <div class="widget-simple">
                <div class="widget-icon pull-left themed-background-blackberry animation-fadeIn">
                    <i class="gi gi-envelope"></i>
                </div>
                <h3 class="widget-content text-right animation-pullDown">
                    <strong>Enviar Correos</strong><br>
                    <?php /* ?><small>LO QUE QUIERAS</small><?php */ ?>
                </h3>
            </div>
        </a>
        <!-- END Widget -->
    </div>
<?php } ?>