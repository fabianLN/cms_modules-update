<?php include 'sections/template_start.php'; ?>
<?php include 'sections/page_head.php'; ?>
<?php $_SESSION['prevpag'] = sprintf("%s://%s%s",isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'],$_SERVER['REQUEST_URI']) ?>

<!-- list content -->
<div id="page-content">
    <!-- Quick Stats -->
    <div class="row text-center">
        <div class="col-sm-6 col-lg-3">
            <div data-action="<?=$cron['action']?>" class="widget widget-hover-effect2 update_mailing_cron">
                <div class="widget-extra themed-background-<?=$cron['class']?>">
                    <h4 class="widget-content-light"><strong>Tarea Cron</strong> <span class="cron_text"><?=$cron['text']?></span></h4>
                </div>
                <div class="widget-extra-full"><span class="h2 text-<?=$cron['class']?> animation-expandOpen">Envío lista correo</span></div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 pull-right">
            <a href="<?= URL_POST ?>list_mailing/create-list" class="widget widget-hover-effect2">
                <div class="widget-extra themed-background-success">
                    <h4 class="widget-content-light"><strong>Añadir</strong> Nueva lista</h4>
                </div>
                <div class="widget-extra-full"><span class="h2 text-success animation-expandOpen"><i class="fa fa-plus"></i></span></div>
            </a>
        </div>
    </div>
    <!-- END Quick Stats -->

    <!-- All Orders Block -->
    <div class="block full">
        <!-- All Orders Title -->
        <div class="block-title">
            <h2><strong>Todas</strong> las listas</h2>
            <div class="block-options pull-right"></div>
        </div>
        <!-- END All Orders Title -->

        <!-- All Orders Content -->
        <div id="avisos-mailing"></div>
		<?php if(count($lists)){ ?>
        <table id="ecom-lists" class="table table-bordered table-striped table-vcenter">
            <thead>
                <tr>
                    <th class="text-center" style="width: 100px;">ID</th>
                    <th class="visible-lg">Nombre</th>
                    <th class="text-center visible-lg">Activa</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
				$labels['0']['class']   = "label-danger";
                $labels['0']['text']    = "No activa";
                $labels['1']['class']   = "label-success";
                $labels['1']['text']    = "Activa";

                ?>
                <?php foreach($lists as $list) { ?>
                <tr>
                    <td class="text-center"><a href="<?= URL_POST ?>list_mailing/view-list/<?= $list->id ?>"><strong><?= $list->id ?></strong></a></td>
                    <td class="visible-lg"><a href="<?= URL_POST ?>list_mailing/view-list/<?= $list->id ?>"><?= $list->name ?></a></td>
                    <td class="text-center"><span class="label<?= ($labels[$list->active]['class']) ? " " . $labels[$list->active]['class'] : ""; ?>"><?php echo $labels[$list->active]['text']; ?></span></td>
                    <td class="text-center">
                        <div class="btn-group btn-group-sm">
                            <a href="<?= URL_POST ?>list_mailing/view-list/<?= $list->id ?>" data-toggle="tooltip" title="Editar" class="btn btn-warning"><i class="fa fa-pencil"></i></a>
                            <?php if($list->fixed != 1){ ?><a href="#" url_action='<?= URL_POST ?>list_mailing/delete-list/<?= $list->id ?>' class="btn btn btn-danger pull-right mr-10 deleteField"><i class="fa fa-times"></i></a><?php } ?>
                        </div>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <!-- END All Orders Content -->
		<?php }else{ echo 'No tienes listas creadas, puedes crear la primera.'; } ?>
    </div>
    <!-- END All Orders Block -->
</div>
<!-- END list Content -->

<?php include 'sections/page_footer.php'; ?>
<?php include 'sections/template_scripts.php'; ?>

<!-- Load and execute javascript code used only in this list -->
<script src="assets/js/pages/ecomOrders.js"></script>

<?php include 'sections/template_end.php'; ?>

<script>var url_post = '<?=URL_POST?>'; </script>
<?php $module_type = 'mailing'?>
<?php include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/ModuleConfig/autoload.php'; ?>