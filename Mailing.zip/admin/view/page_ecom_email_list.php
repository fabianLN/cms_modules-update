<?php include 'sections/template_start.php'; ?>
<link rel="stylesheet" href="/<?= URL ?>assets/css/steps.css">
<?php include 'sections/page_head.php'; ?>
<?php $_SESSION['prevpag'] = sprintf("%s://%s%s",isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'],$_SERVER['REQUEST_URI']) ?>
<!-- Page content -->
<div id="page-content">

    <!-- zona de leads Block -->
    <div class="block full">
        <div class="block-title">
            <h2><strong>listas</strong> de correos</h2>
            <div class="block-options pull-right">
                <button id="actCreateList" class="btn btn btn-success pull-right ml-10" data-id="<?=$list->id?>"><i class="fa fa-floppy-o"></i> Guardar</button>
            </div>
        </div>
        <div class="card-body">
            <div id="avisos-mailing"></div>
            
            <div class="form-group">

                <div class="col-md-2">
                    <label class="col-md-12 control-label">Activa</label>
                    <div class="col-md-12">
                        <label class="switch switch-success">
                            <input type="checkbox" id="list-active" name="list-active" <?php if($list->active == 1 ||  (!isset($list)) ){echo 'checked'; } if($list->fixed == 1){ ?> disabled <?php } ?>>
                            <span></span>
                        </label>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="colorNegro">Nombre</label>
                    <input type="text" class="form-control" placeholder="El nombre de la lista" value="<?=$list->name?>" name="nombre_list" id="nombre_list">
                </div>
                <div class="col-md-4">
                    <label class="colorNegro col-md-2">Tipo</label>
                    <select class="form-control col-md-10" id="tipo_envio" placeholder="Para filtrar los contactos" name="tipo_envio[]" multiple>
                        <?php $tipos = explode(',',$list->tipos)?>
                        <?php foreach ($types as $type) { ?>
                            <option value="<?=$type['id']?>" <?php if(in_array($type['id'],$tipos)){echo 'selected';}?>><?=$type['type']?></option>
                        <?php } ?>
                    </select>
                </div>

            </div>
        </div>
    </div>

    <!-- zona de inscritos Block -->
    <?php if($list->id){ ?>
        <div class="block full">
            <!-- All Orders Title -->
            <div class="block-title">
                <h2><strong>Todos</strong> los inscritos</h2>
                <div class="pull-right">
                    <a href="#modal-incripcion" class="btn btn-sm btn-success pull-right mr-10 modal-inscripcion"  data-toggle="modal"><i class="fa fa-plus"></i> Inscribir</a>
                </div>
            </div>
            <!-- END All Orders Title -->

            <!-- usuarios en la lista -->
            <?php if(count($emails)){ ?>
                <table id="ecom-lists" class="table table-bordered table-striped table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center visible-lg">Activa</th>
                            <th class="visible-lg">Email</th>
                            <th class="text-center visible-lg">Paso</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($emails as $email) { ?>
                        <tr>
                            <td class="text-center">
                                <label class="switch switch-success">
                                    <input type="checkbox" data-id="<?=$email->id?>" class="email-active" name="email-active" <?php if($email->active == 1 ||  (!isset($list)) ){echo 'checked'; } if($email->fixed == 1){ ?> disabled <?php } ?>>
                                    <span></span>
                                </label>
                            </td>
                            <td class="visible-lg"><?= $email->email ?></td>
                            <td class="text-center visible-lg"><?= ($email->paso < $contPasos)? $email->paso : 'Finalizada' ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php }else{ echo 'No tienes usuarios asignados.'; } ?>
            <!-- END All Orders Content -->
        </div>
    <?php } ?>

    <!-- zona de leads Block -->
    <?php if($list->id){ ?>
        <div class="block full">
            <div class="block-title">
                <h2>Gestiona <strong>listas de correos</strong></h2>
                <div class="pull-right">
                    <button class="btn btn-info" id="agregar-paso">Agregar Paso</button>
                    <button class="btn btn-success" id="guardar-pasos"><i class="fa fa-floppy-o"></i> Guardar</button>
                </div>
            </div>
            <div class="card-body">
                <div id="avisos-listing"></div>
                <script> const pasosJSON = <?=$json_pasos?>;</script>
                <div id="pasos"></div>

            </div>

        </div>
    <?php } ?>

    <!-- zona modales -->
    <div id="modal-incripcion" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close btn-close-modal" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title">Nuevos inscritos</h3>
                </div>
                <div class="modal-body">
                    <div class="row form-group leads_mailing">

                        <div class="col-md-12 alert alert-danger tipo_notify_danger" style="display: none">
                            <p>Hay campos obligatorios sin rellenar</p>
                        </div>
                        <div class="col-md-12 incripcion-select">
                            
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="agregar-inscrito" class="btn btn-sm btn-success">Inscribir</button>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- END Page Content -->
<?php include 'sections/page_footer.php'; ?>
<?php include 'sections/template_scripts.php'; ?>
<?php include 'sections/template_end.php'; ?>
<!-- Load and execute javascript code used only in this page -->
<script src="/<?= URL ?>assets/js/pages/ecomOrders.js"></script>
<script>var url_post = '<?=URL_POST?>'; </script>

<script src="/<?= URL ?>lib/modules/contactSteps/steps.js"></script>