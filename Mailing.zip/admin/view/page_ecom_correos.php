<?php include 'sections/template_start.php'; ?>
<?php include 'sections/page_head.php'; ?>
<?php $_SESSION['prevpag'] = sprintf("%s://%s%s",isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'],$_SERVER['REQUEST_URI']) ?>
<!-- Page content -->
<div id="page-content">

    <!-- zona de leads Block -->
    <div class="block full">
        <div class="block-title">
            <h2>Enviar <strong>correos</strong></h2>
            <div class="block-options pull-right"></div>
            <a href="#modal-newlead" class="btn btn-sm btn-success pull-right create_leads" data-toggle="modal"><i class="fa fa-plus"></i> <span class="d-xs-none">Nuevo registro</span></a>
            <a href="#modal-tipo" class="btn btn-sm btn-warning pull-right mr-10"  data-toggle="modal"><i class="fa fa-plus"></i> Tipo</a>
            <a href="#modal-sendMail" class="btn btn-sm btn-info pull-right mr-10" data-toggle="modal"><i class="fa fa-envelope"></i></a>
        </div>
        <div class="card-body">
            <div id="avisos-mailing"></div>
            <table id="ecom-leads" class="table table-bordered table-striped table-vcenter">
                <thead>
                    <tr>
                        <td>Enviar</td>
                        <td>Nombre</td>
                        <td>Correo</td>
                        <td>Teléfono</td>
                        <td>Web</td>
                        <td>Tipo</td>
                        <td>Editar</td>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($leads as $leads){ ?>
                        <tr>
                            <td>
                                <div>
                                    <label class="switch switch-success">
                                        <input type="checkbox" class="enviar_leads" name="enviar_leads" value="<?=$leads->email?>">
                                        <span></span>
                                    </label>
                                </div>
                            </td>
                            <td><?=$leads->nombre?></td>
                            <td><a href="mailto:<?=$leads->email?>"><?=$leads->email?></a></td>
                            <td><a href="tel:<?=$leads->telefono?>"><?=$leads->telefono?></a></td>
                            <td><a href="<?=$leads->web?>" target="_blank"><?=$leads->web?></a></td>
                            <td><?=$types[$leads->tipo]['type']?></td>
                            <td>
                                <button class="btn btn-sm btn-success edit_leads" data-id="<?=$leads->id?>" data-nombre="<?=$leads->nombre?>" data-email="<?=$leads->email?>" data-telefono="<?=$leads->telefono?>" data-web="<?=$leads->web?>" data-tipo="<?=$leads->tipo?>"><i class="fa fa-pencil"></i></button>
                                <button class="btn btn-sm btn-danger delete_lead" data-id="<?=$leads->id?>" data-nombre="<?=$leads->nombre?>" data-email="<?=$leads->email?>" data-telefono="<?=$leads->telefono?>" data-web="<?=$leads->web?>" data-tipo="<?=$leads->tipo?>"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- zona de modales -->
    <div id="modal-newlead" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close btn-close-modal" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title">Gestión de leads</h3>
                </div>
                <div class="modal-body">
                    <div class="row form-group leads_mailing">

                        <div class="col-md-12 alert alert-danger leads_notify_danger" style="display: none">
                            <p>Hay campos obligatorios sin rellenar, ¿has seleccionado leads?</p>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="colorNegro">Nombre*</label>
                                <input type="text" class="form-control" placeholder="El nombre del contacto" value="" name="nombre_leads" id="nombre_leads">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="colorNegro">Correo*</label>
                                <input type="text" class="form-control" placeholder="Para contactar y enviar los correos" value="" name="correo_leads" id="correo_leads">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="colorNegro">Teléfono</label>
                                <input type="text" class="form-control" placeholder="Pues eso, su número" value="" name="telf_leads" id="telf_leads">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="colorNegro">Web</label>
                                <input type="text" class="form-control" placeholder="Si la tuviese el contacto" value="" name="web_leads" id="web_leads">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="colorNegro">Tipo</label>
                                <select class="form-control" id="tipo_leads" placeholder="Para filtrar los contactos" name="tipo_leads">
                                    <?php foreach ($types as $type) { ?>
                                        <option value="<?=$type['id']?>"><?=$type['type']?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="hiden_info">
                            <input type="hidden" id="id_leads" name="id_leads" value="">
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="create-act-leads" class="btn btn-sm btn-success">Guardar</button>
                </div>
            </div>
        </div>
    </div>
    <div id="modal-sendMail" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close btn-close-modal" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title">Nuevo correo</h3>
                </div>
                <div class="modal-body">
                    <div class="row form-group leads_mailing">

                        <div class="col-md-12 alert alert-danger leads_notify_danger" style="display: none">
                            <p>Hay campos obligatorios sin rellenar, ¿has seleccionado leads?</p>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="colorNegro">Asunto*</label>
                                <input type="text" class="form-control" placeholder="Asunto" value="" name="asunto_leads" id="asunto_leads">
                            </div>
                        </div>
                        <div class="col-md-12 mt-20">
                            <div class="form-check">
                                <label>
                                <label for="userfile" class="colorNegro">Enviar fichero:</label> <input name="userfile_leads" id="userfile_leads" type="file">
                                </label>
                            </div>
                        </div>
                        <div class="col-md-12  mt-20">
                            <div class="form-group">
                                <label class="colorNegro">Cuerpo*</label>
                                <textarea class="ckeditor" id="cuerpo_leads" name="cuerpo_leads" id="cuerpo_leads"></textarea>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="sendMail" class="btn btn-sm btn-success">Enviar</button>
                </div>
            </div>
        </div>
    </div>
    <div id="modal-tipo" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close btn-close-modal" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title">Nuevo tipo</h3>
                </div>
                <div class="modal-body">
                    <div class="row form-group leads_mailing">

                        <div class="col-md-12 alert alert-danger tipo_notify_danger" style="display: none">
                            <p>Hay campos obligatorios sin rellenar</p>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="colorNegro">Tipo*</label>
                                <input type="text" class="form-control" placeholder="Asunto" value="" name="newTipo" id="newTipo">
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="createTipo" class="btn btn-sm btn-success">Enviar</button>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- END Page Content -->
<?php include 'sections/page_footer.php'; ?>
<?php include 'sections/template_scripts.php'; ?>
<?php include 'sections/template_end.php'; ?>
<script src="/<?=URL?>assets/js/helpers/ckeditor/ckeditor.js"></script>
<!-- Load and execute javascript code used only in this page -->
<script src="/<?= URL ?>assets/js/pages/ecomOrders.js"></script>
<script>var url_post = '<?=URL_POST?>'; </script>

<?php $module_type = 'mailing'?>
<?php include_once $_SERVER['DOCUMENT_ROOT'] . '/admin/lib/modules/ModuleConfig/autoload.php'; ?>