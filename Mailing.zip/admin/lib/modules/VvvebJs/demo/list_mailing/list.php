<?php
    $internal = true;
    include_once( $_SERVER[ 'DOCUMENT_ROOT' ] . '/config/init.php' );
    $query = ORM::for_table($_GET['action'])->find_one($_GET['id']);
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Album example for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="../../css/editor.css" rel="stylesheet">
    <link href="../../css/block.css" rel="stylesheet">
    <link data-vvveb-helpers="" href="../../css/vvvebjs-editor-helpers.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="../../js/popper.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/holderjs@2.9.4/holder.js"></script>
    <style>
		html, body
		{
			width:100%;
			height:100%;
      background-color: #fff;
		}
    </style>
    <style id="vvvebjs-styles">
      <?=$query->style?>
    </style>
  </head>

  <body>
    <?php if($query->email_content != ''){ ?>
        <?= $query->email_content; ?>
    <?php }else{ ?>
      <!-- Page Content -->
      <div class="container" style="min-height:150px;">
        <div class="m-5">
            <div class="row">
                <h1>Empieza a crear ahora</h1>
            </div>
        </div>
    </div>
    <?php } ?>
  </body>
</html>
