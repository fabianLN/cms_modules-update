<?php
ignore_user_abort(true);
@ini_set('memory_limit', '10000M');
@date_default_timezone_set('Europe/Madrid');
set_time_limit(0);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(1);

// Define la ruta base subiendo dos niveles desde el directorio actual
$basePath = dirname(__DIR__, 5);
$_SERVER['DOCUMENT_ROOT'] = $basePath;

// Incluye los archivos necesarios usando la ruta base
$internal = true;
include_once($basePath . '/config/init.php');
include_once($basePath . '/admin/funciones.php');
include_once($basePath . '/admin/lib/modules/PHPMailer/SendMail.php');

// Obtener listas de leads activas
$leads_lists = ORM::for_table('leads_lists')->where('active', 1)->find_many();

foreach ($leads_lists as $leads_list) {
    // Obtener leads asociados a la lista y que pueden recibir correos
    $leads = ORM::for_table('leads')
        ->where('tipo', $leads_list->tipos)
        ->where('send_mails', 1)
        ->find_many();

    // Recorrer cada lead
    foreach ($leads as $lead) {
        // Verificar si el lead está suscrito a la lista actual
        $lead_user_list = ORM::for_table('lead_users_lists')
            ->where('id_leads', $lead->id)
            ->where('id_leads_lists', $leads_list->id)
            ->find_one();

        // Si el lead no está suscrito a esta lista, pasar al siguiente lead
        if (!$lead_user_list || $lead_user_list->active == 0) {
            continue;
        }

        // Obtener el paso actual del lead en esta lista
        $current_paso = $lead_user_list->paso;

        // Obtener los pasos activos para esta lista de leads
        $pasos = ORM::for_table('lead_lists_pasos')
            ->where('id_leads_lists', $leads_list->id)
            ->where('numero_paso', $current_paso + 1) // Obtener el siguiente paso
            ->order_by_asc('numero_paso')
            ->find_many();

        // Si hay pasos por recorrer
        if ($pasos) {
            // Recorrer cada paso
            foreach ($pasos as $paso) {
                // Verificar si ha pasado el tiempo de espera para este paso
                $last_email_sent_time = strtotime($lead_user_list->last_email_sent_time);
                $current_time = time();
                $time_since_last_email = $current_time - $last_email_sent_time;

                if ($time_since_last_email < $paso->tiempo_espera * 60) {
                    // No ha pasado suficiente tiempo desde el último correo enviado
                    continue;
                } else {
                    // Enviar correo electrónico
                    $subject = $paso->subject;
                    $body = $paso->email_content;
                    $style = $paso->style;

                    enviarCorreo($lead->email, $subject, $body);

                    // Actualizar el paso en lead_users_lists
                    $lead_user_list->paso = $paso->numero_paso;
                    $lead_user_list->last_email_sent_time = date('Y-m-d H:i:s'); // Actualizar el tiempo del último correo enviado
                    $lead_user_list->save();
                }
            }
        }
    }
}
?>