$(document).ready(function(){
    $('#tipo_leads').select2()
    EcomOrders.init();
    $('#ecom-leads').DataTable().destroy()
    const ta = $('#ecom-leads').DataTable({
        order: [[ 0, "desc" ]],
        pageLength: 20,
        lengthMenu: [[10, 20, 30, -1], [10, 20, 30, 'Todas']],
        responsive: true
    })

    $('.edit_leads').on('click',function(){
        const nombre = $(this).data('nombre')
        const email = $(this).data('email')
        const telefono = $(this).data('telefono')
        const web = $(this).data('web')
        const tipo = $(this).data('tipo')

        $('#id_leads').val($(this).data('id'))
        $('#nombre_leads').val(nombre)
        $('#correo_leads').val(email)
        $('#telf_leads').val(telefono)
        $('#web_leads').val(web)
        $('#tipo_leads').val(tipo).trigger('change')

        $('.create_leads').click()
    })

    $('.delete_lead').on('click',function(){
        const id = $(this).data('id')

        $.ajax({
            method: "POST",
            url: url_post + 'mailing/delete_lead',
            data: {
                id,
            },
            type: 'POST',
        }).done(function (data) {
            data = JSON.parse(data)
            $("#avisos-mailing").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
            $("#avisos-mailing .avisoOpciones").show('slow')
            setTimeout(function() {
                location.reload();
            }, 2000);
        });
    })
    
    $('#createTipo').on('click',function(){
        const newTipo = $('#newTipo').val()

        if(newTipo != ''){
            $.ajax({
                method: "POST",
                url: url_post + 'mailing/addTipo',
                data: {
                    newTipo,
                },
                type: 'POST',
            }).done(function (data) {
                data = JSON.parse(data)
                $("#modal-tipo .leads_mailing").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
                $("#modal-tipo .avisoOpciones").show('slow')
                setTimeout(function() {
                    location.reload();
                }, 2000);
            });
        }else{
            $('.tipo_notify_danger').css('display','block')
        }
    })

    $('#create-act-leads').on('click',function(){
        $('.leads_notify_danger').css('display','none')

        const id = $('#id_leads').val()
        const nombre = $('#nombre_leads').val()
        const correo = $('#correo_leads').val()
        const telefono = $('#telf_leads').val()
        const web = $('#web_leads').val()
        const tipo = $('#tipo_leads').val()

        if(nombre != '' && correo != ''){
            $.ajax({
                method: "POST",
                url: url_post + 'mailing/create-act-leads',
                data: {
                    id,
                    nombre,
                    correo,
                    telefono,
                    web,
                    tipo
                },
                type: 'POST',
            }).done(function (data) {
                data = JSON.parse(data)
                $("#modal-newlead .leads_mailing").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
                $("#modal-newlead .avisoOpciones").show('slow')
                setTimeout(function() {
                    location.reload();
                }, 2000);
            });
        }else{
            $('.leads_notify_danger').css('display','block')
        }
    })

    $('#modal-newlead').on('hidden.bs.modal', function () {
        $('#id_leads').val('')
        $('#nombre_leads').val('')
        $('#correo_leads').val('')
        $('#telf_leads').val('')
        $('#web_leads').val('')
    });

    $('#sendMail').on('click',function(){
        $('.leads_notify_danger').css('display','none')
        $(".avisoOpciones").css('display','none')

        const asunto = $('#asunto_leads').val()
        const cuerpo = CKEDITOR.instances['cuerpo_leads'].getData()
        const correos = []

        ta.column(0).nodes().to$().each(function(index) {
            const element = $(this).find('.enviar_leads')
            if(element.is(':checked')){
                correos.push(element.val())
            }
        })

        const fichero = $('#userfile_leads').prop('files')[0]
        let formdata = new FormData()
        formdata.append("fichero",fichero)
        formdata.append("asunto",asunto)
        formdata.append("cuerpo",cuerpo)
        formdata.append("correos",correos)

        if(asunto != '' && cuerpo != '' && correos.length > 0){
            $.ajax({
                method: "POST",
                url: '?cf=mailing/send_mail',
                dataType: 'text',
                data: formdata,
                type: 'POST',
                processData: false,
                contentType: false
            }).done(function (data) {
                data = JSON.parse(data)
                $("#modal-sendMail .leads_mailing").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
                $("#modal-sendMail .avisoOpciones").show('slow')
                setTimeout(function() {
                    location.reload();
                }, 2000);
            });
        }else{
            $('.leads_notify_danger').css('display','block')
        }
    })
})