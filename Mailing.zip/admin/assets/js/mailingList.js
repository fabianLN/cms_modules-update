$(document).ready(function(){
    EcomOrders.init();
    $('#ecom-lists').DataTable();
    $('#tipo_envio').select2()

    $('#page-content').on('click','.update_mailing_cron',function(){
        const action = $(this).data('action')
        $.ajax({
            method: "POST",
            url: url_post + 'list_mailing/activeCron',
            data: {
                action
            },
            type: 'POST',
        }).done(function (data) {
            data = JSON.parse(data)
            if(data.text == 'crear'){
                $('.update_mailing_cron').data('action','borrar')
                $('.update_mailing_cron .widget-extra').removeClass('themed-background-danger').addClass('themed-background-success')
                $('.cron_text').html('Activada')
                $('.update_mailing_cron .h2').removeClass('text-danger').addClass('text-success')
            }else{
                $('.update_mailing_cron').data('action','borrar')
                $('.update_mailing_cron .widget-extra').removeClass('themed-background-success').addClass('themed-background-danger')
                $('.cron_text').html('No activada')
                $('.update_mailing_cron .h2').removeClass('text-success').addClass('text-danger')
            }
        });
    })

    $('#actCreateList').on('click',function(){
        const id=  $(this).data('id')
        const active = ($('#list-active').is(':checked'))? 'true' : 'false'
        const name = $('#nombre_list').val()
        const tipo = $('#tipo_envio').val()

        if(active != '' && name != '' && tipo != ''){
            $.ajax({
                method: "POST",
                url: url_post + 'list_mailing/act_create_list',
                data: {
                    id,
                    active,
                    name,
                    tipo
                },
                type: 'POST',
            }).done(function (data) {
                data = JSON.parse(data)
                $("#avisos-mailing").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
                $("#avisos-mailing .avisoOpciones").show('slow')
                setTimeout(function() {
                    if (data.id) {
                        location.href = '?cf=list_mailing/view-list/'+data.id
                    }else{
                        location.reload();
                    }
                }, 2000);
            });
        }else{
            $("#avisos-mailing").prepend('<div class="alert alert-danger avisoOpciones" style="display:none" role="alert">Algunos campos no están seleccionados</div>')
            $("#avisos-mailing .avisoOpciones").show('slow')
        }
    })

    $('.modal-inscripcion').on('click',function(){
        const id = $('#actCreateList').data('id')

        $.ajax({
            method: "POST",
            url: url_post + 'list_mailing/getLeads',
            data: {
                id
            },
            type: 'POST',
        }).done(function (data) {
            $('.leads_mailing').html(data)
            $('#nuevos_inscritos').select2({ width: '70%' })
        });
    })

    $('#agregar-inscrito').on('click',function(){
        const id = $('#actCreateList').data('id')
        const inscritos = $('#nuevos_inscritos').val()

        $.ajax({
            method: "POST",
            url: url_post + 'list_mailing/setInscritos',
            data: {
                id,
                inscritos
            },
            type: 'POST',
        }).done(function (data) {
            data = JSON.parse(data)
            $('.btn-close-modal').click()
            $("#avisos-mailing").prepend('<div class="alert alert-'+data['class']+' avisoOpciones" style="display:none" role="alert">' + data['text'] + '</div>')
            $("#avisos-mailing .avisoOpciones").show('slow')
            setTimeout(function() {
                location.reload();
            }, 2000);
        });
    })

    $('.email-active').on('change',function(){
        const id = $(this).data('id')
        const active = $(this).is(':checked')
        $.ajax({
            method: "POST",
            url: url_post + 'list_mailing/activeUser',
            data: {
                id,
                active
            },
            type: 'POST',
        })
    })
})